﻿namespace GeneralSchool
{
}
namespace GeneralSchool {
    
    
    public partial class SchoolDbDataSet {
    }
}
namespace GeneralSchool {
    
    
    public partial class SchoolDbDataSet {
    }
}
