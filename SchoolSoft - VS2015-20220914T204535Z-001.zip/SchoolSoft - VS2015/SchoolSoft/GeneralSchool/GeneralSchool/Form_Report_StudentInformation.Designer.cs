namespace GeneralSchool
{
    partial class Form_Report_StudentInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBox_SmcsdID = new System.Windows.Forms.ComboBox();
            this.tblSMCSDefineBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.comboBox_SessionID = new System.Windows.Forms.ComboBox();
            this.tblSessionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_Show_Report = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.crystalReportViewer_StudentInformation = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.tbl_SMCS_DefineTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SMCS_DefineTableAdapter();
            this.tbl_SessionTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SessionTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.tblSMCSDefineBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSessionBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBox_SmcsdID
            // 
            this.comboBox_SmcsdID.DataSource = this.tblSMCSDefineBindingSource;
            this.comboBox_SmcsdID.DisplayMember = "Class_Detail";
            this.comboBox_SmcsdID.FormattingEnabled = true;
            this.comboBox_SmcsdID.Location = new System.Drawing.Point(88, 73);
            this.comboBox_SmcsdID.Name = "comboBox_SmcsdID";
            this.comboBox_SmcsdID.Size = new System.Drawing.Size(467, 21);
            this.comboBox_SmcsdID.TabIndex = 0;
            this.comboBox_SmcsdID.ValueMember = "Smcsd_ID";
            this.comboBox_SmcsdID.SelectedIndexChanged += new System.EventHandler(this.comboBox_SmcsdID_SelectedIndexChanged);
            // 
            // tblSMCSDefineBindingSource
            // 
            this.tblSMCSDefineBindingSource.DataMember = "tbl_SMCS_Define";
            this.tblSMCSDefineBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox_SessionID
            // 
            this.comboBox_SessionID.DataSource = this.tblSessionBindingSource;
            this.comboBox_SessionID.DisplayMember = "Session_Desc";
            this.comboBox_SessionID.FormattingEnabled = true;
            this.comboBox_SessionID.Location = new System.Drawing.Point(88, 35);
            this.comboBox_SessionID.Name = "comboBox_SessionID";
            this.comboBox_SessionID.Size = new System.Drawing.Size(121, 21);
            this.comboBox_SessionID.TabIndex = 1;
            this.comboBox_SessionID.ValueMember = "Session_ID";
            // 
            // tblSessionBindingSource
            // 
            this.tblSessionBindingSource.DataMember = "tbl_Session";
            this.tblSessionBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // button_Show_Report
            // 
            this.button_Show_Report.Image = global::GeneralSchool.Properties.Resources.show_report;
            this.button_Show_Report.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_Show_Report.Location = new System.Drawing.Point(434, 14);
            this.button_Show_Report.Name = "button_Show_Report";
            this.button_Show_Report.Size = new System.Drawing.Size(121, 42);
            this.button_Show_Report.TabIndex = 2;
            this.button_Show_Report.Text = "Show Report";
            this.button_Show_Report.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_Show_Report.UseVisualStyleBackColor = true;
            this.button_Show_Report.Click += new System.EventHandler(this.button_Show_Report_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.comboBox_SmcsdID);
            this.groupBox1.Controls.Add(this.comboBox_SessionID);
            this.groupBox1.Controls.Add(this.button_Show_Report);
            this.groupBox1.Location = new System.Drawing.Point(12, 71);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(598, 104);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Parameters";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Class Detail:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Session Year:";
            // 
            // crystalReportViewer_StudentInformation
            // 
            this.crystalReportViewer_StudentInformation.ActiveViewIndex = -1;
            this.crystalReportViewer_StudentInformation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer_StudentInformation.Location = new System.Drawing.Point(12, 192);
            this.crystalReportViewer_StudentInformation.Name = "crystalReportViewer_StudentInformation";
            this.crystalReportViewer_StudentInformation.SelectionFormula = "";
            this.crystalReportViewer_StudentInformation.Size = new System.Drawing.Size(972, 423);
            this.crystalReportViewer_StudentInformation.TabIndex = 4;
            this.crystalReportViewer_StudentInformation.ViewTimeSelectionFormula = "";
            this.crystalReportViewer_StudentInformation.Load += new System.EventHandler(this.crystalReportViewer_StudentInformation_Load);
            // 
            // tbl_SMCS_DefineTableAdapter
            // 
            this.tbl_SMCS_DefineTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_SessionTableAdapter
            // 
            this.tbl_SessionTableAdapter.ClearBeforeFill = true;
            // 
            // Form_Report_StudentInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(996, 746);
            this.Controls.Add(this.crystalReportViewer_StudentInformation);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form_Report_StudentInformation";
            this.Text = "Student Information Report";
            this.Load += new System.EventHandler(this.Form_Report_StudentInformation_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Report_StudentInformation_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.tblSMCSDefineBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSessionBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_SmcsdID;
        private System.Windows.Forms.ComboBox comboBox_SessionID;
        private System.Windows.Forms.Button button_Show_Report;
        private System.Windows.Forms.GroupBox groupBox1;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer_StudentInformation;
        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tblSMCSDefineBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SMCS_DefineTableAdapter tbl_SMCS_DefineTableAdapter;
        private System.Windows.Forms.BindingSource tblSessionBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SessionTableAdapter tbl_SessionTableAdapter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}