using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_NewStudent_Registration : Form
    {
        Class_ConnectDB conDb = new Class_ConnectDB();
        public Form_General_Student_Info frmGSInfo;

        public Form_NewStudent_Registration()
        {
            InitializeComponent();
        }
        private void Form_NewStudent_Registration_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_SMCS_Define' table. You can move, or remove it, as needed.
            this.tbl_SMCS_DefineTableAdapter.Fill(this.schoolDbDataSet.tbl_SMCS_Define);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Result' table. You can move, or remove it, as needed.
            this.tbl_ResultTableAdapter.Fill(this.schoolDbDataSet.tbl_Result);
             // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Student_Movement' table. You can move, or remove it, as needed.
            this.tbl_Student_MovementTableAdapter.Fill(this.schoolDbDataSet.tbl_Student_Movement);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Student_Master' table. You can move, or remove it, as needed.
            this.tbl_Student_MasterTableAdapter.Fill(this.schoolDbDataSet.tbl_Student_Master);


          
            label19_resultID.Text = "1";

            this.label_SessionID.Text = conDb .returnSessionID ();
            this.label_SessionDesc.Text = conDb.returnSessionDesc();

            bindingNavigatorAddNewItem.Enabled = false;
            tbl_Student_MasterBindingNavigatorSaveItem.Enabled = false;

            bindingNavigatorMoveFirstItem.Enabled = true ;
            bindingNavigatorMovePreviousItem.Enabled = true;
            bindingNavigatorMoveNextItem.Enabled = true;
            bindingNavigatorMoveLastItem.Enabled = true;
            bindingNavigatorPositionItem.Enabled = true;
            BtnUpdate.Enabled = false;

            gR_NoTextBox.Enabled = false;
            percentageTextBox.Enabled = false;
            rollTextBox.Enabled = false;
        }

        // StudentNotRegisterGridView is for Only New Students, who want to take Admission in this School
        // in a New Class.
        private void studentNotRegisterGridView()
        {
            //string Con = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Program Files\General Solutions\SetupGSchool\Data\SchoolDB.mdb";
            string SqlNotRegStd = "SELECT Student_ID, Student_Name, Father_Name, Gender,Test_Result, Admission_Date "+
                "FROM tbl_Student WHERE (NOT (Student_ID IN (SELECT Student_ID "+
                "FROM tbl_Student_Master))) AND (Active = Yes) "+
                "AND (Class_ID = " + Convert.ToInt32(label2_ClassID.Text) + ") ";
            
            // Pass connection string to the OledbConnection object
            OleDbConnection OledbConn = new OleDbConnection(conDb.returnConString());

            //Unpaid Fee Voucher Grid View Fill
            OleDbDataAdapter daNRS = new OleDbDataAdapter(SqlNotRegStd, conDb.returnConString());
            DataTable dtNRS = new DataTable();
            daNRS.Fill(dtNRS);
            notRegStudent_bindingSource.DataSource = dtNRS;
            dvg_NotRegisteredStudent.DataSource = notRegStudent_bindingSource;
            dvg_NotRegisteredStudent.Columns[0].HeaderText = "ID";
            dvg_NotRegisteredStudent.Columns[1].HeaderText = "Student Name";
            //dvg_NotRegisteredStudent.Columns[1].Width = 300;
            dvg_NotRegisteredStudent.Columns[2].HeaderText = "Father Name";
            //dvg_NotRegisteredStudent.Columns[2].Width = 300;
            dvg_NotRegisteredStudent.Columns[3].HeaderText = "Gender";
            dvg_NotRegisteredStudent.Columns[4].HeaderText = "Test%";
            dvg_NotRegisteredStudent.Columns[5].HeaderText = "Admission-Date";
            dvg_NotRegisteredStudent.AutoResizeColumns ();
            //dvg_NotRegisteredStudent.AutoResizeColumnHeadersHeight();
            //dvg_NotRegisteredStudent.AutoResizeColumns(
            //DataGridViewAutoSizeColumnsMode.ColumnHeader);
         }
        
        
       // studentRegisterGridView() is those students, who have register and there GR No. is Assigned.
        private void studentRegisterGridView()
        {
            try
            {
                //SELECT St_Mov_ID, GR_No, Percentage, Roll, Student_ID, Student_Name, Father_Name, Gender FROM View_Student_Information WHERE (Session_ID = 2) AND (Shift_ID = 1) AND (Medium_ID = 2) AND (Class_ID = 4) AND (Section_ID = 1) AND (Result_ID = 1)

                // Session_ID is the Max ID of the Session Table, so when you create new session 
                // and not transfered the existing class students to new session in nex class it will give error.
                // So the best practice is that, strictly follow the steps of operating procedure.
                int S_ID = Convert.ToInt32(label_SessionID.Text); // this is Session_ID

                int Smsc_Id = Convert.ToInt32(label_SMCS_ID.Text);
                int Res_ID = Convert.ToInt32(label19_resultID.Text);
                //string Con = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Program Files\General Solutions\SetupGSchool\Data\SchoolDB.mdb";
                //string SqlRegStd = "SELECT St_Mov_ID, GR_No, Percentage, Roll, Student_ID, Student_Name, Father_Name, Gender FROM View_Student_Information WHERE (Session_ID = 2) AND (Shift_ID = " + Sh_ID + ") AND (Medium_ID = " + Med_ID + ") AND (Class_ID = " + Cls_ID + ") AND (Section_ID = " + Sec_ID + ") AND (Result_ID = " + Res_ID + ")  AND (Active = Yes)";

                string SqlRegStd = "SELECT St_Mov_ID, GR_No, Student_ID, Student_Name, Father_Name, " +
                " Gender, Percentage, Roll  FROM View_Student_Information WHERE (Session_ID = " + S_ID + ") " +
                " AND (Smcsd_ID = " + Smsc_Id + ") AND (Result_ID = " + Res_ID + ") AND (Active = Yes)";
                // Pass connection string to the OledbConnection object
                OleDbConnection OledbConn2 = new OleDbConnection(conDb.returnConString());

                OleDbDataAdapter daRS = new OleDbDataAdapter(SqlRegStd, conDb.returnConString());
                DataTable dtRS = new DataTable();

                daRS.Fill(dtRS);
                regStudent_bindingSource.DataSource = dtRS;
                dgv_RegisteredStudent.DataSource = regStudent_bindingSource;

                dgv_RegisteredStudent.Columns[0].Visible = false;
                dgv_RegisteredStudent.Columns[1].HeaderText = "GR No";
                dgv_RegisteredStudent.Columns[2].HeaderText = "ID";
                dgv_RegisteredStudent.Columns[3].HeaderText = "Student Name";
                dgv_RegisteredStudent.Columns[4].HeaderText = "Father Name";
                dgv_RegisteredStudent.Columns[5].HeaderText = "Gender";
                dgv_RegisteredStudent.Columns[6].HeaderText = "Percentage";
                dgv_RegisteredStudent.Columns[7].HeaderText = "Roll";
                dgv_RegisteredStudent.AutoResizeColumns();
            }
            catch
                (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex));
                //MessageBox.Show("Error: All Fields are necessary or This Student Already Registered...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
       
        }
     
        private void btnFindStudent_Click(object sender, EventArgs e)
        {
            if (label_SMCS_ID.Text != "Smcs_ID")
            { showCSSMiD(Convert.ToString(label_SMCS_ID.Text));
            }
            else { label_SMCS_ID.Text = "1"; showCSSMiD(Convert.ToString(label_SMCS_ID.Text)); }
                studentNotRegisterGridView();
            studentRegisterGridView();
            label4_MaxRoll.Text = returnMaxRoll(label_SMCS_ID.Text);
            if (label4_MaxRoll.Text == "")
            label4_MaxRoll.Text = "0";
        
            label18_Total_Student.Text = returnClassStudentCount(label_SessionID.Text, label_SMCS_ID.Text, label19_resultID.Text);

        }

        private void showCSSMiD(string  SmcsdID)
        {
            int id = Convert.ToInt32(SmcsdID);
            conDb.con.Open();
            OleDbCommand cmd5 = new OleDbCommand("SELECT Class_ID, Class_Capacity,  Class_Detail " +
            " FROM tbl_SMCS_Define WHERE (Smcsd_ID= " + id + " )", conDb.con);
             OleDbDataReader reader5 = cmd5.ExecuteReader();
            
                while (reader5.Read())
                {
                 label2_ClassID.Text = reader5["Class_ID"].ToString();
                 label_Class_Detail.Text = reader5["Class_Detail"].ToString();
                 label2_Class_Capacity.Text = reader5["Class_Capacity"].ToString();
                }
                reader5.Close();
                conDb.con.Close();

            //object returnValue5;
            //returnValue5 = cmd5.ExecuteScalar();
            //conDb.con.Close();
            //label11_ClassDetail.Text = Convert.ToString(returnValue5);
        }

        private void searchByClassComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            label_SMCS_ID.Text = Convert.ToString(searchByClassComboBox.SelectedValue);
            
        }
     

        private void comboBox3_Result_SelectedIndexChanged(object sender, EventArgs e)
        {
            label19_resultID.Text = Convert.ToString(comboBox3_Result.SelectedValue);
        }

        private void dvg_NotRegisteredStudent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1 && e.ColumnIndex > -1)
            {
                label_Class_Detail.Text = searchByClassComboBox.Text;
                //label4_Shift.Text = comboBox1_Shift.Text;
                //label7_Medium.Text = comboBox2_Medium.Text;

                //label18_Section.Text = searchBySection_ComboBox.Text;
                label19_Result.Text = comboBox3_Result.Text;

                label3_St_ID.Text = Convert.ToString(dvg_NotRegisteredStudent.SelectedCells[0].Value);
                label_StudentName.Text = Convert.ToString(dvg_NotRegisteredStudent.SelectedCells[1].Value);
                label_FatherName.Text = Convert.ToString(dvg_NotRegisteredStudent.SelectedCells[2].Value);
                label_Gender.Text = Convert.ToString(dvg_NotRegisteredStudent.SelectedCells[3].Value);
                label18_Test_Percent.Text = Convert.ToString(dvg_NotRegisteredStudent.SelectedCells[4].Value);
                label_AdmissionDate.Text = Convert.ToString(dvg_NotRegisteredStudent.SelectedCells[5].Value);

             

                if (int.Parse (label18_Total_Student.Text)  >=  int.Parse (label2_Class_Capacity.Text) )
                {
                    bindingNavigatorAddNewItem.Enabled = false;
                    if (MessageBox.Show("No Seating Capacity in this Class, For Create New Section or Increase Class Capacity Click Yes", "No Seating Capacity", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    { 
                       Form_Class_Section_Shift_Medium_Define frmClassDefine = new Form_Class_Section_Shift_Medium_Define();
                       frmClassDefine .frmNSR = this ;
                        frmClassDefine .ShowDialog ();
                        
                    }
                    else { tabControl1.SelectTab(0); }
                }
                else
                {
                    bindingNavigatorAddNewItem.Enabled = true;

                    gR_NoTextBox.Visible = false;
                    percentageTextBox.Visible = false;
                    rollTextBox.Visible = false;

                    bindingNavigatorMoveFirstItem.Enabled = false;
                    bindingNavigatorMovePreviousItem.Enabled = false;
                    bindingNavigatorMoveNextItem.Enabled = false;
                    bindingNavigatorMoveLastItem.Enabled = false;
                    bindingNavigatorPositionItem.Enabled = true;

                    tbl_Student_MasterBindingNavigatorSaveItem.Enabled = false;
                    BtnUpdate.Enabled = false;

                    tabControl1.SelectTab(1);

                }

            }

        }

        private void autoIncrement()
        {
           
                gR_NoTextBox.Visible = true;
                gR_NoTextBox.Enabled = false;
                conDb.con.Open();
                OleDbCommand cmd = new OleDbCommand("SELECT  Max(gR_No) AS expr_ID FROM View_Student_Information", conDb.con);
                object returnValue;
                returnValue = cmd.ExecuteScalar();
                conDb.con.Close();
                if (returnValue != DBNull.Value )
                {
                    int val1 = Convert.ToInt32(returnValue);
                    int val2 = val1 + 1;
                    gR_NoTextBox.Text = Convert.ToString(val2);
                }
                else
                {
                    gR_NoTextBox.Visible = true;
                    gR_NoTextBox.Enabled = true;
                    MessageBox.Show("Enter the First GR.Number of your School...", "Starting GR No.", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    gR_NoTextBox.Focus();
                }
            
        }

        private string returnMaxRoll(string smcsId)
        {
            int smcs_id = Convert.ToInt32(smcsId); 
            conDb.con.Open();
            OleDbCommand cmd2 = new OleDbCommand("SELECT  Max(Roll)  AS expr_Roll  FROM View_Student_Information Where Smcsd_ID = " + smcs_id + "", conDb.con);
            object returnValue2;
            returnValue2 = cmd2.ExecuteScalar();
            conDb.con.Close();
        
           return Convert.ToString(returnValue2); 
        }

        //private string returnClassCapacity(string smcsId)
        //{
        //    int smcs_id = Convert.ToInt32(smcsId); 
        //    conDb.con.Open();
        //    OleDbCommand cmd3 = new OleDbCommand("SELECT  Class_Capacity  FROM View_Student_Information Where Smcsd_ID = " + smcs_id + "", conDb.con);
        //    object returnValue3;
        //    returnValue3 = cmd3.ExecuteScalar();
        //    conDb.con.Close();
        //    return Convert.ToString(returnValue3);
        //}

        private string returnClassStudentCount(string sID, string smcsId, string resID)
        {
            int S_ID = Convert.ToInt32(sID );
            int smcs_id = Convert.ToInt32(smcsId); 
            int Res_ID = Convert.ToInt32(resID );   
     
            conDb.con.Open();
            OleDbCommand cmd4 = new OleDbCommand("SELECT COUNT(GR_No) AS Expr1 FROM View_Student_Information "+
            " WHERE (Session_ID = " + S_ID + ") AND (Smcsd_ID = " + smcs_id +
            ") AND (Result_ID = " + Res_ID + ") AND (Active = Yes) ", conDb.con);
            object returnValue4;
            returnValue4 = cmd4.ExecuteScalar();
            conDb.con.Close();
            return Convert.ToString(returnValue4);
        }

        private void bindingNavigatorAddNewItem_Click_1(object sender, EventArgs e)
        {
            autoIncrement();
            student_IDTextBox.Text = label3_St_ID.Text;
            session_IDTextBox.Text = label_SessionID.Text;
            smcsd_IDTextBox.Text = label_SMCS_ID.Text;
            result_IDTextBox.Text  = label19_resultID.Text;
            percentageTextBox.Text = label18_Test_Percent.Text;

            
            gR_NoTextBox.BackColor = Color.LawnGreen;
            percentageTextBox.Visible =true;
            percentageTextBox.Enabled = false;
            percentageTextBox.BackColor = Color.LawnGreen;
            
            rollTextBox.Visible = true ;
            rollTextBox.Enabled = false;
            rollTextBox.BackColor = Color.LawnGreen;
            
            if (label18_Total_Student.Text != "0")
                rollTextBox.Text = Convert.ToString(Convert.ToInt32(returnMaxRoll(label_SMCS_ID.Text )) + 1);
            else
            {
                label4_MaxRoll.Text = "0";
                rollTextBox.Text = "1";
            }
            bindingNavigatorMoveFirstItem.Enabled = false;
            bindingNavigatorMovePreviousItem.Enabled = false;
            bindingNavigatorMoveNextItem.Enabled = false;
            bindingNavigatorMoveLastItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
            
            bindingNavigatorAddNewItem.Enabled = false;
           
            tbl_Student_MasterBindingNavigatorSaveItem.Enabled = true ;
            btn_Edit.Enabled = false;
            BtnUpdate.Enabled = false;
        }

        private void tbl_Student_MasterBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            //this.Validate();
            //this.tbl_Student_MasterBindingSource.EndEdit();
            //this.tbl_Student_MasterTableAdapter.Update(this.schoolDbDataSet.tbl_Student_Master);
            try
            {
                //tbl_Student_Master
                
                int grNo = Convert.ToInt32(gR_NoTextBox.Text);
             
                int stdId = Convert.ToInt32(student_IDTextBox.Text);
                //tbl_Student_Movement
                int sessionId = Convert.ToInt32(session_IDTextBox.Text);
                int smcsdId = Convert.ToInt32(smcsd_IDTextBox.Text);
               
                int resId = Convert.ToInt32(result_IDTextBox.Text);
               double per = Convert.ToDouble(percentageTextBox.Text);
                int roll = Convert.ToInt32(rollTextBox.Text);

                tbl_Student_MasterTableAdapter.Insert(grNo, stdId);
                tbl_Student_MovementTableAdapter.Insert(grNo, sessionId, smcsdId, resId, per, roll);
                MessageBox.Show("This Student Succesfully Registered...", "Successfully Registered", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch
                (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex));
                //MessageBox.Show("Error: All Fields are necessary or This Student Already Registered...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //RefreshDataset();
            tbl_Student_MasterBindingNavigatorSaveItem.Enabled = false;
            //Load Unregister Students GridView
            studentNotRegisterGridView();
            studentRegisterGridView();
            label4_MaxRoll.Text = returnMaxRoll(label_SMCS_ID.Text);
            label18_Total_Student.Text = returnClassStudentCount(label_SessionID.Text, label_SMCS_ID.Text, label19_resultID.Text);
            tabControl1.SelectTab(0);
        }

        private void BtnUpdate_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_Student_MovementBindingSource.EndEdit();
            this.tbl_Student_MovementTableAdapter.Update(this.schoolDbDataSet.tbl_Student_Movement);
            MessageBox.Show("Record Successfully Updated, Press OK to Continue...", "Record Successfully Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
            BtnUpdate.Enabled = false;
            btn_Edit.Enabled = true;
            percentageTextBox.Enabled = false;
            percentageTextBox.BackColor = Color.Empty;
            //percentageTextBox.Focus();
            rollTextBox.Enabled = false ;
            rollTextBox.BackColor = Color.Empty;
            
            
            
            //int grNo = Convert.ToInt32(gR_NoTextBox.Text);
            //int stdId = Convert.ToInt32(student_IDComboBox.SelectedValue);
            ////tbl_Student_Movement
            //int sessionId = Convert.ToInt32(session_IDComboBox.SelectedValue);
            //int shiftId = Convert.ToInt32(shift_IDComboBox.SelectedValue);
            //int medId = Convert.ToInt32(medium_IDComboBox.SelectedValue);
            //int classId = Convert.ToInt32(class_IDComboBox.SelectedValue);
            //int secId = Convert.ToInt32(section_IDComboBox.SelectedValue);
            //int resId = Convert.ToInt32(result_IDComboBox.SelectedValue);
            //int per = Convert.ToInt32(percentageTextBox.Text);
            //int roll = Convert.ToInt32(rollTextBox.Text);
            //conDb.con.Open();
            //OleDbCommand cmd1 = new OleDbCommand();
            //cmd1.CommandType = CommandType.Text;
            ////cmd.CommandText = "UPDATE tbl_Student_Movement SET RegionID = 1, RegionDescription = 'East' WHERE RegionID = 1";
            //cmd1.CommandText = "UPDATE tbl_Student_Movement SET GR_No = " + grNo + ",Session_ID= " +sessionId+", Shift_ID = "+shiftId+", Medium_ID = "+medId+", Class_ID = "+classId+", Section_ID = "+secId+", Result_ID = "+resId+", Percentage = "+per+", Roll = "+roll+" WHERE GR_No =  " + Convert.ToInt32(gR_NoTextBox.Text) + " ";

            //cmd1.ExecuteNonQuery();
            //conDb.con.Close();
        }

        private void gR_NoTextBox_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void showDataByGrNo()
        {
            conDb.con.Open();
            OleDbCommand cmd4 = new OleDbCommand("SELECT GR_No, Student_ID, Session_Desc, "+
            " Result_Desc, Student_Name, Father_Name," +
            " Gender, Admission_Date, Class_Detail FROM View_Student_Information "+
            " WHERE (GR_No = " + Convert.ToInt32(gR_NoTextBox.Text) + ")", conDb.con);
            OleDbDataReader reader4 = cmd4.ExecuteReader();
            if (reader4.HasRows == true)
            {
                while (reader4.Read())
                {
                    label3_St_ID.Text = reader4["Student_ID"].ToString();
                    label_SessionDesc .Text = reader4["Session_Desc"].ToString();
                    label_Class_Detail.Text = reader4["Class_Detail"].ToString();
                    label19_Result.Text = reader4["Result_Desc"].ToString();
                    label_StudentName.Text = reader4["Student_Name"].ToString();
                    label_FatherName.Text = reader4["Father_Name"].ToString();
                    label_Gender.Text = reader4["Gender"].ToString();
                    label_AdmissionDate.Text = reader4["Admission_Date"].ToString();
                }
            }
            else
            {
                MessageBox.Show("No Record Found, Press OK to Continue...", "No Record Found", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            reader4.Close();
            conDb.con.Close();
        }

 

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            showDataByGrNo();
            //label4_MaxRoll.Text = returnMaxRoll(class_IDTextBox.Text);
            //label3_ClassCapacity.Text = returnClassCapacity(class_IDTextBox.Text);
            //label18_Total_Student.Text = returnClassStudentCount(session_IDTextBox.Text, shift_IDTextBox.Text, medium_IDTextBox.Text, class_IDTextBox.Text, section_IDTextBox.Text, result_IDTextBox.Text);
            
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            showDataByGrNo();
            //label4_MaxRoll.Text = returnMaxRoll(class_IDTextBox.Text);
            //label3_ClassCapacity.Text = returnClassCapacity(class_IDTextBox.Text);
            //label18_Total_Student.Text = returnClassStudentCount(session_IDTextBox.Text, shift_IDTextBox.Text, medium_IDTextBox.Text, class_IDTextBox.Text, section_IDTextBox.Text, result_IDTextBox.Text);
           
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            showDataByGrNo();
            //label4_MaxRoll.Text = returnMaxRoll(class_IDTextBox.Text);
            //label3_ClassCapacity.Text = returnClassCapacity(class_IDTextBox.Text);
            //label18_Total_Student.Text = returnClassStudentCount(session_IDTextBox.Text, shift_IDTextBox.Text, medium_IDTextBox.Text, class_IDTextBox.Text, section_IDTextBox.Text, result_IDTextBox.Text);
           
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            showDataByGrNo();
            //label4_MaxRoll.Text = returnMaxRoll(class_IDTextBox.Text);
            //label3_ClassCapacity.Text = returnClassCapacity(class_IDTextBox.Text);
            //label18_Total_Student.Text = returnClassStudentCount(session_IDTextBox.Text, shift_IDTextBox.Text, medium_IDTextBox.Text, class_IDTextBox.Text, section_IDTextBox.Text, result_IDTextBox.Text);
           
        }

        private Form_PasswordDialog _passDlg = new Form_PasswordDialog();
        private Form_Login frmLogin = new Form_Login();

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = _passDlg.ShowDialog(this);
            if ((dialogResult == DialogResult.OK) && (_passDlg.Password == "15March2011915"))
            {
                _passDlg.textBoxPassword.Text = "";
                percentageTextBox.Enabled = true;
                //percentageTextBox.BackColor = Color.White;
                percentageTextBox.Focus();
                rollTextBox.Enabled = true;
                //rollTextBox.BackColor = Color.White;
                btn_Edit.Enabled = false;
                BtnUpdate.Enabled = true;
            }
            else if ((dialogResult == DialogResult.OK) && (_passDlg.Password == frmLogin.checkUserPass("Admin")))
            {
                _passDlg.textBoxPassword.Text = "";
                percentageTextBox.Enabled = true;
                //percentageTextBox.BackColor = Color.White;
                percentageTextBox.Focus();
                rollTextBox.Enabled = true;
                //rollTextBox.BackColor = Color.White;
                btn_Edit.Enabled = false;
                BtnUpdate.Enabled = true;
            }
            else if (dialogResult == DialogResult.Cancel)
            { }
            else
            {
                _passDlg.textBoxPassword.Text = "";
                MessageBox.Show("Invalid Password.....Press OK to continue...", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            
        }

        private void Form_NewStudent_Registration_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.RegisterStudent = false;
            
        }

    
    }
}

/*
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * // student_IDTextBox Text Change 
        //private void student_IDTextBox_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //    if (e.KeyChar == 13)
        //    {
        //        class_IDTextBox.Text = label_Class_ID.Text;
        //        label_AdmissionInClass.Text = searchByClassComboBox.Text;
        //        session_IDTextBox.Text = label_SessionID.Text;
                 
        //        conDb.con.Open();

        //OleDbCommand cmd4 = new OleDbCommand("SELECT GR_No, Student_ID, Session_Desc, Shift_Desc, Medium_Desc, Class_Desc, Class_Capacity, Section_Desc, Result_Desc, Percentage, Roll, Student_Name, Father_Name, Gender FROM View_Student_Information WHERE (GR_No = 1000)", conDb.con);
        //        OleDbDataReader reader4 = cmd4.ExecuteReader();
        //        if (reader4.HasRows == true)
        //        {
        //            while (reader4.Read())
        //            {
        //             label_StudentName .Text = reader4["Student_Name"].ToString();
        //            label_FatherName.Text = reader4["Father_Name"].ToString();
        //            label_Gender.Text = reader4["Gender"].ToString();
        //           //label_AdmissionInClass.Text = reader4["Class_ID"].ToString();
        //            label_AdmissionDate.Text = reader4["Admission_Date"].ToString();
                       
                       
        //            }
        //        }
        //        else
        //        {
        //            label_StudentName.Text = "";
        //            label_FatherName.Text = "";
        //            label_Gender.Text = "";
        //            class_IDTextBox.Text = "";
        //            label_AdmissionDate.Text = "";
                   


        //            MessageBox.Show("No Record Found, Press OK to Continue...", "No Record Found", MessageBoxButtons.OK, MessageBoxIcon.Information);

        //        }
        //        reader4.Close();
        //        conDb.con.Close();
        //    }
        //}
 * 
 * 
 * 
 * 
 *   private void dvg_NotRegisteredStudent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
             if (e.RowIndex > -1 && e.ColumnIndex > -1)
            {
                //string session = "";
                //SessionID = Convert.ToInt32(sessionIDComboBox.SelectedValue);
                //session = sessionIDComboBox.Text;
                //txtsessionID.Text = session;


                //StdID = Convert.ToInt32(view_Find_StudentDataGridView.SelectedCells[0].Value);
                //StdName = Convert.ToString(view_Find_StudentDataGridView.SelectedCells[1].Value);
                //Gender = Convert.ToString(view_Find_StudentDataGridView.SelectedCells[2].Value);
                //ClassDsc = Convert.ToString(view_Find_StudentDataGridView.SelectedCells[3].Value);
                //SecDsc = Convert.ToString(view_Find_StudentDataGridView.SelectedCells[4].Value);
                //RNID = Convert.ToInt32(view_Find_StudentDataGridView.SelectedCells[5].Value);
                //StdDtID = Convert.ToInt32(view_Find_StudentDataGridView.SelectedCells[6].Value);


                txtsessionID.Text = sessionIDComboBox.Text;

                txtStdID.Text = Convert.ToString(view_Find_StudentDataGridView.SelectedCells[0].Value);
                txtName.Text = Convert.ToString(view_Find_StudentDataGridView.SelectedCells[1].Value);
                txtGender.Text = Convert.ToString(view_Find_StudentDataGridView.SelectedCells[2].Value);
                txtClass.Text = Convert.ToString(view_Find_StudentDataGridView.SelectedCells[3].Value);
                txtSection.Text = Convert.ToString(view_Find_StudentDataGridView.SelectedCells[4].Value);
                txtRNID.Text = Convert.ToString(view_Find_StudentDataGridView.SelectedCells[5].Value);
                StdDtID = Convert.ToInt32(view_Find_StudentDataGridView.SelectedCells[6].Value);


                classDescComboBox1.Text = txtClass.Text;
                secDescComboBox1.Text = txtSection.Text;
                rNIDComboBox1.Text = txtRNID.Text;
                
                tabControl1.SelectTab(1);

                ClassDsc = classDescComboBox1.Text;
                // TODO: This line of code loads data into the 'dS_View_Section.View_Section' table. You can move, or remove it, as needed.
                this.view_SectionTableAdapter.FillBy_SectionBy_ClassDesc(this.dS_View_Section.View_Section, ClassDsc);


                //stdIDTextBox1.Text = Convert.ToString(StdID);
                //nameTextBox1.Text = StdName;
                //genderTextBox.Text = Gender;
                //classDescTextBox.Text = ClassDsc;
                //secDescTextBox.Text = SecDsc;
                //rNIDTextBox.Text = Convert.ToString(RNID);

                ////// TODO: This line of code loads data into the 'dS_View_FeeDesc_ByClassDesc.View_Fee_Desc_By_ClassDesc' table. You can move, or remove it, as needed.
                ////this.view_Fee_Desc_By_ClassDescTableAdapter.FillBy_ClassDesc_SessionID(this.dS_View_FeeDesc_ByClassDesc.View_Fee_Desc_By_ClassDesc,SessionID,ClassDsc);

                // TODO: This line of code loads data into the 'dS_View_Recp_ByStdDtID.View_Recp_ByStdDtID' table. You can move, or remove it, as needed.
                //this.view_Recp_ByStdDtIDTableAdapter.FillBy_StdDtID(this.dS_View_Recp_ByStdDtID.View_Recp_ByStdDtID, StdDtID);
                //this.view_Recp_ByStdDtIDBindingSource.MoveLast();

                //// TODO: This line of code loads data into the 'dS_View_FeeRecp_ByStdID.View_FeeRecp_ByStdID' table. You can move, or remove it, as needed. ,SessionID,StdID,ClassDsc,SecDsc);
                //this.view_FeeRecp_ByStdIDTableAdapter.FillBy_StdID_ClassDesc_SecDesc(this.dS_View_FeeRecp_ByStdID.View_FeeRecp_ByStdID, StdID, ClassDsc, SecDsc);

                //tabFeeReceipt.SelectTab(1);
                //if (recpIDTextBox.Text != "")
                //{
                //    FeeRecpID = Convert.ToInt32(recpIDTextBox.Text);
                //    //TODO: This line of code loads data into the 'dS_View_RecpDt_ByRecpID.View_RecpDt_ByRecpID' table. You can move, or remove it, as needed.
                //    this.view_RecpDt_ByRecpIDTableAdapter.FillBy_RecpID_DscOrder(this.dS_View_RecpDt_ByRecpID.View_RecpDt_ByRecpID, FeeRecpID);
                //}
                //else
                //{ FeeRecpID = 0; }
                //// TODO: This line of code loads data into the 'dS_View_RecpDt_ByRecpID.View_RecpDt_ByRecpID' table. You can move, or remove it, as needed.
                //this.view_RecpDt_ByRecpIDTableAdapter.FillBy_RecpID_DscOrder(this.dS_View_RecpDt_ByRecpID.View_RecpDt_ByRecpID, FeeRecpID);

            }
        }
 * 
 * 
 * 
 * 
 * 
  SELECT Student_ID, Student_Name, Father_Name, Gender, Admission_Date
  FROM tbl_Student WHERE (NOT (Student_ID IN (SELECT Student_ID 
  FROM tbl_Student_Master))) AND (Active = Yes)
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
//this.Validate();
//this.tbl_Student_MovementBindingSource.EndEdit();
//this.tbl_Student_MovementTableAdapter.Update(this.schoolDbDataSet.tbl_Student_Movement);
////            * Insert New Records Using TableAdapters
//// * 
//// * TableAdapters provide different ways to insert new records into a database, depending on the requirements 
//// * of your application.

////If your application uses datasets to store data, then you can simply add new records to the desired DataTable 
//// * in the dataset, and then call the TableAdapter.Update method. The TableAdapter.Update method takes any 
//// * changes in the DataTable and sends those changes to the database (including modified and deleted records).


//            SchoolDbDataSet.tbl_Student_MasterRow newMasterRow;
//            newMasterRow =  schoolDbDataSet.tbl_Student_Master.Newtbl_Student_MasterRow();
//            newMasterRow.GR_No  = 1;
//            newMasterRow.Student_ID  =Convert.to student_IDComboBox.SelectedValue;

//            // Add the row to the tbl_Student_Movement
//            this.schoolDbDataSet.tbl_Student_Master.Rows.Add(newMasterRow) ;
//            // Save the new row to the database
//            this.tbl_Student_MasterTableAdapter.Update(this.schoolDbDataSet.tbl_Student_Master);


//            SchoolDbDataSet.tbl_Student_MovementRow newMovementRow;
//            newMovementRow = schoolDbDataSet.tbl_Student_Movement.Newtbl_Student_MovementRow();
//            st_Mov_IDTextBox.Text = student_IDComboBox.SelectedValue;
//            newMovementRow.St_Mov_ID = st_Mov_IDTextBox.Text;
//            newMovementRow.GR_No = gR_NoTextBox1.Text;
//            newMovementRow.Section_ID = session_IDComboBox.SelectedValue;
//            newMovementRow.Shift_ID = shift_IDComboBox.SelectedValue;
//            newMovementRow.Medium_ID = medium_IDComboBox.SelectedValue;
//            newMovementRow.Class_ID = class_IDComboBox.SelectedValue;
//            newMovementRow.Section_ID = section_IDComboBox.SelectedValue;
//            newMovementRow.Result_ID = result_IDComboBox.SelectedValue;
//            newMovementRow.Percentage = percentageTextBox.Text;
//            newMovementRow.Roll = rollTextBox.Text;

//            // Add the row to the tbl_Student_Movement
//            this.schoolDbDataSet.tbl_Student_Movement.Rows.Add(newMovementRow);
//            // Save the new row to the database
//            this.tbl_Student_MovementTableAdapter.Update(this.schoolDbDataSet.tbl_Student_Movement);

 * 
 * 
 * 
 * 
 * 
 * private void UpdateDB()
        {
            
            SchoolDbDataSet.tbl_Student_MovementDataTable deletedChildRecords =
               (SchoolDbDataSet.tbl_Student_MovementDataTable)schoolDbDataSet.tbl_Student_Movement.GetChanges(DataRowState.Deleted );
            
            SchoolDbDataSet.tbl_Student_MovementDataTable newChildRecords =
               (SchoolDbDataSet.tbl_Student_MovementDataTable)schoolDbDataSet.tbl_Student_Movement.GetChanges(DataRowState.Added);
                       
            SchoolDbDataSet.tbl_Student_MovementDataTable modifiedChildRecords =
                (SchoolDbDataSet.tbl_Student_MovementDataTable)schoolDbDataSet.tbl_Student_Movement.GetChanges(DataRowState.Modified);
            

            try
            {
                if (deletedChildRecords != null)
                {
                    tbl_Student_MovementTableAdapter.Update(deletedChildRecords);
                    
                }
                tbl_Student_MovementTableAdapter.Update(schoolDbDataSet.tbl_Student_Movement);
                

                if (newChildRecords != null)
                {
                    tbl_Student_MovementTableAdapter.Update(newChildRecords);
                }

                if (modifiedChildRecords != null)
                {
                    tbl_Student_MovementTableAdapter.Update(modifiedChildRecords);
                }
                schoolDbDataSet.AcceptChanges();
            }

            catch (Exception ex)
            {
                MessageBox.Show(Convert .ToString (ex));
                // Add code to handle error here.
            }

            finally
            {
                if (deletedChildRecords != null)
                {
                    deletedChildRecords.Dispose();
                }
                if (newChildRecords != null)
                {
                    newChildRecords.Dispose();
                }
                if (modifiedChildRecords != null)
                {
                    modifiedChildRecords.Dispose();
                }
            }
        }
 * 
 * 
 * 
 * 
 * 
 * 
 * //UpdateDB();


            //System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            //cmd.CommandType = System.Data.CommandType.Text;
            //cmd.CommandText = "UPDATE Region SET RegionID = 1, RegionDescription = 'East' WHERE RegionID = 1";
            //cmd.Connection = sqlConnection1;
            //sqlConnection1.Open();
            //cmd.ExecuteNonQuery();
            //sqlConnection1.Close();
            //tbl_Student_MasterTableAdapter.Insert(grNo, stdId);
            //tbl_Student_MovementTableAdapter.Insert(grNo, sessionId, shiftId, medId, classId, secId, resId, per, roll);
            //tbl_Student_MasterTableAdapter .Update (

            //SchoolDbDataSet.tbl_Student_MasterRow stMasterRow;
            //stMasterRow = schoolDbDataSet.tbl_Student_Master.FindByGR_No(Convert.ToInt32(gR_NoTextBox.Text));
            ////tbl_Student_MasterTable Fields
            //stMasterRow.GR_No = Convert.ToInt32 ( gR_NoTextBox.Text);
            //stMasterRow .Student_ID = Convert.ToInt32 (student_IDComboBox.SelectedValue);
            
            //SchoolDbDataSet.tbl_Student_MovementRow stMovementRow;
            ////tbl_Student_MovementTable Fields
            //stMovementRow = schoolDbDataSet.tbl_Student_Movement.FindBySt_Mov_ID (Convert.ToInt32(st_Mov_IDTextBox.Text));
            //stMovementRow.GR_No = Convert.ToInt32 (gR_NoTextBox.Text);
            //stMovementRow.Session_ID = Convert.ToInt32 (section_IDComboBox.SelectedValue);
            //stMovementRow.Shift_ID = Convert.ToInt32 (shift_IDComboBox.SelectedValue);
            //stMovementRow.Medium_ID = Convert.ToInt32 (medium_IDComboBox.SelectedValue);
            //stMovementRow.Class_ID = Convert.ToInt32 (class_IDComboBox.SelectedValue);
            //stMovementRow.Section_ID = Convert.ToInt32 (section_IDComboBox.SelectedValue);
            //stMovementRow.Result_ID = Convert.ToInt32 (result_IDComboBox.SelectedValue);
            //stMovementRow.Percentage = Convert.ToInt32 (percentageTextBox.Text);
            //stMovementRow.Roll = Convert.ToInt32 (rollTextBox.Text);

            //this.tbl_Student_MasterTableAdapter.Update(this.schoolDbDataSet.tbl_Student_Master);
            //this.tbl_Student_MovementTableAdapter.Update(this.schoolDbDataSet.tbl_Student_Movement);
            
            //Locate the row you want to update.
            //NorthwindDataSet.RegionRow regionRow;
            //regionRow = northwindDataSet.Region.FindByRegionID(1);
            //// Assign the new value to the desired column.
            //regionRow.RegionDescription = "East";
            //// Save the updated row to the database.
            //this.regionTableAdapter.Update(this.northwindDataSet.Region);
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
*/