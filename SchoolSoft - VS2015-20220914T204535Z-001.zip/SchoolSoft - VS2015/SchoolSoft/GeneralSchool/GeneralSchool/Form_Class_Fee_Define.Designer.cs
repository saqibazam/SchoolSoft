namespace GeneralSchool
{
    partial class Form_Class_Fee_Define
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label fee_Define_IDLabel;
            System.Windows.Forms.Label session_IDLabel;
            System.Windows.Forms.Label class_IDLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Class_Fee_Define));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.tbl_Fee_Define_MasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_Fee_Define_MasterTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Fee_Define_MasterTableAdapter();
            this.tbl_Fee_Define_MasterBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_Fee_Define_MasterBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_Edit_Data = new System.Windows.Forms.ToolStripButton();
            this.btn_Delete = new System.Windows.Forms.ToolStripButton();
            this.fee_Define_IDTextBox = new System.Windows.Forms.TextBox();
            this.tbl_Fee_Define_DetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_Fee_Define_DetailTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Fee_Define_DetailTableAdapter();
            this.tbl_Fee_Define_DetailDataGridView = new System.Windows.Forms.DataGridView();
            this.feeDefineDetailIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.feeDefineIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.feeTypeIDDataGridViewComboBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.viewFeeTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.feeAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.feeMonthDataGridViewComboBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.tblFeeTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.session_IDTextBox = new System.Windows.Forms.ComboBox();
            this.tblSessionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.class_IDTextBox = new System.Windows.Forms.ComboBox();
            this.tblClassBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_SessionTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SessionTableAdapter();
            this.tbl_ClassTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ClassTableAdapter();
            this.tbl_Fee_TypeTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Fee_TypeTableAdapter();
            this.feeCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_Select_DeSelect = new System.Windows.Forms.Button();
            this.btn_Insert_Tution_Fee = new System.Windows.Forms.Button();
            this.cmb_FeeType = new System.Windows.Forms.ComboBox();
            this.amountTextBox = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox_FeeDetail = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button_EnabaleAddEdit = new System.Windows.Forms.Button();
            this.view_FeeTypeTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.View_FeeTypeTableAdapter();
            fee_Define_IDLabel = new System.Windows.Forms.Label();
            session_IDLabel = new System.Windows.Forms.Label();
            class_IDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Define_MasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Define_MasterBindingNavigator)).BeginInit();
            this.tbl_Fee_Define_MasterBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Define_DetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Define_DetailDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewFeeTypeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblFeeTypeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSessionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblClassBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox_FeeDetail.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // fee_Define_IDLabel
            // 
            fee_Define_IDLabel.AutoSize = true;
            fee_Define_IDLabel.Location = new System.Drawing.Point(14, 26);
            fee_Define_IDLabel.Name = "fee_Define_IDLabel";
            fee_Define_IDLabel.Size = new System.Drawing.Size(76, 13);
            fee_Define_IDLabel.TabIndex = 1;
            fee_Define_IDLabel.Text = "Fee Define ID:";
            // 
            // session_IDLabel
            // 
            session_IDLabel.AutoSize = true;
            session_IDLabel.Location = new System.Drawing.Point(14, 52);
            session_IDLabel.Name = "session_IDLabel";
            session_IDLabel.Size = new System.Drawing.Size(72, 13);
            session_IDLabel.TabIndex = 3;
            session_IDLabel.Text = "Session Year:";
            // 
            // class_IDLabel
            // 
            class_IDLabel.AutoSize = true;
            class_IDLabel.Location = new System.Drawing.Point(14, 77);
            class_IDLabel.Name = "class_IDLabel";
            class_IDLabel.Size = new System.Drawing.Size(35, 13);
            class_IDLabel.TabIndex = 5;
            class_IDLabel.Text = "Class:";
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_Fee_Define_MasterBindingSource
            // 
            this.tbl_Fee_Define_MasterBindingSource.DataMember = "tbl_Fee_Define_Master";
            this.tbl_Fee_Define_MasterBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tbl_Fee_Define_MasterTableAdapter
            // 
            this.tbl_Fee_Define_MasterTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_Fee_Define_MasterBindingNavigator
            // 
            this.tbl_Fee_Define_MasterBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_Fee_Define_MasterBindingNavigator.BindingSource = this.tbl_Fee_Define_MasterBindingSource;
            this.tbl_Fee_Define_MasterBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_Fee_Define_MasterBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_Fee_Define_MasterBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.tbl_Fee_Define_MasterBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_Fee_Define_MasterBindingNavigatorSaveItem,
            this.toolStripButton_Edit_Data,
            this.btn_Delete});
            this.tbl_Fee_Define_MasterBindingNavigator.Location = new System.Drawing.Point(347, 195);
            this.tbl_Fee_Define_MasterBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_Fee_Define_MasterBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_Fee_Define_MasterBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_Fee_Define_MasterBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_Fee_Define_MasterBindingNavigator.Name = "tbl_Fee_Define_MasterBindingNavigator";
            this.tbl_Fee_Define_MasterBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_Fee_Define_MasterBindingNavigator.Size = new System.Drawing.Size(427, 25);
            this.tbl_Fee_Define_MasterBindingNavigator.TabIndex = 0;
            this.tbl_Fee_Define_MasterBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(69, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_Fee_Define_MasterBindingNavigatorSaveItem
            // 
            this.tbl_Fee_Define_MasterBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_Fee_Define_MasterBindingNavigatorSaveItem.Image")));
            this.tbl_Fee_Define_MasterBindingNavigatorSaveItem.Name = "tbl_Fee_Define_MasterBindingNavigatorSaveItem";
            this.tbl_Fee_Define_MasterBindingNavigatorSaveItem.Size = new System.Drawing.Size(77, 22);
            this.tbl_Fee_Define_MasterBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_Fee_Define_MasterBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_Fee_Define_MasterBindingNavigatorSaveItem_Click);
            // 
            // toolStripButton_Edit_Data
            // 
            this.toolStripButton_Edit_Data.Image = global::GeneralSchool.Properties.Resources.edit;
            this.toolStripButton_Edit_Data.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_Edit_Data.Name = "toolStripButton_Edit_Data";
            this.toolStripButton_Edit_Data.Size = new System.Drawing.Size(71, 22);
            this.toolStripButton_Edit_Data.Text = "Edit Data";
            this.toolStripButton_Edit_Data.Click += new System.EventHandler(this.toolStripButton_Edit_Data_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Enabled = false;
            this.btn_Delete.Image = ((System.Drawing.Image)(resources.GetObject("btn_Delete.Image")));
            this.btn_Delete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(109, 22);
            this.btn_Delete.Text = "Delete Fee Detail";
            this.btn_Delete.Visible = false;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // fee_Define_IDTextBox
            // 
            this.fee_Define_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Fee_Define_MasterBindingSource, "Fee_Define_ID", true));
            this.fee_Define_IDTextBox.Enabled = false;
            this.fee_Define_IDTextBox.Location = new System.Drawing.Point(96, 23);
            this.fee_Define_IDTextBox.Name = "fee_Define_IDTextBox";
            this.fee_Define_IDTextBox.ReadOnly = true;
            this.fee_Define_IDTextBox.Size = new System.Drawing.Size(40, 20);
            this.fee_Define_IDTextBox.TabIndex = 2;
            // 
            // tbl_Fee_Define_DetailBindingSource
            // 
            this.tbl_Fee_Define_DetailBindingSource.DataMember = "tbl_Fee_Define_Mastertbl_Fee_Define_Detail";
            this.tbl_Fee_Define_DetailBindingSource.DataSource = this.tbl_Fee_Define_MasterBindingSource;
            // 
            // tbl_Fee_Define_DetailTableAdapter
            // 
            this.tbl_Fee_Define_DetailTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_Fee_Define_DetailDataGridView
            // 
            this.tbl_Fee_Define_DetailDataGridView.AllowUserToAddRows = false;
            this.tbl_Fee_Define_DetailDataGridView.AllowUserToDeleteRows = false;
            this.tbl_Fee_Define_DetailDataGridView.AllowUserToResizeColumns = false;
            this.tbl_Fee_Define_DetailDataGridView.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tbl_Fee_Define_DetailDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.tbl_Fee_Define_DetailDataGridView.AutoGenerateColumns = false;
            this.tbl_Fee_Define_DetailDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.tbl_Fee_Define_DetailDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.feeDefineDetailIDDataGridViewTextBoxColumn,
            this.feeDefineIDDataGridViewTextBoxColumn,
            this.feeTypeIDDataGridViewComboBoxColumn,
            this.feeAmountDataGridViewTextBoxColumn,
            this.feeMonthDataGridViewComboBoxColumn});
            this.tbl_Fee_Define_DetailDataGridView.DataSource = this.tbl_Fee_Define_DetailBindingSource;
            this.tbl_Fee_Define_DetailDataGridView.Location = new System.Drawing.Point(347, 229);
            this.tbl_Fee_Define_DetailDataGridView.Name = "tbl_Fee_Define_DetailDataGridView";
            this.tbl_Fee_Define_DetailDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.tbl_Fee_Define_DetailDataGridView.Size = new System.Drawing.Size(549, 405);
            this.tbl_Fee_Define_DetailDataGridView.TabIndex = 7;
            // 
            // feeDefineDetailIDDataGridViewTextBoxColumn
            // 
            this.feeDefineDetailIDDataGridViewTextBoxColumn.DataPropertyName = "Fee_Define_Detail_ID";
            this.feeDefineDetailIDDataGridViewTextBoxColumn.HeaderText = "Detail ID";
            this.feeDefineDetailIDDataGridViewTextBoxColumn.Name = "feeDefineDetailIDDataGridViewTextBoxColumn";
            // 
            // feeDefineIDDataGridViewTextBoxColumn
            // 
            this.feeDefineIDDataGridViewTextBoxColumn.DataPropertyName = "Fee_Define_ID";
            this.feeDefineIDDataGridViewTextBoxColumn.HeaderText = "Fee Define ID";
            this.feeDefineIDDataGridViewTextBoxColumn.Name = "feeDefineIDDataGridViewTextBoxColumn";
            // 
            // feeTypeIDDataGridViewComboBoxColumn
            // 
            this.feeTypeIDDataGridViewComboBoxColumn.DataPropertyName = "Fee_Type_ID";
            this.feeTypeIDDataGridViewComboBoxColumn.DataSource = this.viewFeeTypeBindingSource;
            this.feeTypeIDDataGridViewComboBoxColumn.DisplayMember = "Fee_Type";
            this.feeTypeIDDataGridViewComboBoxColumn.HeaderText = "Fee Type";
            this.feeTypeIDDataGridViewComboBoxColumn.Name = "feeTypeIDDataGridViewComboBoxColumn";
            this.feeTypeIDDataGridViewComboBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.feeTypeIDDataGridViewComboBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.feeTypeIDDataGridViewComboBoxColumn.ValueMember = "Fee_Type_ID";
            // 
            // viewFeeTypeBindingSource
            // 
            this.viewFeeTypeBindingSource.DataMember = "View_FeeType";
            this.viewFeeTypeBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // feeAmountDataGridViewTextBoxColumn
            // 
            this.feeAmountDataGridViewTextBoxColumn.DataPropertyName = "Fee_Amount";
            this.feeAmountDataGridViewTextBoxColumn.HeaderText = "Fee Amount";
            this.feeAmountDataGridViewTextBoxColumn.Name = "feeAmountDataGridViewTextBoxColumn";
            // 
            // feeMonthDataGridViewComboBoxColumn
            // 
            this.feeMonthDataGridViewComboBoxColumn.DataPropertyName = "Fee_Month";
            this.feeMonthDataGridViewComboBoxColumn.HeaderText = "Fee Month";
            this.feeMonthDataGridViewComboBoxColumn.Items.AddRange(new object[] {
            "Selected",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
            "January",
            "February",
            "March"});
            this.feeMonthDataGridViewComboBoxColumn.Name = "feeMonthDataGridViewComboBoxColumn";
            this.feeMonthDataGridViewComboBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.feeMonthDataGridViewComboBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // tblFeeTypeBindingSource
            // 
            this.tblFeeTypeBindingSource.DataMember = "tbl_Fee_Type";
            this.tblFeeTypeBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // session_IDTextBox
            // 
            this.session_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tbl_Fee_Define_MasterBindingSource, "Session_ID", true));
            this.session_IDTextBox.DataSource = this.tblSessionBindingSource;
            this.session_IDTextBox.DisplayMember = "Session_Desc";
            this.session_IDTextBox.FormattingEnabled = true;
            this.session_IDTextBox.Location = new System.Drawing.Point(96, 49);
            this.session_IDTextBox.Name = "session_IDTextBox";
            this.session_IDTextBox.Size = new System.Drawing.Size(121, 21);
            this.session_IDTextBox.TabIndex = 8;
            this.session_IDTextBox.ValueMember = "Session_ID";
            // 
            // tblSessionBindingSource
            // 
            this.tblSessionBindingSource.DataMember = "tbl_Session";
            this.tblSessionBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // class_IDTextBox
            // 
            this.class_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tbl_Fee_Define_MasterBindingSource, "Class_ID", true));
            this.class_IDTextBox.DataSource = this.tblClassBindingSource;
            this.class_IDTextBox.DisplayMember = "Class_Desc";
            this.class_IDTextBox.FormattingEnabled = true;
            this.class_IDTextBox.Location = new System.Drawing.Point(96, 74);
            this.class_IDTextBox.Name = "class_IDTextBox";
            this.class_IDTextBox.Size = new System.Drawing.Size(121, 21);
            this.class_IDTextBox.TabIndex = 9;
            this.class_IDTextBox.ValueMember = "Class_ID";
            // 
            // tblClassBindingSource
            // 
            this.tblClassBindingSource.DataMember = "tbl_Class";
            this.tblClassBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tbl_SessionTableAdapter
            // 
            this.tbl_SessionTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_ClassTableAdapter
            // 
            this.tbl_ClassTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_Fee_TypeTableAdapter
            // 
            this.tbl_Fee_TypeTableAdapter.ClearBeforeFill = true;
            // 
            // feeCodeDataGridViewTextBoxColumn
            // 
            this.feeCodeDataGridViewTextBoxColumn.DataPropertyName = "Fee_Code";
            this.feeCodeDataGridViewTextBoxColumn.HeaderText = "Fee_Code";
            this.feeCodeDataGridViewTextBoxColumn.Name = "feeCodeDataGridViewTextBoxColumn";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.CheckOnClick = true;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
            "January",
            "February",
            "March"});
            this.checkedListBox1.Location = new System.Drawing.Point(11, 19);
            this.checkedListBox1.MultiColumn = true;
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(248, 94);
            this.checkedListBox1.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_Select_DeSelect);
            this.groupBox1.Controls.Add(this.checkedListBox1);
            this.groupBox1.Location = new System.Drawing.Point(7, 80);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(265, 163);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Month";
            // 
            // btn_Select_DeSelect
            // 
            this.btn_Select_DeSelect.Image = global::GeneralSchool.Properties.Resources.check_btn;
            this.btn_Select_DeSelect.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Select_DeSelect.Location = new System.Drawing.Point(11, 124);
            this.btn_Select_DeSelect.Name = "btn_Select_DeSelect";
            this.btn_Select_DeSelect.Size = new System.Drawing.Size(85, 27);
            this.btn_Select_DeSelect.TabIndex = 16;
            this.btn_Select_DeSelect.Text = "Select All";
            this.btn_Select_DeSelect.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Select_DeSelect.UseVisualStyleBackColor = true;
            this.btn_Select_DeSelect.Click += new System.EventHandler(this.btn_Select_DeSelect_Click);
            // 
            // btn_Insert_Tution_Fee
            // 
            this.btn_Insert_Tution_Fee.Image = global::GeneralSchool.Properties.Resources.enable_add;
            this.btn_Insert_Tution_Fee.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Insert_Tution_Fee.Location = new System.Drawing.Point(18, 256);
            this.btn_Insert_Tution_Fee.Name = "btn_Insert_Tution_Fee";
            this.btn_Insert_Tution_Fee.Size = new System.Drawing.Size(85, 32);
            this.btn_Insert_Tution_Fee.TabIndex = 11;
            this.btn_Insert_Tution_Fee.Text = "Add Fee";
            this.btn_Insert_Tution_Fee.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Insert_Tution_Fee.UseVisualStyleBackColor = true;
            this.btn_Insert_Tution_Fee.Click += new System.EventHandler(this.btn_Insert_Tution_Fee_Click);
            // 
            // cmb_FeeType
            // 
            this.cmb_FeeType.DataSource = this.tblFeeTypeBindingSource;
            this.cmb_FeeType.DisplayMember = "Fee_Type";
            this.cmb_FeeType.FormattingEnabled = true;
            this.cmb_FeeType.Location = new System.Drawing.Point(78, 19);
            this.cmb_FeeType.Name = "cmb_FeeType";
            this.cmb_FeeType.Size = new System.Drawing.Size(108, 21);
            this.cmb_FeeType.TabIndex = 12;
            this.cmb_FeeType.ValueMember = "Fee_Type_ID";
            this.cmb_FeeType.SelectedIndexChanged += new System.EventHandler(this.cmb_FeeType_SelectedIndexChanged);
            // 
            // amountTextBox
            // 
            this.amountTextBox.Location = new System.Drawing.Point(78, 47);
            this.amountTextBox.Mask = "00000";
            this.amountTextBox.Name = "amountTextBox";
            this.amountTextBox.Size = new System.Drawing.Size(48, 20);
            this.amountTextBox.TabIndex = 13;
            this.amountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Fee Type:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Fee Amount:";
            // 
            // groupBox_FeeDetail
            // 
            this.groupBox_FeeDetail.Controls.Add(this.groupBox1);
            this.groupBox_FeeDetail.Controls.Add(this.label2);
            this.groupBox_FeeDetail.Controls.Add(this.btn_Insert_Tution_Fee);
            this.groupBox_FeeDetail.Controls.Add(this.cmb_FeeType);
            this.groupBox_FeeDetail.Controls.Add(this.amountTextBox);
            this.groupBox_FeeDetail.Controls.Add(this.label1);
            this.groupBox_FeeDetail.Location = new System.Drawing.Point(37, 195);
            this.groupBox_FeeDetail.Name = "groupBox_FeeDetail";
            this.groupBox_FeeDetail.Size = new System.Drawing.Size(294, 301);
            this.groupBox_FeeDetail.TabIndex = 16;
            this.groupBox_FeeDetail.TabStop = false;
            this.groupBox_FeeDetail.Text = "Add Fee Detail";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button_EnabaleAddEdit);
            this.groupBox3.Controls.Add(this.session_IDTextBox);
            this.groupBox3.Controls.Add(class_IDLabel);
            this.groupBox3.Controls.Add(this.class_IDTextBox);
            this.groupBox3.Controls.Add(session_IDLabel);
            this.groupBox3.Controls.Add(this.fee_Define_IDTextBox);
            this.groupBox3.Controls.Add(fee_Define_IDLabel);
            this.groupBox3.Location = new System.Drawing.Point(37, 86);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(410, 103);
            this.groupBox3.TabIndex = 17;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Add Session Class";
            // 
            // button_EnabaleAddEdit
            // 
            this.button_EnabaleAddEdit.Image = global::GeneralSchool.Properties.Resources.enable_add_edit;
            this.button_EnabaleAddEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_EnabaleAddEdit.Location = new System.Drawing.Point(264, 19);
            this.button_EnabaleAddEdit.Name = "button_EnabaleAddEdit";
            this.button_EnabaleAddEdit.Size = new System.Drawing.Size(131, 42);
            this.button_EnabaleAddEdit.TabIndex = 10;
            this.button_EnabaleAddEdit.Text = "Enable Add Edit";
            this.button_EnabaleAddEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_EnabaleAddEdit.UseVisualStyleBackColor = true;
            this.button_EnabaleAddEdit.Click += new System.EventHandler(this.button_EnabaleAddEdit_Click);
            // 
            // view_FeeTypeTableAdapter
            // 
            this.view_FeeTypeTableAdapter.ClearBeforeFill = true;
            // 
            // Form_Class_Fee_Define
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(920, 646);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox_FeeDetail);
            this.Controls.Add(this.tbl_Fee_Define_DetailDataGridView);
            this.Controls.Add(this.tbl_Fee_Define_MasterBindingNavigator);
            this.Name = "Form_Class_Fee_Define";
            this.Text = "Class Fee Define";
            this.Load += new System.EventHandler(this.Form_Class_Fee_Define_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Class_Fee_Define_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Define_MasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Define_MasterBindingNavigator)).EndInit();
            this.tbl_Fee_Define_MasterBindingNavigator.ResumeLayout(false);
            this.tbl_Fee_Define_MasterBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Define_DetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Define_DetailDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewFeeTypeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblFeeTypeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSessionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblClassBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox_FeeDetail.ResumeLayout(false);
            this.groupBox_FeeDetail.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tbl_Fee_Define_MasterBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Fee_Define_MasterTableAdapter tbl_Fee_Define_MasterTableAdapter;
        private System.Windows.Forms.BindingNavigator tbl_Fee_Define_MasterBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_Fee_Define_MasterBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox fee_Define_IDTextBox;
        private System.Windows.Forms.BindingSource tbl_Fee_Define_DetailBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Fee_Define_DetailTableAdapter tbl_Fee_Define_DetailTableAdapter;
        private System.Windows.Forms.DataGridView tbl_Fee_Define_DetailDataGridView;
        private System.Windows.Forms.ComboBox session_IDTextBox;
        private System.Windows.Forms.ComboBox class_IDTextBox;
        private System.Windows.Forms.BindingSource tblSessionBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SessionTableAdapter tbl_SessionTableAdapter;
        private System.Windows.Forms.BindingSource tblClassBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ClassTableAdapter tbl_ClassTableAdapter;
        private System.Windows.Forms.BindingSource tblFeeTypeBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Fee_TypeTableAdapter tbl_Fee_TypeTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn feeCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripButton toolStripButton_Edit_Data;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_Insert_Tution_Fee;
        private System.Windows.Forms.ComboBox cmb_FeeType;
        private System.Windows.Forms.MaskedTextBox amountTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox_FeeDetail;
        private System.Windows.Forms.Button btn_Select_DeSelect;
        private System.Windows.Forms.ToolStripButton btn_Delete;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button_EnabaleAddEdit;
        private System.Windows.Forms.BindingSource viewFeeTypeBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.View_FeeTypeTableAdapter view_FeeTypeTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn feeDefineDetailIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn feeDefineIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn feeTypeIDDataGridViewComboBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn feeAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn feeMonthDataGridViewComboBoxColumn;
    }
}