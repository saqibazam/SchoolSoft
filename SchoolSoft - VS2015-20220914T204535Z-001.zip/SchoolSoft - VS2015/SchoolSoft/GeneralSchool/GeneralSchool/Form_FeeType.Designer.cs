namespace GeneralSchool
{
    partial class Form_FeeType
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label fee_Type_IDLabel;
            System.Windows.Forms.Label fee_TypeLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_FeeType));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_EnableAddEdit = new System.Windows.Forms.Button();
            this.fee_Type_IDTextBox = new System.Windows.Forms.TextBox();
            this.tbl_Fee_TypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.fee_TypeTextBox = new System.Windows.Forms.TextBox();
            this.tbl_Fee_TypeTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Fee_TypeTableAdapter();
            this.tbl_Fee_TypeBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_Fee_TypeBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.button_EditData = new System.Windows.Forms.ToolStripButton();
            this.tbl_Fee_TypeDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            fee_Type_IDLabel = new System.Windows.Forms.Label();
            fee_TypeLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_TypeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_TypeBindingNavigator)).BeginInit();
            this.tbl_Fee_TypeBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_TypeDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // fee_Type_IDLabel
            // 
            fee_Type_IDLabel.AutoSize = true;
            fee_Type_IDLabel.Location = new System.Drawing.Point(14, 47);
            fee_Type_IDLabel.Name = "fee_Type_IDLabel";
            fee_Type_IDLabel.Size = new System.Drawing.Size(69, 13);
            fee_Type_IDLabel.TabIndex = 2;
            fee_Type_IDLabel.Text = "Fee Type ID:";
            // 
            // fee_TypeLabel
            // 
            fee_TypeLabel.AutoSize = true;
            fee_TypeLabel.Location = new System.Drawing.Point(14, 88);
            fee_TypeLabel.Name = "fee_TypeLabel";
            fee_TypeLabel.Size = new System.Drawing.Size(55, 13);
            fee_TypeLabel.TabIndex = 4;
            fee_TypeLabel.Text = "Fee Type:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_EnableAddEdit);
            this.groupBox1.Controls.Add(fee_Type_IDLabel);
            this.groupBox1.Controls.Add(this.fee_Type_IDTextBox);
            this.groupBox1.Controls.Add(this.fee_TypeTextBox);
            this.groupBox1.Controls.Add(fee_TypeLabel);
            this.groupBox1.Location = new System.Drawing.Point(31, 131);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(427, 128);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add Fee Type";
            // 
            // button_EnableAddEdit
            // 
            this.button_EnableAddEdit.Image = global::GeneralSchool.Properties.Resources.enable_add_edit;
            this.button_EnableAddEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_EnableAddEdit.Location = new System.Drawing.Point(278, 25);
            this.button_EnableAddEdit.Name = "button_EnableAddEdit";
            this.button_EnableAddEdit.Size = new System.Drawing.Size(131, 42);
            this.button_EnableAddEdit.TabIndex = 6;
            this.button_EnableAddEdit.Text = "Enable Add Edit";
            this.button_EnableAddEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_EnableAddEdit.UseVisualStyleBackColor = true;
            this.button_EnableAddEdit.Click += new System.EventHandler(this.button_EnableAddEdit_Click);
            // 
            // fee_Type_IDTextBox
            // 
            this.fee_Type_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Fee_TypeBindingSource, "Fee_Type_ID", true));
            this.fee_Type_IDTextBox.Enabled = false;
            this.fee_Type_IDTextBox.Location = new System.Drawing.Point(89, 44);
            this.fee_Type_IDTextBox.Name = "fee_Type_IDTextBox";
            this.fee_Type_IDTextBox.Size = new System.Drawing.Size(47, 20);
            this.fee_Type_IDTextBox.TabIndex = 3;
            // 
            // tbl_Fee_TypeBindingSource
            // 
            this.tbl_Fee_TypeBindingSource.DataMember = "tbl_Fee_Type";
            this.tbl_Fee_TypeBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fee_TypeTextBox
            // 
            this.fee_TypeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Fee_TypeBindingSource, "Fee_Type", true));
            this.fee_TypeTextBox.Location = new System.Drawing.Point(89, 85);
            this.fee_TypeTextBox.Name = "fee_TypeTextBox";
            this.fee_TypeTextBox.Size = new System.Drawing.Size(244, 20);
            this.fee_TypeTextBox.TabIndex = 5;
            // 
            // tbl_Fee_TypeTableAdapter
            // 
            this.tbl_Fee_TypeTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_Fee_TypeBindingNavigator
            // 
            this.tbl_Fee_TypeBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_Fee_TypeBindingNavigator.BindingSource = this.tbl_Fee_TypeBindingSource;
            this.tbl_Fee_TypeBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_Fee_TypeBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_Fee_TypeBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.tbl_Fee_TypeBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_Fee_TypeBindingNavigatorSaveItem,
            this.button_EditData});
            this.tbl_Fee_TypeBindingNavigator.Location = new System.Drawing.Point(31, 262);
            this.tbl_Fee_TypeBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_Fee_TypeBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_Fee_TypeBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_Fee_TypeBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_Fee_TypeBindingNavigator.Name = "tbl_Fee_TypeBindingNavigator";
            this.tbl_Fee_TypeBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_Fee_TypeBindingNavigator.Size = new System.Drawing.Size(427, 25);
            this.tbl_Fee_TypeBindingNavigator.TabIndex = 1;
            this.tbl_Fee_TypeBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(69, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Enabled = false;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Enabled = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.ReadOnly = true;
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_Fee_TypeBindingNavigatorSaveItem
            // 
            this.tbl_Fee_TypeBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_Fee_TypeBindingNavigatorSaveItem.Image")));
            this.tbl_Fee_TypeBindingNavigatorSaveItem.Name = "tbl_Fee_TypeBindingNavigatorSaveItem";
            this.tbl_Fee_TypeBindingNavigatorSaveItem.Size = new System.Drawing.Size(77, 22);
            this.tbl_Fee_TypeBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_Fee_TypeBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_Fee_TypeBindingNavigatorSaveItem_Click);
            // 
            // button_EditData
            // 
            this.button_EditData.Image = global::GeneralSchool.Properties.Resources.edit;
            this.button_EditData.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.button_EditData.Name = "button_EditData";
            this.button_EditData.Size = new System.Drawing.Size(71, 22);
            this.button_EditData.Text = "Edit Data";
            this.button_EditData.Click += new System.EventHandler(this.button_EditData_Click);
            // 
            // tbl_Fee_TypeDataGridView
            // 
            this.tbl_Fee_TypeDataGridView.AllowUserToAddRows = false;
            this.tbl_Fee_TypeDataGridView.AllowUserToDeleteRows = false;
            this.tbl_Fee_TypeDataGridView.AllowUserToResizeColumns = false;
            this.tbl_Fee_TypeDataGridView.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tbl_Fee_TypeDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.tbl_Fee_TypeDataGridView.AutoGenerateColumns = false;
            this.tbl_Fee_TypeDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.tbl_Fee_TypeDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.tbl_Fee_TypeDataGridView.DataSource = this.tbl_Fee_TypeBindingSource;
            this.tbl_Fee_TypeDataGridView.Location = new System.Drawing.Point(31, 300);
            this.tbl_Fee_TypeDataGridView.Name = "tbl_Fee_TypeDataGridView";
            this.tbl_Fee_TypeDataGridView.ReadOnly = true;
            this.tbl_Fee_TypeDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.tbl_Fee_TypeDataGridView.Size = new System.Drawing.Size(427, 170);
            this.tbl_Fee_TypeDataGridView.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Fee_Type_ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "Fee Type ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Fee_Type";
            this.dataGridViewTextBoxColumn2.HeaderText = "Fee Type";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 250;
            // 
            // Form_FeeType
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 530);
            this.Controls.Add(this.tbl_Fee_TypeDataGridView);
            this.Controls.Add(this.tbl_Fee_TypeBindingNavigator);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form_FeeType";
            this.Text = "Add Fee Type";
            this.Load += new System.EventHandler(this.Form_FeeType_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_FeeType_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_TypeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_TypeBindingNavigator)).EndInit();
            this.tbl_Fee_TypeBindingNavigator.ResumeLayout(false);
            this.tbl_Fee_TypeBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_TypeDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tbl_Fee_TypeBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Fee_TypeTableAdapter tbl_Fee_TypeTableAdapter;
        private System.Windows.Forms.BindingNavigator tbl_Fee_TypeBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_Fee_TypeBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox fee_Type_IDTextBox;
        private System.Windows.Forms.TextBox fee_TypeTextBox;
        private System.Windows.Forms.DataGridView tbl_Fee_TypeDataGridView;
        private System.Windows.Forms.ToolStripButton button_EditData;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Button button_EnableAddEdit;
    }
}