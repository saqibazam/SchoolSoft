namespace GeneralSchool
{
    partial class Form_Section
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label section_IDLabel;
            System.Windows.Forms.Label section_DescLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Section));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.tbl_SectionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_SectionTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SectionTableAdapter();
            this.tbl_SectionBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_SectionBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.tbl_SectionDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.section_IDTextBox = new System.Windows.Forms.TextBox();
            this.section_DescTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_EnableAdd = new System.Windows.Forms.Button();
            section_IDLabel = new System.Windows.Forms.Label();
            section_DescLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SectionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SectionBindingNavigator)).BeginInit();
            this.tbl_SectionBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SectionDataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // section_IDLabel
            // 
            section_IDLabel.AutoSize = true;
            section_IDLabel.Location = new System.Drawing.Point(6, 29);
            section_IDLabel.Name = "section_IDLabel";
            section_IDLabel.Size = new System.Drawing.Size(60, 13);
            section_IDLabel.TabIndex = 2;
            section_IDLabel.Text = "Section ID:";
            // 
            // section_DescLabel
            // 
            section_DescLabel.AutoSize = true;
            section_DescLabel.Location = new System.Drawing.Point(6, 55);
            section_DescLabel.Name = "section_DescLabel";
            section_DescLabel.Size = new System.Drawing.Size(74, 13);
            section_DescLabel.TabIndex = 4;
            section_DescLabel.Text = "Section Desc:";
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_SectionBindingSource
            // 
            this.tbl_SectionBindingSource.DataMember = "tbl_Section";
            this.tbl_SectionBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tbl_SectionTableAdapter
            // 
            this.tbl_SectionTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_SectionBindingNavigator
            // 
            this.tbl_SectionBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_SectionBindingNavigator.BindingSource = this.tbl_SectionBindingSource;
            this.tbl_SectionBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_SectionBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_SectionBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.tbl_SectionBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_SectionBindingNavigatorSaveItem});
            this.tbl_SectionBindingNavigator.Location = new System.Drawing.Point(37, 194);
            this.tbl_SectionBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_SectionBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_SectionBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_SectionBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_SectionBindingNavigator.Name = "tbl_SectionBindingNavigator";
            this.tbl_SectionBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_SectionBindingNavigator.Size = new System.Drawing.Size(356, 25);
            this.tbl_SectionBindingNavigator.TabIndex = 0;
            this.tbl_SectionBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(69, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.ReadOnly = true;
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_SectionBindingNavigatorSaveItem
            // 
            this.tbl_SectionBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_SectionBindingNavigatorSaveItem.Image")));
            this.tbl_SectionBindingNavigatorSaveItem.Name = "tbl_SectionBindingNavigatorSaveItem";
            this.tbl_SectionBindingNavigatorSaveItem.Size = new System.Drawing.Size(77, 22);
            this.tbl_SectionBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_SectionBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_SectionBindingNavigatorSaveItem_Click);
            // 
            // tbl_SectionDataGridView
            // 
            this.tbl_SectionDataGridView.AllowUserToAddRows = false;
            this.tbl_SectionDataGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tbl_SectionDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.tbl_SectionDataGridView.AutoGenerateColumns = false;
            this.tbl_SectionDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.tbl_SectionDataGridView.DataSource = this.tbl_SectionBindingSource;
            this.tbl_SectionDataGridView.Location = new System.Drawing.Point(37, 232);
            this.tbl_SectionDataGridView.Name = "tbl_SectionDataGridView";
            this.tbl_SectionDataGridView.ReadOnly = true;
            this.tbl_SectionDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tbl_SectionDataGridView.Size = new System.Drawing.Size(245, 137);
            this.tbl_SectionDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Section_ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "Section ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Section_Desc";
            this.dataGridViewTextBoxColumn2.HeaderText = "Section Desc";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // section_IDTextBox
            // 
            this.section_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SectionBindingSource, "Section_ID", true));
            this.section_IDTextBox.Enabled = false;
            this.section_IDTextBox.Location = new System.Drawing.Point(86, 26);
            this.section_IDTextBox.Name = "section_IDTextBox";
            this.section_IDTextBox.Size = new System.Drawing.Size(40, 20);
            this.section_IDTextBox.TabIndex = 3;
            // 
            // section_DescTextBox
            // 
            this.section_DescTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SectionBindingSource, "Section_Desc", true));
            this.section_DescTextBox.Location = new System.Drawing.Point(86, 52);
            this.section_DescTextBox.Name = "section_DescTextBox";
            this.section_DescTextBox.Size = new System.Drawing.Size(100, 20);
            this.section_DescTextBox.TabIndex = 5;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_EnableAdd);
            this.groupBox1.Controls.Add(section_IDLabel);
            this.groupBox1.Controls.Add(this.section_DescTextBox);
            this.groupBox1.Controls.Add(this.section_IDTextBox);
            this.groupBox1.Controls.Add(section_DescLabel);
            this.groupBox1.Location = new System.Drawing.Point(37, 93);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(356, 88);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add Section";
            // 
            // button_EnableAdd
            // 
            this.button_EnableAdd.Image = global::GeneralSchool.Properties.Resources.enable_add;
            this.button_EnableAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_EnableAdd.Location = new System.Drawing.Point(231, 42);
            this.button_EnableAdd.Name = "button_EnableAdd";
            this.button_EnableAdd.Size = new System.Drawing.Size(99, 32);
            this.button_EnableAdd.TabIndex = 6;
            this.button_EnableAdd.Text = "Enable Add";
            this.button_EnableAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_EnableAdd.UseVisualStyleBackColor = true;
            this.button_EnableAdd.Click += new System.EventHandler(this.button_EnableAdd_Click);
            // 
            // Form_Section
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(781, 446);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tbl_SectionDataGridView);
            this.Controls.Add(this.tbl_SectionBindingNavigator);
            this.Name = "Form_Section";
            this.Text = "Add Section";
            this.Load += new System.EventHandler(this.Form_Section_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Section_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SectionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SectionBindingNavigator)).EndInit();
            this.tbl_SectionBindingNavigator.ResumeLayout(false);
            this.tbl_SectionBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SectionDataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tbl_SectionBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SectionTableAdapter tbl_SectionTableAdapter;
        private System.Windows.Forms.BindingNavigator tbl_SectionBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_SectionBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView tbl_SectionDataGridView;
        private System.Windows.Forms.TextBox section_IDTextBox;
        private System.Windows.Forms.TextBox section_DescTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_EnableAdd;
    }
}