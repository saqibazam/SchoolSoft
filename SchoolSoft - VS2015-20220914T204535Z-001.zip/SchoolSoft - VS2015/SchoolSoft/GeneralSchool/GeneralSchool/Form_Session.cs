using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_Session : Form
    {
        Class_ConnectDB conDb = new Class_ConnectDB();
        public Form_Session()
        {
            InitializeComponent();
        }

        private void tbl_SessionBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.tbl_SessionBindingSource.EndEdit();
                this.tbl_SessionTableAdapter.Update(this.schoolDbDataSet.tbl_Session);
                disableControls();
                bindingNavigatorAddNewItem.Enabled = true;
                tbl_SessionBindingNavigatorSaveItem.Enabled = false;
                toolStripButton_Edit_Data.Enabled = true;
                MessageBox.Show("Record has been saved successfully.....Press OK to continue...", "Record has been saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Convert.ToString(Ex));
            }
        }

        private void Form_Session_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Session' table. You can move, or remove it, as needed.
            this.tbl_SessionTableAdapter.Fill(this.schoolDbDataSet.tbl_Session);
            loadSessionPrgressGV();
            disableControls();
            tbl_SessionBindingNavigatorSaveItem.Enabled = false;

            bindingNavigatorPositionItem.Enabled = false;
            bindingNavigatorAddNewItem.Enabled = false;
            toolStripButton_Edit_Data.Enabled = false;
            disableAddbutton();
        }

        private void Form_Session_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.AddSession = false;
        }

        public void loadSessionPrgressGV()
        {
            string SqlSPS = "SELECT * from tbl_Session_Progress_Status ";

            // Pass connection string to the OledbConnection object
            OleDbConnection OledbConn = new OleDbConnection(conDb.returnConString());

            //Unpaid Fee Voucher Grid View Fill
            OleDbDataAdapter daSPS = new OleDbDataAdapter(SqlSPS, conDb.returnConString());
            DataTable dtSPS = new DataTable();
            daSPS.Fill(dtSPS);
            SPS_bindingSource.DataSource = dtSPS;
            dgv_SessionProgressStatus.DataSource = SPS_bindingSource;
            dgv_SessionProgressStatus.Columns[0].HeaderText = "ID";
            dgv_SessionProgressStatus.Columns[1].HeaderText = "Session ID";
            dgv_SessionProgressStatus.Columns[2].HeaderText = "Session Year";
            //dvg_NotRegisteredStudent.Columns[1].Width = 300;
            dgv_SessionProgressStatus.Columns[3].HeaderText = "Cleared All Students Fee";
            //dvg_NotRegisteredStudent.Columns[2].Width = 300;
            dgv_SessionProgressStatus.Columns[4].HeaderText = "Passed Out Last Class";
            dgv_SessionProgressStatus.Columns[5].HeaderText = "Moved To New Session";
            dgv_SessionProgressStatus.Columns[6].HeaderText = "Moved To New Class";
            dgv_SessionProgressStatus.Columns[7].HeaderText = "Assigned Roll No.";
            dgv_SessionProgressStatus.AutoResizeColumns();
        
        }

        private void btn_AddSession_Click(object sender, EventArgs e)
        {
            int a = int.Parse (conDb .returnSessionID ());
            int b = int.Parse (conDb.returnSPSSessionID());
            string sd = conDb.returnSessionDesc();
            
            if (a == b)
            {
                MessageBox.Show("Can Not Update Session, First Create New Session.", "Can Not Add Session",
                                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else 
            {
                //OleDbCommand cmdIsps = new OleDbCommand("INSERT INTO tbl_Session_Progress_Status (Session_ID, FeeClosingCompleted, PassOutLastClassStudents, MoveAllStudentstoNewSession, MoveAllSuccessfulStudentsToNewClass, AssignRollNoToNewClass) VALUES (" + a + ", " + false  + " , " + false  + ", " + false  + ", " + false  + ", " + false  + " )", conDb.con);
                OleDbCommand cmdIsps = new OleDbCommand("INSERT INTO tbl_Session_Progress_Status (Session_ID, Session_YEar) VALUES (" + a + ", '"+sd+"'   )", conDb.con);
                conDb.con.Open();

                cmdIsps.ExecuteNonQuery();
                conDb.con.Close();
            
            }
            loadSessionPrgressGV();
        }

        private void enableControls()
        { 
        session_DescTextBox.Enabled = true ;
        session_StartDateTimePicker.Enabled = true ;
        session_EndDateTimePicker.Enabled = true;
        }

        private void disableControls()
        {
            session_DescTextBox.Enabled = false ;
            session_StartDateTimePicker.Enabled = false ;
            session_EndDateTimePicker.Enabled = false ;
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            try
            {
                enableControls();
                bindingNavigatorAddNewItem.Enabled = false;
                tbl_SessionBindingNavigatorSaveItem.Enabled = true;
                toolStripButton_Edit_Data.Enabled = false;
                MessageBox.Show("After Save New Session, Click on Update Session Progress Status Button to Update Session Progress Status.......Press OK to continue...", "After Save, Click on Update Session Progress Status Button", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception Ex) { MessageBox.Show(Convert.ToString(Ex)); }
            }

    
        private void disableAddbutton()
        {
            //if (conDb._feeClosed == true && conDb._passOutLastClass == true && conDb._moveToNewSession == true && conDb._moveToNewClass == true && conDb._assignRoll == true)
            if (conDb._feeClosed == true )
            {
                button_EnableAddEdit.Enabled = true;
            }
            else { button_EnableAddEdit.Enabled = false; }
        
        }
        
        

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorPositionItem.Enabled = false;
            bindingNavigatorAddNewItem.Enabled = false;
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorPositionItem.Enabled = false;
            bindingNavigatorAddNewItem.Enabled = false;
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorPositionItem.Enabled = false;
            bindingNavigatorAddNewItem.Enabled = false;
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorPositionItem.Enabled = false;
            bindingNavigatorAddNewItem.Enabled = false;
        }

        private void toolStripButton_Edit_Data_Click(object sender, EventArgs e)
        {
            enableControls();
            bindingNavigatorAddNewItem.Enabled = false;
            tbl_SessionBindingNavigatorSaveItem.Enabled = true;
            toolStripButton_Edit_Data.Enabled = false;
        }
        
        private Form_PasswordDialog _passDlg = new Form_PasswordDialog();
        private Form_Login frmLogin = new Form_Login();
       
        private void button_EnableAddEdit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = _passDlg.ShowDialog(this);
            if ((dialogResult == DialogResult.OK) && (_passDlg.Password == "15March2011915"))
            {
                _passDlg.textBoxPassword.Text = "";
                enableControls();
                bindingNavigatorAddNewItem.Enabled = true;
                toolStripButton_Edit_Data.Enabled = true;
            }
            else if ((dialogResult == DialogResult.OK) && (_passDlg.Password == frmLogin.checkUserPass("Admin")))
            {
                _passDlg.textBoxPassword.Text = "";
                enableControls();
                bindingNavigatorAddNewItem.Enabled = true;
                toolStripButton_Edit_Data.Enabled = true;
            }
            else if (dialogResult == DialogResult.Cancel)
            { }
            else
            {
                _passDlg.textBoxPassword.Text = "";
                MessageBox.Show("Invalid Password.....Press OK to continue...", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }







    }
}