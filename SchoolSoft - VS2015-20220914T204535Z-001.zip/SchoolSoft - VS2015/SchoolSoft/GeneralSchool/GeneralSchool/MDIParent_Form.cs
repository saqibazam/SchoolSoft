using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb ;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
//using System.Configuration;

namespace GeneralSchool
{
    public partial class MDIParent_Form : Form
    {
        
        //Create a conDb Object
        Class_ConnectDB conDb = new Class_ConnectDB();
        private int childFormNumber = 0;
        
        
        public MDIParent_Form()
        {
            InitializeComponent();
        }
        public static bool Login = false;
        public static bool School = false;
        public static bool Class = false;
        public static bool Section = false;
        public static bool ClassDefine = false;
        public static bool ClassFeeDefine = false;
        public static bool NewStudent = false;
        public static bool RegisterStudent = false;
        public static bool GeneralStudent = false;
        public static bool StudentMoveNewSession = false;
        public static bool AddSession = false;
        public static bool AboutGS = false;
        public static bool BackupRestoreData = false;
        public static bool FeeReports = false;
        public static bool StudentInfoReports = false;
        public static bool AddFeeType = false;
        
        
        private void ShowItem(Form frmForm)
        {
            try
            {
                CloseChildForms();
                this.IsMdiContainer = true;
                // Make it a child of this MDI form before showing it.
                frmForm.MdiParent = this;
                //frmForm.Dock = DockStyle.Fill; //   ' DockStyle.None     ''
                frmForm.TopMost = true;
                frmForm.WindowState = FormWindowState.Maximized;
                //frmForm.Text = "sub window";
                //pnlContainer.Visible = false;
                //Timer1.Enabled = pnlContainer.Visible;
                frmForm.BringToFront();
                frmForm.Left = 0;
                frmForm.Top = 0;
                frmForm.Show();
                groupBox_Login.SendToBack();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        public void CloseChildForms()
        {
            //' *** iterate thru child forms ***

            for (int x = 0; x <= this.MdiChildren.Length - 5; x++)
            {
                //' Create a temporary instance of a child form.
                Form tempChild = (Form)this.MdiChildren[x];

                tempChild.Close();
                tempChild.Dispose();
                
            }
            
        }

        private void MDIParent_Form_Load(object sender, EventArgs e)
        {
            string currentDate;
            currentDate = string.Format("{0:dd-MMM-yyyy}", DateTime.Now );

            string expireDate;
            expireDate = string.Format("{0:dd-MMM-yyyy}", Convert.ToDateTime(conDb._expireOn));

            string updateDate;
            updateDate = string.Format("{0:dd-MMM-yyyy}", Convert.ToDateTime(conDb._updatedon));

            //Show School Data
            textBoxHeader.Text = conDb._schoolName + "\r\n" + conDb._address + ", Tel: " + conDb._phone +
            "\r\n \r\n Session: " + conDb.returnSessionDesc();
            //textBoxHeader.ForeColor = Color.White;
            //textBoxHeader.BackColor = Color.Blue;


            textBox_SoftwareDetail.Text = conDb._softwareName + "\r\n" + conDb._title + " " + conDb._version + "\r\n Update On: " + updateDate +
                   "\r\n \r\n Design & Developed By: \r\n " + conDb._companyName + "\r\n Contact: " + conDb._contact + "\r\n Email: " + conDb._email + " \r\n Website: " + conDb._website;
            //"\r\n Expire On: " + expireDate + 

            //lblMdi_SessionID.Text = conDb.returnSessionID();
            //lblMdi_SessionDesc.Text = conDb.returnSessionDesc();

            //lblMdi_SchoolName.Text = conDb._schoolName;
            //lblMdi_Address.Text = conDb._address;
            //lblMdi_Phone.Text = conDb._phone ;

            cmbUserName.Text = "Admin";
            logoutPrivileges();
            toolStripButton_LogOut.Enabled = false;
            groupBox_Login.BringToFront();
            label_DateTime.Text = currentDate;
           
            //ToggleConfigEncryption("C:\\Program Files\\General Solutions\\SetupGSchool\\GeneralSchool.exe");
           
            
            }

        //static void ToggleConfigEncryption(string exeConfigName)
        //{
        //    // Takes the executable file name without the
        //    // .config extension.
        //    try
        //    {
        //        // Open the configuration file and retrieve 
        //        // the connectionStrings section.
        //        Configuration config = ConfigurationManager.
        //            OpenExeConfiguration(exeConfigName);

        //        ConnectionStringsSection section =
        //            config.GetSection("connectionStrings")
        //            as ConnectionStringsSection;

        //        if (section.SectionInformation.IsProtected)
        //        {
        //            // Remove encryption.
        //            section.SectionInformation.UnprotectSection();
        //        }
        //        else
        //        {
        //            // Encrypt the section.
        //            section.SectionInformation.ProtectSection(
        //                "DataProtectionConfigurationProvider");
        //        }
        //        // Save the current configuration.
        //        config.Save();

        //        //Console.WriteLine("Protected={0}",
        //        //    section.SectionInformation.IsProtected);
        //        //MessageBox.Show("Protected={0}" + section.SectionInformation.IsProtected );
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //}
       

        private void School_toolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
                // TODO: Add code here to open the file.
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
                // TODO: Add code here to save the current contents of the form to a file.
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // TODO: Use System.Windows.Forms.Clipboard to insert the selected text or images into the clipboard
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // TODO: Use System.Windows.Forms.Clipboard to insert the selected text or images into the clipboard
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // TODO: Use System.Windows.Forms.Clipboard.GetText() or System.Windows.Forms.GetData to retrieve information from the clipboard.
        }

        private void ToolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolStrip.Visible = toolBarToolStripMenuItem.Checked;
        }

        private void StatusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            statusStrip.Visible = statusBarToolStripMenuItem.Checked;
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
            
        }
        private void ShowNewForm(object sender, EventArgs e)
        {
            // Create a new instance of the child form.
            Form childForm = new Form();
            // Make it a child of this MDI form before showing it.
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }
       

        private void addNewStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (NewStudent == false)
            {
                Form_New_Student_Info frmStdInfo = new Form_New_Student_Info();
                ShowItem(frmStdInfo);
                NewStudent = true;
            }
        
        }
       
        private void registerNewStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (RegisterStudent == false)
            {
                Form_NewStudent_Registration frmStdReg = new Form_NewStudent_Registration();
                ShowItem(frmStdReg);
                RegisterStudent = true;
            }
            
            
            //Form_NewStudent_Registration frmStdReg = new Form_NewStudent_Registration();
            //frmStdReg.MdiParent = this;
            //frmStdReg.Text = "New Student Registration Form - " + this.MdiChildren.Length.ToString();
            //frmStdReg.Show();
        }

        private void generalStudentInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (GeneralStudent == false)
            {
                Form_General_Student_Info frmGenStd = new Form_General_Student_Info();
                ShowItem(frmGenStd);
                GeneralStudent = true;
            }
           
        }
       


        //public static bool GeneralStudent = false;
        private void menuStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
       

       
        

        private void classFeeDefineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ClassFeeDefine == false)
            {
                Form_Class_Fee_Define frmClFeD = new Form_Class_Fee_Define();
                ShowItem(frmClFeD);
                ClassFeeDefine = true;
            }

        }
      
        private void addClassToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Class == false)
            {
                Form_Class frmClass = new Form_Class();
                ShowItem(frmClass);
                Class = true;
            }
           
         
        }

        private void addSectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Section == false)
            {
                Form_Section frmSection = new Form_Section();
                ShowItem(frmSection);
                Section = true;
            }
            
            
         
        }
        
        private void classDefineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ClassDefine == false)
            {
                Form_Class_Section_Shift_Medium_Define frmClsDefine = new Form_Class_Section_Shift_Medium_Define();
                ShowItem(frmClsDefine);
                ClassDefine = true;
            }
            
            
        }
        //private void versionExpire()
        //{
        //    //DateTime.MaxValue();
        //    int d1 = Convert.ToDateTime(label_DateTime.Text).Day ;
           

        //}
       

        private void textBox_Password_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                Form_Login frmLogin = new Form_Login();
                textBox_SoftwareDetail.SendToBack();
               
                if   ( (cmbUserName .Text == "Guest" ) &&  ((frmLogin.checkUserPass("Guest") == textBox_Password.Text)))
                {
                    // Call Guest Function
                    guestPrivileges();
                   
                   
                }
              else if ((cmbUserName.Text == "Operator") && ((frmLogin.checkUserPass("Operator") == textBox_Password.Text)))
                {
                    
                   



                    //if (Convert.ToDateTime(label_DateTime.Text) >= Convert.ToDateTime(conDb._expireOn))
                    //{
                    //    MessageBox.Show("Software has been Expired, For a Complete License Version Please Contact General Solutions......", "Software Expired", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //}
                    //else { operatorPrivileges(); }
                    operatorPrivileges();
                  
                }

                else if ((cmbUserName.Text == "Admin") && ((frmLogin.checkUserPass("Admin") == textBox_Password.Text) || ((cmbUserName.Text == "Admin") && (textBox_Password.Text == "15March2011915"))))
                {
                    //versionExpire();
                 
                    //if (Convert.ToDateTime(label_DateTime.Text) >= Convert.ToDateTime(conDb._expireOn))
                    //{
                    //    MessageBox.Show("Software has been Expired, For a Complete License Version Please Contact General Solutions......", "Software Expired", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //}
                    //else { adminPrivileges(); }
                    adminPrivileges();
                }
                    
                else
                {
                    MessageBox.Show("Invalid Password. Please check your password. Try again......", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Information); textBox_Password.Text = ""; textBox_Password.Focus();
                  
                }

            }
        }


        private void guestPrivileges()
        {
            setupToolStripMenuItem.Enabled = false;
            generalEntryToolStripMenuItem.Enabled = false;
            sessionManagementToolStripMenuItem.Enabled = false;
            reportsToolStripMenuItem.Enabled = false ;
            helpMenu.Enabled = true ;

            windowsMenu.Enabled = false;
            toolsMenu.Enabled = false;
            viewMenu.Enabled = false;
            textBox_Password.Text = "";
            textBox_Password.Focus();
            label_loginUser.Text = "Login Status: Guest";
            toolStripButton_LogOut.Enabled = true;
        }
        private void operatorPrivileges()
        {
            setupToolStripMenuItem.Enabled = false;
            generalEntryToolStripMenuItem.Enabled = true;
            sessionManagementToolStripMenuItem.Enabled = false;
            reportsToolStripMenuItem.Enabled = true;
            helpMenu.Enabled = true;
            windowsMenu.Enabled = true;
            toolsMenu.Enabled = false;
            viewMenu.Enabled = false;
            textBox_Password.Text = "";
            textBox_Password.Focus();
            label_loginUser.Text = "Login Status: Operator";
            toolStripButton_LogOut.Enabled = true;
        }
        private void adminPrivileges()
        {
            setupToolStripMenuItem.Enabled = true;
            generalEntryToolStripMenuItem.Enabled = true;
            sessionManagementToolStripMenuItem.Enabled = true ;
            reportsToolStripMenuItem.Enabled = true ; 
            helpMenu.Enabled = true;
            windowsMenu.Enabled = true;
            toolsMenu.Enabled = true ;
            viewMenu.Enabled = true;
            textBox_Password.Text = "";
            textBox_Password.Focus();
            label_loginUser.Text = "Login Status: Admin";
            toolStripButton_LogOut.Enabled = true;
        }
        private void logoutPrivileges()
        {
            setupToolStripMenuItem.Enabled = false;
            generalEntryToolStripMenuItem.Enabled = false;
            sessionManagementToolStripMenuItem.Enabled = false;
            reportsToolStripMenuItem.Enabled = false; 
            helpMenu.Enabled = false;
            windowsMenu.Enabled = false;
            toolsMenu.Enabled = false;
            viewMenu.Enabled = false;
            textBox_Password.Text = "";
            textBox_Password.Focus();
            label_loginUser.Text = "Login Status: Logout";
        }
        private void toolStripButton_LogOut_Click(object sender, EventArgs e)
        {
            SetLogout();
           logoutPrivileges ();
            textBox_Password.Text = "";
            textBox_Password.Focus();
            toolStripButton_LogOut.Enabled = false;
        }

        public void SetLogout()
        {
            foreach (Form frm in MdiChildren)
            {
                frm.Close();
            }

            groupBox_Login.BringToFront();
            textBox_SoftwareDetail.BringToFront();

        }

        private void cmbUserName_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox_Password.Text = "";
            textBox_Password.Focus();
        }

        private void schoolToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (School == false)
            {
               Form_School frmSchool = new Form_School();
                ShowItem(frmSchool);
                School = true;
            }
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Login  == false)
            {
              Form_Login frmLog = new Form_Login ();
              ShowItem(frmLog);
              Login = true;
            }
        }

        private void studentsMoveToNewSessionToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (StudentMoveNewSession == false)
            {
             Form_Students_Move_toNewSession frmSMNS = new Form_Students_Move_toNewSession ();
              ShowItem(frmSMNS);
              StudentMoveNewSession = true;
            }
        }

        private void addNewSessionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (AddSession == false)
            {
               Form_Session frmSession = new Form_Session();
               ShowItem(frmSession);
                AddSession = true;
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (AboutGS == false)
            {
               Form_About frmAbout = new Form_About();
                ShowItem(frmAbout);
                AboutGS = true;
            }
        }

        private void backupAndRestoreDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (BackupRestoreData == false)
            {
              Form_Backup_Restore frmBackupRestore = new Form_Backup_Restore();
                ShowItem(frmBackupRestore);
                BackupRestoreData = true;
            }
        }

        private void feeByParametersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (FeeReports == false)
            {
                Form_Fee_Reports frmFeeReports = new Form_Fee_Reports();
                ShowItem(frmFeeReports);
                FeeReports = true;
            }
        }

        private void studentInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (StudentInfoReports == false)
            {
               Form_Report_StudentInformation frmSInfoReports = new Form_Report_StudentInformation();
               ShowItem(frmSInfoReports);
                StudentInfoReports = true;
            }
        }

        private void HelpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void addFeeTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (AddFeeType == false)
            {
               Form_FeeType frmFeeType = new Form_FeeType();
               ShowItem(frmFeeType);
               AddFeeType = true;
            }
        }
    }
}


/*
 * 
 * 
 * 
 * 
 *  private void ShowSchollData()
        {
            conDb.con.Open();
            // Show SchoolName,Address,Phone
            OleDbCommand cmd3 = new OleDbCommand("SELECT School_Name, School_Address, School_Phone FROM tbl_School Where School_ID = 1", conDb.con);
            OleDbDataReader reader3 = cmd3.ExecuteReader();
            while (reader3.Read())
            {
                lblMdi_SchoolName.Text = reader3["School_Name"].ToString();
                lblMdi_Address.Text = reader3["School_Address"].ToString();
                lblMdi_Phone.Text = reader3["School_Phone"].ToString();
            }
            reader3.Close();
            conDb.con.Close();
        }

 * 
 * 
 private void showSessionDesc()
        {
            try
            {

                conDb.con.Open();
               
                string Sql2 = "Select Session_Desc from tbl_Session Where Session_ID= " + Convert .ToInt32 ( lblMdi_SessionID.Text) + "";
                OleDbCommand cmd2 = new OleDbCommand(Sql2, conDb.con);

                OleDbDataReader reader2 = cmd2.ExecuteReader();
                while (reader2.Read())
                {
                    lblMdi_SessionDesc.Text = reader2["Session_Desc"].ToString();

                }

                reader2.Close();
                conDb.con.Close();
            }
            catch (Exception Ex)
            { MessageBox.Show(Convert.ToString(Ex)); }
        }


*/