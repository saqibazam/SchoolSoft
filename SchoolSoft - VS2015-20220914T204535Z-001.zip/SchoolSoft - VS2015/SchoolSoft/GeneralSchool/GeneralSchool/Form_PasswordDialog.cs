using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_PasswordDialog : Form
    {
        public Form_PasswordDialog()
        {
            InitializeComponent();
        }
        public string Password
        {
         get { return textBoxPassword.Text; }
            set { textBoxPassword.Text = value; }
        }

        private void Form_PasswordDialog_Load(object sender, EventArgs e)
        {
            textBoxPassword.Focus();
        }

        private void textBoxPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {

                button_Ok.Focus();
            }
        }

       



    }
}