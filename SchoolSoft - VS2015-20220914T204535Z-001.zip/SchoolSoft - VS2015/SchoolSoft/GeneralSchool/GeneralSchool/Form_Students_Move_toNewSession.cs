using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_Students_Move_toNewSession : Form
    {
        Class_ConnectDB conDb = new Class_ConnectDB();

       
        public Form_Students_Move_toNewSession()
        {
            InitializeComponent();
          
        }

        private void tbl_Student_MovementBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_Student_MovementBindingSource.EndEdit();
            this.tbl_Student_MovementTableAdapter.Update(this.schoolDbDataSet.tbl_Student_Movement);
            tbl_Student_MovementBindingNavigatorSaveItem.Enabled = false;

        }

        private void Form_Students_Move_toNewSession_Load(object sender, EventArgs e)
        {
            
            // TODO: This line of code loads data into the 'schoolDbDataSet.View_ClassDetailThree' table. You can move, or remove it, as needed.
            this.view_ClassDetailThreeTableAdapter.Fill(this.schoolDbDataSet.View_ClassDetailThree);
            //tbl_Student_MovementDataGridView.DataSource = "";
            // TODO: This line of code loads data into the 'schoolDbDataSet.View_ClassDetailTwo' table. You can move, or remove it, as needed.
            this.view_ClassDetailTwoTableAdapter.Fill(this.schoolDbDataSet.View_ClassDetailTwo);
            // TODO: This line of code loads data into the 'schoolDbDataSet.View_ClassDetail' table. You can move, or remove it, as needed.
            this.view_ClassDetailTableAdapter.Fill(this.schoolDbDataSet.View_ClassDetail);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Session' table. You can move, or remove it, as needed.
            this.tbl_SessionTableAdapter.Fill(this.schoolDbDataSet.tbl_Session);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Result' table. You can move, or remove it, as needed.
            this.tbl_ResultTableAdapter.Fill(this.schoolDbDataSet.tbl_Result);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_SMCS_Define' table. You can move, or remove it, as needed.
            this.tbl_SMCS_DefineTableAdapter.Fill(this.schoolDbDataSet.tbl_SMCS_Define);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Student_Movement' table. You can move, or remove it, as needed.
           
           
            cmbClassDetailListLoad();
            cmbClassDetailOneListLoad();
            cmbClassDetailTwoListLoad();
            cmb_ClassDetailThreeListLoad();
            cmb_ClassDetailFourListLoad();
    
            gridViewLoadPercentDisable();

            loadSessionProgressStatus();
            bindingNavigatorDeleteItem.Enabled = false;
            tbl_Student_MovementBindingNavigatorSaveItem.Enabled = false;

            if (checkBox_PassOutStudents.Checked == true)
            {
                btn_MarkPassOut.Enabled = false;
            }
            if (checkBox_MovedAllStudentsToNewSession.Checked == true)
            {
                btn_MoveSession.Enabled = false; 
            }
            if (checkBox_MovedToNewClass.Checked == true)
            {
                btn_MoveToNewClass.Enabled = false;
            }
            if (checkBox_AssignedRollNumbers.Checked == true)
            {
                btn_AssignRoll.Enabled = false;
            }


        }
        private void cmbClassDetailListLoad()
        {
           
            cmbClassDetail.DataSource = schoolDbDataSet.Tables["tbl_SMCS_Define"];
            cmbClassDetail.DisplayMember = "Class_Detail";
            // Value Member is a Field Type and ValumeMember just store it field name not field value
            // It send valu to Selected Value Properties.
            cmbClassDetail.ValueMember = "smcsd_ID";
          
            int sesId = int.Parse(conDb.returnSessionID()) - 1;
            this.tbl_Student_MovementTableAdapter.FillBySession_SmcsdID(this.schoolDbDataSet.tbl_Student_Movement, sesId, Convert.ToInt32(cmbClassDetail.SelectedValue));
            

        }
        private void cmbClassDetailOneListLoad()
        {
            cmbClassDetailOne.DataSource = schoolDbDataSet.Tables["View_ClassDetail"];
            cmbClassDetailOne.DisplayMember = "Class_Detail";
            cmbClassDetailOne.ValueMember = "smcsd_ID";
            int s_ID = Convert.ToInt32(conDb.returnSessionID());
            this.tbl_Student_MovementTableAdapter.FillBySession_SmcsdID(this.schoolDbDataSet.tbl_Student_Movement, s_ID, Convert.ToInt32(cmbClassDetailOne.SelectedValue));
        }
       
        private void  cmbClassDetailTwoListLoad()
        {
            cmbClassDetailTwo.DataSource = schoolDbDataSet.Tables["View_ClassDetailTwo"];
            cmbClassDetailTwo.DisplayMember = "Class_Detail";
            cmbClassDetailTwo.ValueMember = "smcsd_ID";
            label12.Text =  cmbClassDetailTwo.SelectedValue.ToString ();
        }
        private void cmb_ClassDetailThreeListLoad()
        {
            cmb_ClassDetailThree.DataSource = schoolDbDataSet.Tables["View_ClassDetailThree"];
            cmb_ClassDetailThree.DisplayMember = "Class_Detail";
            cmb_ClassDetailThree.ValueMember = "smcsd_ID";
            int sesId = int.Parse(conDb.returnSessionID());
            this.tbl_Student_MovementTableAdapter.FillByPercentageAcendingOrder_SesID_SmcsdID(this.schoolDbDataSet.tbl_Student_Movement, sesId, Convert.ToInt32(cmb_ClassDetailThree.SelectedValue));
        }

        private void cmb_ClassDetailFourListLoad()
        {
            //cmbClassDetailFour.DataSource = schoolDbDataSet.Tables["View_ClassDetailTwo"];
            cmbClassDetailFour.DataSource = schoolDbDataSet.Tables["View_ClassDetailThree"];
            cmbClassDetailFour.DisplayMember = "Class_Detail";
            cmbClassDetailFour.ValueMember = "smcsd_ID";
            int sesId = int.Parse(conDb.returnSessionID());
            this.tbl_Student_MovementTableAdapter.FillByPercentageAcendingOrder_SesID_SmcsdID(this.schoolDbDataSet.tbl_Student_Movement, sesId, Convert.ToInt32(cmbClassDetailFour.SelectedValue));
        }



        private void cmbClassDetailOne_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbClassDetailOneListLoad();
            bindingNavigatorDeleteItem.Enabled = false;
        }

        private void cmbClassDetailTwo_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbClassDetailTwoListLoad();
            bindingNavigatorDeleteItem.Enabled = false;
        }
        private void cmb_ClassDetailThree_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmb_ClassDetailThreeListLoad();
            bindingNavigatorDeleteItem.Enabled = false;
        }
        private void cmbClassDetailFour_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmb_ClassDetailFourListLoad();
            bindingNavigatorDeleteItem.Enabled = false;
        }
        private void gridViewLoadPercentEnable()
        {
            tbl_Student_MovementDataGridView.ReadOnly = false;
            tbl_Student_MovementDataGridView.Columns[0].ReadOnly = true;
            tbl_Student_MovementDataGridView.Columns[1].ReadOnly = true;
            tbl_Student_MovementDataGridView.Columns[2].ReadOnly = true;
            tbl_Student_MovementDataGridView.Columns[3].ReadOnly = true;
            tbl_Student_MovementDataGridView.Columns[4].ReadOnly = false;
            tbl_Student_MovementDataGridView.Columns[5].ReadOnly = true;
          
        }
        private void gridViewLoadResultPercentRollEnable()
        {
            tbl_Student_MovementDataGridView.ReadOnly = false;
            tbl_Student_MovementDataGridView.Columns[0].ReadOnly = true;
            tbl_Student_MovementDataGridView.Columns[1].ReadOnly = true;
            tbl_Student_MovementDataGridView.Columns[2].ReadOnly = true;
            tbl_Student_MovementDataGridView.Columns[3].ReadOnly = false ;
            tbl_Student_MovementDataGridView.Columns[4].ReadOnly = false;
            tbl_Student_MovementDataGridView.Columns[5].ReadOnly = false;
          
        }
        private void gridViewLoadPercentDisable()
        {
            tbl_Student_MovementDataGridView.ReadOnly = true;
        }
 

        private void tabControl_Students_Move_Session_Selected(object sender, TabControlEventArgs e)
        {
            //Pass Out Last Class Tab
            if (tabControl_Students_Move_Session.SelectedIndex == 0)
            {
                gridViewLoadPercentDisable();
               
                //tabPage_AssignRollNo.Controls.Add(this.cmbClassDetail);
            }

                //Move to New Session Tab
            else if (tabControl_Students_Move_Session.SelectedIndex == 1)
            {
                gridViewLoadPercentDisable();
                
            }

                //Move to New Class Tab
            else if (tabControl_Students_Move_Session.SelectedIndex == 2)
            {
                gridViewLoadPercentEnable();
              
            }

                //Assign Roll Numbers Tab
            else if (tabControl_Students_Move_Session.SelectedIndex == 3)
            {
                gridViewLoadPercentDisable();
              

            }
            //IR-Regular Changes Tab
            else if (tabControl_Students_Move_Session.SelectedIndex == 4)
            {
                gridViewLoadPercentDisable();
                
               
            }

        }

        private void tabControl_Students_Move_Session_Selecting(object sender, TabControlCancelEventArgs e)
        {
            ////Pass Out Last Class Tab
            //if (tabControl_Students_Move_Session.SelectedIndex == 0)
            //{
            //    //gridViewLoadPercentDisable();
            //    //tabPage_AssignRollNo.Controls.Add(this.cmbClassDetail);
            //    //tabPage_AssignRollNo.Controls.Add(this.label1_SessionDesc);
            //    //cmbClassDetail.Visible = true;
                
            //}

            //    //Move to New Session Tab
            //else if (tabControl_Students_Move_Session.SelectedIndex == 1)
            //{
            //    //gridViewLoadPercentEnable();
            //}

            //    //Move to New Class Tab
            //else if (tabControl_Students_Move_Session.SelectedIndex == 2)
            //{
            //    //gridViewLoadPercentEnable();
            //}

            //    //Assign Roll Numbers Tab
            //else if (tabControl_Students_Move_Session.SelectedIndex == 3)
            //{
            //    //tabPage_AssignRollNo.Controls.Add(this.cmbClassDetail);
            //    //tabPage_AssignRollNo.Controls.Add(this.label1_SessionDesc);
            //    //cmbClassDetail.Visible = true;
            //}
        }

        private void btn_MoveSession_Click(object sender, EventArgs e)
        {
            try
            {

                for (int counter = 0; counter < (tbl_Student_MovementDataGridView.Rows.Count); counter++)
                {

                    int grNo = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[1].Value);
                    int percent = 0;
                    int roll = 0;
                    int smcsdID = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[6].Value);
                    int res_ID = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[3].Value);
                    int ses_ID = 0;

                    if (res_ID == 1) // 1 is Pass
                    {
                        // New Session
                        ses_ID = Convert.ToInt32(conDb.returnSessionID());
                        int res_Nid = 5;
                        this.tbl_Student_MovementTableAdapter.Insert(grNo, ses_ID, smcsdID, res_Nid, percent, roll);
                    }
                }
                this.tbl_Student_MovementTableAdapter.FillBySessionID(this.schoolDbDataSet.tbl_Student_Movement, Convert.ToInt32(cmb_Session.SelectedValue));
                btn_MoveSession.Enabled = false;
                checkBox_MovedAllStudentsToNewSession.Checked = true;
                UpdateMoveToNewSessionInTable();
                
            }
               
            catch (Exception ex) { MessageBox.Show(Convert.ToString(ex)); }
        }

        private int returnClassCapacity(string cmbSelectedValue)
        {

            int smcsd_ID = int.Parse(cmbSelectedValue);
            conDb.con.Open();
            OleDbCommand cmd = new OleDbCommand("SELECT  Class_Capacity FROM tbl_SMCS_Define Where Smcsd_ID = " + smcsd_ID + " ", conDb.con);
            object returnValue1;
            returnValue1 = cmd.ExecuteScalar();
            conDb.con.Close();
            return Convert.ToInt32(returnValue1);

        }
        private void btn_MoveToNewClass_Click(object sender, EventArgs e)
        {
            try
            {
                int currentClass = returnClassCapacity (cmbClassDetailOne.SelectedValue.ToString () ) ;
                int nextClass = returnClassCapacity(cmbClassDetailTwo.SelectedValue.ToString());
                if ((nextClass >= currentClass) && (Convert.ToInt32(cmbClassDetailOne.SelectedValue) != Convert.ToInt32(cmbClassDetailTwo.SelectedValue)))
                {
                    int sesId = int.Parse(conDb.returnSessionID());
                    //int sesId = Convert.ToInt32(tbl_Student_MovementDataGridView.SelectedCells[2].Value);
                    //int roll = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[5].Value);
                    //int grNo = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[1].Value);
                    conDb.con.Open();
                    for (int counter = 0; counter < (tbl_Student_MovementDataGridView.Rows.Count); counter++)
                    {
                        int stMovId = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[0].Value);
                        int resId = 0;
                        double percent = Convert.ToDouble(tbl_Student_MovementDataGridView.Rows[counter].Cells[4].Value);

                        int smcsdID = 0;
                        if (percent >= 45.00)
                        {
                            smcsdID = Convert.ToInt32(cmbClassDetailTwo.SelectedValue);
                            resId = 1;
                        }
                        else if (percent < 45.00)
                        {
                            smcsdID = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[6].Value);
                            resId = 3;
                        }

                        // I had used update by TableAdapter but it is not Updating, and reason is still not found, So I leave it, and Use by Command Object to Update directly to the Database.                                                                                          
                        // this.tbl_Student_MovementTableAdapter.Update(grNo, sesId, smcsdID, resId, percent, roll, stMovId, grNo, sesId, smcsd_OId, resId, percent, roll);

                        // OleDbCommand cmdUpdate = new OleDbCommand("UPDATE tbl_Student_Movement SET GR_No = " + grNo + " , Session_ID = " + sesId + " , Result_ID = " + resId + " , Percentage = " + percent + " , Roll = " + roll + " , Smcsd_ID = " + smcsdID + " WHERE St_Mov_ID = "+stMovId +"  ", conDb.con);
                        OleDbCommand cmdUpdate = new OleDbCommand("UPDATE tbl_Student_Movement SET Result_ID = " + resId + " , Percentage = " + percent + " , Smcsd_ID = " + smcsdID + " WHERE St_Mov_ID = " + stMovId + "  ", conDb.con);

                        cmdUpdate.ExecuteNonQuery();

                    }
                    conDb.con.Close();
                    btn_MoveToNewClass.Enabled = false;
                    this.tbl_Student_MovementTableAdapter.FillBySession_SmcsdID(this.schoolDbDataSet.tbl_Student_Movement, sesId, Convert.ToInt32(cmbClassDetailTwo.SelectedValue));
                    checkBox_MovedToNewClass.Checked = true;
                    UpdateMoveToNewClassInTable();
                }
                else {
                    if (MessageBox.Show("Seating Capacity is less than required Capacity OR May be You Choose Same Class, For Edit Class Detail Click Yes..,", "No Seating Capacity", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        Form_Class_Section_Shift_Medium_Define frmClassDefine = new Form_Class_Section_Shift_Medium_Define();
                        frmClassDefine.frmSMNS = this;
                        frmClassDefine.ShowDialog();
                        //this.view_ClassDetailTwoTableAdapter.Fill(this.schoolDbDataSet.View_ClassDetailTwo);
                    }
                    else {tabControl_Students_Move_Session .SelectTab (2); }
                }
                }
            catch (Exception ex) { MessageBox.Show(Convert.ToString(ex)); }
        }

        private void cmb_Session_SelectedIndexChanged(object sender, EventArgs e)
        {
            int s_ID = Convert.ToInt32(cmb_Session .SelectedValue );
            this.tbl_Student_MovementTableAdapter.FillBySessionID(this.schoolDbDataSet.tbl_Student_Movement, s_ID);
            bindingNavigatorDeleteItem.Enabled = false;
        }

        private void cmbClassDetail_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbClassDetailListLoad();
            bindingNavigatorDeleteItem.Enabled = false;
            //tbl_Student_MovementDataGridView.DataSource = tbl_Student_MovementBindingSource;
        }
 
        private void loadSessionProgressStatus()
        {
            checkBox_PassOutStudents.Checked = conDb._passOutLastClass;
            checkBox_MovedAllStudentsToNewSession.Checked = conDb._moveToNewSession;
            checkBox_MovedToNewClass.Checked = conDb._moveToNewClass;
            checkBox_AssignedRollNumbers.Checked = conDb._assignRoll;

        }

        private void UpdateAssignRollToNewClassInTable()
        {
            int S_ID = Convert.ToInt32(conDb.returnSessionID());
            OleDbCommand cmdARNC = new OleDbCommand("UPDATE  tbl_Session_Progress_Status SET  AssignRollNoToNewClass = " + true + " WHERE Session_ID = " + S_ID + "  ", conDb.con);
            conDb.con.Open();
            cmdARNC.ExecuteNonQuery();
            conDb.con.Close();
        }

        private void UpdateMoveToNewClassInTable()
        {
            int S_ID = Convert.ToInt32(conDb.returnSessionID());
            OleDbCommand cmdMNC = new OleDbCommand("UPDATE  tbl_Session_Progress_Status SET  MoveAllSuccessfulStudentsToNewClass = " + true + " WHERE Session_ID = " + S_ID + "  ", conDb.con);
            conDb.con.Open();
            cmdMNC.ExecuteNonQuery();
            conDb.con.Close();
        }

        private void UpdateMoveToNewSessionInTable()
        {
            int S_ID = Convert.ToInt32(conDb.returnSessionID());
            OleDbCommand cmdMNS = new OleDbCommand("UPDATE  tbl_Session_Progress_Status SET  MoveAllStudentstoNewSession = " + true + " WHERE Session_ID = " + S_ID + "  ", conDb.con);
            conDb.con.Open();
            cmdMNS.ExecuteNonQuery();
            conDb.con.Close();
        }

        private void UpdatePassOutInTable()
        {
             int S_ID = Convert .ToInt32 (conDb.returnSessionID());
             OleDbCommand cmdUPO = new OleDbCommand("UPDATE  tbl_Session_Progress_Status SET PassOutLastClassStudents = " + true + " WHERE Session_ID = " + S_ID + "  ", conDb.con);
             conDb.con.Open();
             cmdUPO.ExecuteNonQuery();
             conDb.con.Close();
        }


        private void btn_MarkPassOut_Click(object sender, EventArgs e)
        {
            try
            {

                for (int counter = 0; counter < (tbl_Student_MovementDataGridView.Rows.Count); counter++)
                {
                    int stMovId = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[0].Value);
                    int grNo = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[1].Value);
                    int sesId = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[2].Value);
                    int resIdNew = 4;
                    int resId = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[3].Value);
                    int percent = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[4].Value);
                    int smcsdID = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[6].Value);
                    int roll = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[5].Value);

                    this.tbl_Student_MovementTableAdapter.Update(grNo, sesId, smcsdID, resIdNew, percent, roll, stMovId, grNo, sesId, smcsdID, resId, percent, roll);
                }
                this.tbl_Student_MovementTableAdapter.FillBySmcsdID(this.schoolDbDataSet.tbl_Student_Movement, Convert.ToInt32(cmbClassDetail.SelectedValue));
                checkBox_PassOutStudents.Checked = true ;
                UpdatePassOutInTable();
            }
            catch (Exception ex) { MessageBox.Show(Convert.ToString(ex)); }
        }

        private void btn_AssignRoll_Click(object sender, EventArgs e)
        {
            try
            {
                int roll = 1;
                conDb.con.Open();

                for (int counter = 0; counter < (tbl_Student_MovementDataGridView.Rows.Count); counter++)
                {
                    int stMovId = Convert.ToInt32(tbl_Student_MovementDataGridView.Rows[counter].Cells[0].Value);
                    OleDbCommand cmdUpdate = new OleDbCommand("UPDATE tbl_Student_Movement SET Roll = " + roll + "  WHERE St_Mov_ID = " + stMovId + "  ", conDb.con);
                    roll++;
                    cmdUpdate.ExecuteNonQuery();
                }
                conDb.con.Close();
                btn_AssignRoll.Enabled = false;
                cmb_ClassDetailThreeListLoad();
             checkBox_AssignedRollNumbers.Checked = true;
             UpdateAssignRollToNewClassInTable();
            }
            catch (Exception ex) { MessageBox.Show(Convert.ToString(ex)); }
        }

        private void btn_Enable_Delete_Save_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Be Carefull, You are going to Delete or Save Records in your Database, Are you sure you want to Change Records..,", "No Seating Capacity", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                bindingNavigatorDeleteItem.Enabled = true;
                tbl_Student_MovementBindingNavigatorSaveItem.Enabled = true;
                gridViewLoadResultPercentRollEnable();
            }
            else { tabControl_Students_Move_Session.SelectTab(4); }
            
            
            
        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorDeleteItem.Enabled = false;
           
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorDeleteItem.Enabled = false;
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorDeleteItem.Enabled = false;
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorDeleteItem.Enabled = false;
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorDeleteItem.Enabled = false;
        }

        private void Form_Students_Move_toNewSession_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.StudentMoveNewSession = false;
        }

    }
}