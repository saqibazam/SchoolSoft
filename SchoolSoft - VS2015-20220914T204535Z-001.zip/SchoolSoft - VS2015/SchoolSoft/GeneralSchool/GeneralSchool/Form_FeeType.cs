using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_FeeType : Form
    {
        public Form_FeeType()
        {
            InitializeComponent();
        }

        private void tbl_Fee_TypeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.tbl_Fee_TypeBindingSource.EndEdit();
                this.tbl_Fee_TypeTableAdapter.Update(this.schoolDbDataSet.tbl_Fee_Type);
                MessageBox.Show("Record has been saved successfully.....Press OK to continue...", "Record has been saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
               
                bindingNavigatorAddNewItem.Enabled = true;
                tbl_Fee_TypeBindingNavigatorSaveItem.Enabled = false;
                button_EditData.Enabled = true;
                fee_TypeTextBox.Enabled = false;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Convert.ToString(Ex));
            }
            }

        private void Form_FeeType_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Fee_Type' table. You can move, or remove it, as needed.
            this.tbl_Fee_TypeTableAdapter.Fill(this.schoolDbDataSet.tbl_Fee_Type);
            fee_TypeTextBox.Enabled = false ;
            bindingNavigatorAddNewItem.Enabled = false  ;
            tbl_Fee_TypeBindingNavigatorSaveItem.Enabled = false ;
            button_EditData.Enabled = false  ;
        }

        private void Form_FeeType_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.AddFeeType = false;
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            fee_TypeTextBox.Enabled = true;
            bindingNavigatorAddNewItem.Enabled = false ;
            tbl_Fee_TypeBindingNavigatorSaveItem.Enabled = true ;
            button_EditData.Enabled = false ;
        }

        private void button_EditData_Click(object sender, EventArgs e)
        {
            fee_TypeTextBox.Enabled = true;
            bindingNavigatorAddNewItem.Enabled = false ;
            tbl_Fee_TypeBindingNavigatorSaveItem.Enabled = true ;
            button_EditData.Enabled = false ;
        }

        private Form_PasswordDialog _passDlg = new Form_PasswordDialog();
        private Form_Login frmLogin = new Form_Login();
       
        private void button_EnableAddEdit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = _passDlg.ShowDialog(this);
            if ((dialogResult == DialogResult.OK) && (_passDlg.Password == "15March2011915"))
            {
                _passDlg.textBoxPassword.Text = "";
                bindingNavigatorAddNewItem.Enabled = true  ;
                button_EditData.Enabled = true  ;
            }
            else if ((dialogResult == DialogResult.OK) && (_passDlg.Password == frmLogin.checkUserPass("Admin")))
            {
                _passDlg.textBoxPassword.Text = "";
                bindingNavigatorAddNewItem.Enabled = true ;
                button_EditData.Enabled = true ;
            }
            else if (dialogResult == DialogResult.Cancel)
            { }
            else
            {
                _passDlg.textBoxPassword.Text = "";
                MessageBox.Show("Invalid Password.....Press OK to continue...", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
           bindingNavigatorPositionItem.Enabled = false;
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }
    }
}