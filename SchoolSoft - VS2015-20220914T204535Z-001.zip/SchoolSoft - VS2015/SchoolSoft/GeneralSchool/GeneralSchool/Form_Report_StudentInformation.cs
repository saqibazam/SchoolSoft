using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace GeneralSchool
{
    public partial class Form_Report_StudentInformation : Form
    {
        Class_ConnectDB conDb = new Class_ConnectDB();
        public Form_Report_StudentInformation()
        {
            InitializeComponent();
        }

        private void Form_Report_StudentInformation_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.StudentInfoReports = false ;
        }

        private void Form_Report_StudentInformation_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Session' table. You can move, or remove it, as needed.
            this.tbl_SessionTableAdapter.Fill(this.schoolDbDataSet.tbl_Session);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_SMCS_Define' table. You can move, or remove it, as needed.
            this.tbl_SMCS_DefineTableAdapter.Fill(this.schoolDbDataSet.tbl_SMCS_Define);

        }

        private void crystalReportViewer_StudentInformation_Load(object sender, EventArgs e)
        {

        }

        private void comboBox_SmcsdID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void SetDBLogonForReport(ConnectionInfo connectionInfo)
        {
            TableLogOnInfos tableLogOnInfos = crystalReportViewer_StudentInformation.LogOnInfo;
            foreach (TableLogOnInfo tableLogOnInfo in tableLogOnInfos)
            {
                tableLogOnInfo.ConnectionInfo = connectionInfo;
            }
        }
        private void button_Show_Report_Click(object sender, EventArgs e)
        {
            try
            {
              CR_Student_Information crSInfo = new CR_Student_Information ();
              crSInfo.Load("C://SchoolSoft//GeneralSchool//GeneralSchool//CR_Student_Information.rpt");
              crystalReportViewer_StudentInformation.ReportSource = crSInfo;
              crystalReportViewer_StudentInformation.DisplayToolbar = true;
              crystalReportViewer_StudentInformation.DisplayGroupTree = true;
              crystalReportViewer_StudentInformation.Zoom(100);
                //crystalReportViewer_VoucherReport.Right;
              crSInfo.SetParameterValue("schoolName", conDb._schoolName);
              crSInfo.SetParameterValue("addressSchool", conDb._address);
              crSInfo.SetParameterValue("phoneSchool", conDb._phone);
                string compNamAdd = conDb ._companyName +" URL: " + conDb ._website + " Email: " + conDb ._email ;
                crSInfo.SetParameterValue("_companyNameAddress", compNamAdd);

              int sessionID = Convert.ToInt32(comboBox_SessionID.SelectedValue);
              int smcsdID = Convert.ToInt32(comboBox_SmcsdID.SelectedValue);
              crSInfo.SetParameterValue("_smcsdID", smcsdID);
              crSInfo.SetParameterValue("_session", sessionID);
              
                ConnectionInfo connectionInfo = new ConnectionInfo();
                connectionInfo.Password = "30615aorangikhi75800";
                SetDBLogonForReport(connectionInfo);


                //tabControl_Fee_Report.SelectTab(0);
            }
            catch (Exception Ex)
            {
                //MessageBox.Show("Fee Voucher Not Found, First Create Voucher... ", "Voucher Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show(Convert.ToString(Ex));
            }
        }
    }
}