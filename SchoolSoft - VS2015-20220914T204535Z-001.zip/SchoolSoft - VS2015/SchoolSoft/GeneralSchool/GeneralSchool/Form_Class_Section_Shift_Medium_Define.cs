using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_Class_Section_Shift_Medium_Define : Form
    {
        public Form_NewStudent_Registration frmNSR;
        public Form_Students_Move_toNewSession frmSMNS;
        public Form_Class_Section_Shift_Medium_Define()
        {
            InitializeComponent();
        }

        private void Form_Class_Section_Shift_Medium_Define_Load(object sender, EventArgs e)
        {
           
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Section' table. You can move, or remove it, as needed.
            this.tbl_SectionTableAdapter.Fill(this.schoolDbDataSet.tbl_Section);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Class' table. You can move, or remove it, as needed.
            this.tbl_ClassTableAdapter.Fill(this.schoolDbDataSet.tbl_Class);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Medium' table. You can move, or remove it, as needed.
            this.tbl_MediumTableAdapter.Fill(this.schoolDbDataSet.tbl_Medium);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Shift' table. You can move, or remove it, as needed.
            this.tbl_ShiftTableAdapter.Fill(this.schoolDbDataSet.tbl_Shift);
            
            if (this.frmNSR != null)
            {
                this.smcsd_IDTextBox.Text = ((Form_NewStudent_Registration)this.frmNSR).label_SMCS_ID.Text;
                int smcsdID = Convert.ToInt32(smcsd_IDTextBox.Text);
                this.tbl_SMCS_DefineTableAdapter.FillBy(this.schoolDbDataSet.tbl_SMCS_Define, smcsdID);
            }
            //else if (this.frmNSR == null)
            //{
            //    // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_SMCS_Define' table. You can move, or remove it, as needed.
            //    this.tbl_SMCS_DefineTableAdapter.Fill(this.schoolDbDataSet.tbl_SMCS_Define);
            //}

            else if (this.frmSMNS != null)
            {
                this.smcsd_IDTextBox.Text = ((Form_Students_Move_toNewSession)this.frmSMNS).label12.Text;
                int smcsdID = Convert.ToInt32(smcsd_IDTextBox.Text);
                this.tbl_SMCS_DefineTableAdapter.FillBy(this.schoolDbDataSet.tbl_SMCS_Define, smcsdID);
            }
            else
            {
                // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_SMCS_Define' table. You can move, or remove it, as needed.
                this.tbl_SMCS_DefineTableAdapter.Fill(this.schoolDbDataSet.tbl_SMCS_Define);
            }
            disableControls();
            toolStripButton_Edit.Enabled = false;
            tbl_SMCS_DefineBindingNavigatorSaveItem.Enabled = false;
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void tbl_SMCS_DefineBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                class_CodeTextBox.Text = "1" + medium_IDComboBox.SelectedValue + shift_IDComboBox.SelectedValue + class_IDComboBox.SelectedValue + section_IDComboBox.SelectedValue;
                class_DetailTextBox.Text = class_IDComboBox.Text + " - " + section_IDComboBox.Text + "  - ( " + shift_IDComboBox.Text + " shift - " + medium_IDComboBox.Text + " medium - Seating capacity: " + class_CapacityTextBox.Text + " )";
                this.Validate();
                this.tbl_SMCS_DefineBindingSource.EndEdit();
                this.tbl_SMCS_DefineTableAdapter.Update(this.schoolDbDataSet.tbl_SMCS_Define);
                MessageBox.Show("Record has been successfully updated.....", "Update Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {
                MessageBox.Show("Duplicate Record Not Allowed.....", "Duplicate Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //MessageBox.Show(Convert.ToString(Ex)); 
            }
            disableControls();
            button_EnableAddEdit.Enabled = true;

            toolStripButton_Edit.Enabled = true ;
            tbl_SMCS_DefineBindingNavigatorSaveItem.Enabled = false ;
            bindingNavigatorAddNewItem.Enabled = true ;
        }

        private void Form_Class_Section_Shift_Medium_Define_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.ClassDefine = false;
        }
        public void enableControls()
        { 
        shift_IDComboBox.Enabled = true ;
        medium_IDComboBox.Enabled = true ;
        class_IDComboBox.Enabled = true ;
        section_IDComboBox.Enabled = true ;
        class_CapacityTextBox .Enabled = true ;     
        class_RoomSizeTextBox.Enabled = true ;
        class_RoomNoTextBox.Enabled = true;
        }
        public void disableControls()
        {
            shift_IDComboBox.Enabled = false;
            medium_IDComboBox.Enabled = false;
            class_IDComboBox.Enabled = false;
            section_IDComboBox.Enabled = false;
            class_CapacityTextBox.Enabled = false;
            class_RoomSizeTextBox.Enabled = false;
            class_RoomNoTextBox.Enabled = false;
        }

        private void toolStripButton_Edit_Click(object sender, EventArgs e)
        {
            enableControls();
            toolStripButton_Edit.Enabled = false;
            tbl_SMCS_DefineBindingNavigatorSaveItem.Enabled = true ;
            bindingNavigatorAddNewItem.Enabled = false;
        }

        private Form_PasswordDialog _passDlg = new Form_PasswordDialog();
        private Form_Login frmLogin = new Form_Login();

        private void button_EnableAddEdit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = _passDlg.ShowDialog(this);
            if ((dialogResult == DialogResult.OK) && (_passDlg.Password == "15March2011915"))
            {
                _passDlg.textBoxPassword.Text = "";
                enableControls();
                toolStripButton_Edit.Enabled = true;
                tbl_SMCS_DefineBindingNavigatorSaveItem.Enabled = false;
                bindingNavigatorAddNewItem.Enabled = true ;
                button_EnableAddEdit.Enabled = false;
            }
            else if ((dialogResult == DialogResult.OK) && (_passDlg.Password == frmLogin.checkUserPass("Admin")))
            {
                _passDlg.textBoxPassword.Text = "";
                enableControls();
                toolStripButton_Edit.Enabled = true;
                tbl_SMCS_DefineBindingNavigatorSaveItem.Enabled = false;
                bindingNavigatorAddNewItem.Enabled = true ;
                button_EnableAddEdit.Enabled = false;
            }
            else if (dialogResult == DialogResult.Cancel)
            { }
            else
            {
                _passDlg.textBoxPassword.Text = "";
                MessageBox.Show("Invalid Password.....Press OK to continue...", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

    }
}