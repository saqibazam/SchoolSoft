namespace GeneralSchool
{
    partial class Form_Fee_Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl_Fee_Report = new System.Windows.Forms.TabControl();
            this.tabPage_Report1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_ShowReport = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox_Class = new System.Windows.Forms.ComboBox();
            this.tblClassBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.comboBox_Section = new System.Windows.Forms.ComboBox();
            this.tblSectionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox_Shift = new System.Windows.Forms.ComboBox();
            this.tblShiftBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_Medium = new System.Windows.Forms.ComboBox();
            this.tblMediumBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage_PaidFeeOfAllClass = new System.Windows.Forms.TabPage();
            this.button_ShowPaidFeeAllClass = new System.Windows.Forms.Button();
            this.tabPage_ExemptFeeOfAllClass = new System.Windows.Forms.TabPage();
            this.button_ShowExemptFeeAllClass = new System.Windows.Forms.Button();
            this.comboBox_SessionYear = new System.Windows.Forms.ComboBox();
            this.tblSessionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.cRViewer_FeeVoucher = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.tbl_ClassTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ClassTableAdapter();
            this.tbl_SectionTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SectionTableAdapter();
            this.tbl_SessionTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SessionTableAdapter();
            this.tbl_ShiftTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ShiftTableAdapter();
            this.tbl_MediumTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_MediumTableAdapter();
            this.checkBox_FeeClosingCompleted = new System.Windows.Forms.CheckBox();
            this.label_SumFee = new System.Windows.Forms.Label();
            this.tabControl_Fee_Report.SuspendLayout();
            this.tabPage_Report1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblClassBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSectionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblShiftBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblMediumBindingSource)).BeginInit();
            this.tabPage_PaidFeeOfAllClass.SuspendLayout();
            this.tabPage_ExemptFeeOfAllClass.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblSessionBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl_Fee_Report
            // 
            this.tabControl_Fee_Report.Controls.Add(this.tabPage_Report1);
            this.tabControl_Fee_Report.Controls.Add(this.tabPage_PaidFeeOfAllClass);
            this.tabControl_Fee_Report.Controls.Add(this.tabPage_ExemptFeeOfAllClass);
            this.tabControl_Fee_Report.Location = new System.Drawing.Point(12, 120);
            this.tabControl_Fee_Report.Name = "tabControl_Fee_Report";
            this.tabControl_Fee_Report.SelectedIndex = 0;
            this.tabControl_Fee_Report.Size = new System.Drawing.Size(872, 127);
            this.tabControl_Fee_Report.TabIndex = 0;
            // 
            // tabPage_Report1
            // 
            this.tabPage_Report1.Controls.Add(this.groupBox1);
            this.tabPage_Report1.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Report1.Name = "tabPage_Report1";
            this.tabPage_Report1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Report1.Size = new System.Drawing.Size(864, 101);
            this.tabPage_Report1.TabIndex = 0;
            this.tabPage_Report1.Text = "Fee Report By Class";
            this.tabPage_Report1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btn_ShowReport);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.comboBox_Class);
            this.groupBox1.Controls.Add(this.comboBox_Section);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBox_Shift);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.comboBox_Medium);
            this.groupBox1.Location = new System.Drawing.Point(6, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(834, 66);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Parameters";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Class:";
            // 
            // btn_ShowReport
            // 
            this.btn_ShowReport.Image = global::GeneralSchool.Properties.Resources.show_report;
            this.btn_ShowReport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ShowReport.Location = new System.Drawing.Point(631, 19);
            this.btn_ShowReport.Name = "btn_ShowReport";
            this.btn_ShowReport.Size = new System.Drawing.Size(114, 40);
            this.btn_ShowReport.TabIndex = 1;
            this.btn_ShowReport.Text = "Show Report";
            this.btn_ShowReport.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_ShowReport.UseVisualStyleBackColor = true;
            this.btn_ShowReport.Click += new System.EventHandler(this.btn_ShowReport_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(150, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Section:";
            // 
            // comboBox_Class
            // 
            this.comboBox_Class.DataSource = this.tblClassBindingSource;
            this.comboBox_Class.DisplayMember = "Class_Desc";
            this.comboBox_Class.FormattingEnabled = true;
            this.comboBox_Class.Location = new System.Drawing.Point(7, 39);
            this.comboBox_Class.Name = "comboBox_Class";
            this.comboBox_Class.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Class.TabIndex = 2;
            this.comboBox_Class.ValueMember = "Class_ID";
            // 
            // tblClassBindingSource
            // 
            this.tblClassBindingSource.DataMember = "tbl_Class";
            this.tblClassBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox_Section
            // 
            this.comboBox_Section.DataSource = this.tblSectionBindingSource;
            this.comboBox_Section.DisplayMember = "Section_Desc";
            this.comboBox_Section.FormattingEnabled = true;
            this.comboBox_Section.Location = new System.Drawing.Point(153, 39);
            this.comboBox_Section.Name = "comboBox_Section";
            this.comboBox_Section.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Section.TabIndex = 3;
            this.comboBox_Section.ValueMember = "Section_ID";
            this.comboBox_Section.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // tblSectionBindingSource
            // 
            this.tblSectionBindingSource.DataMember = "tbl_Section";
            this.tblSectionBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(306, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Shift:";
            // 
            // comboBox_Shift
            // 
            this.comboBox_Shift.DataSource = this.tblShiftBindingSource;
            this.comboBox_Shift.DisplayMember = "Shift_Desc";
            this.comboBox_Shift.FormattingEnabled = true;
            this.comboBox_Shift.Location = new System.Drawing.Point(309, 39);
            this.comboBox_Shift.Name = "comboBox_Shift";
            this.comboBox_Shift.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Shift.TabIndex = 5;
            this.comboBox_Shift.ValueMember = "Shift_ID";
            // 
            // tblShiftBindingSource
            // 
            this.tblShiftBindingSource.DataMember = "tbl_Shift";
            this.tblShiftBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(448, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Medium:";
            // 
            // comboBox_Medium
            // 
            this.comboBox_Medium.DataSource = this.tblMediumBindingSource;
            this.comboBox_Medium.DisplayMember = "Medium_Desc";
            this.comboBox_Medium.FormattingEnabled = true;
            this.comboBox_Medium.Location = new System.Drawing.Point(451, 38);
            this.comboBox_Medium.Name = "comboBox_Medium";
            this.comboBox_Medium.Size = new System.Drawing.Size(121, 21);
            this.comboBox_Medium.TabIndex = 6;
            this.comboBox_Medium.ValueMember = "Medium_ID";
            // 
            // tblMediumBindingSource
            // 
            this.tblMediumBindingSource.DataMember = "tbl_Medium";
            this.tblMediumBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tabPage_PaidFeeOfAllClass
            // 
            this.tabPage_PaidFeeOfAllClass.Controls.Add(this.button_ShowPaidFeeAllClass);
            this.tabPage_PaidFeeOfAllClass.Location = new System.Drawing.Point(4, 22);
            this.tabPage_PaidFeeOfAllClass.Name = "tabPage_PaidFeeOfAllClass";
            this.tabPage_PaidFeeOfAllClass.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_PaidFeeOfAllClass.Size = new System.Drawing.Size(864, 101);
            this.tabPage_PaidFeeOfAllClass.TabIndex = 1;
            this.tabPage_PaidFeeOfAllClass.Text = "Paid Fee of All Class";
            this.tabPage_PaidFeeOfAllClass.UseVisualStyleBackColor = true;
            // 
            // button_ShowPaidFeeAllClass
            // 
            this.button_ShowPaidFeeAllClass.Image = global::GeneralSchool.Properties.Resources.show_report;
            this.button_ShowPaidFeeAllClass.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_ShowPaidFeeAllClass.Location = new System.Drawing.Point(44, 27);
            this.button_ShowPaidFeeAllClass.Name = "button_ShowPaidFeeAllClass";
            this.button_ShowPaidFeeAllClass.Size = new System.Drawing.Size(176, 39);
            this.button_ShowPaidFeeAllClass.TabIndex = 0;
            this.button_ShowPaidFeeAllClass.Text = "Show Paid Fee of All Class";
            this.button_ShowPaidFeeAllClass.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_ShowPaidFeeAllClass.UseVisualStyleBackColor = true;
            this.button_ShowPaidFeeAllClass.Click += new System.EventHandler(this.button_ShowPaidFeeAllClass_Click);
            // 
            // tabPage_ExemptFeeOfAllClass
            // 
            this.tabPage_ExemptFeeOfAllClass.Controls.Add(this.button_ShowExemptFeeAllClass);
            this.tabPage_ExemptFeeOfAllClass.Location = new System.Drawing.Point(4, 22);
            this.tabPage_ExemptFeeOfAllClass.Name = "tabPage_ExemptFeeOfAllClass";
            this.tabPage_ExemptFeeOfAllClass.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_ExemptFeeOfAllClass.Size = new System.Drawing.Size(864, 101);
            this.tabPage_ExemptFeeOfAllClass.TabIndex = 2;
            this.tabPage_ExemptFeeOfAllClass.Text = "Exempt Fee of All Class";
            this.tabPage_ExemptFeeOfAllClass.UseVisualStyleBackColor = true;
            // 
            // button_ShowExemptFeeAllClass
            // 
            this.button_ShowExemptFeeAllClass.Image = global::GeneralSchool.Properties.Resources.show_report;
            this.button_ShowExemptFeeAllClass.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_ShowExemptFeeAllClass.Location = new System.Drawing.Point(49, 28);
            this.button_ShowExemptFeeAllClass.Name = "button_ShowExemptFeeAllClass";
            this.button_ShowExemptFeeAllClass.Size = new System.Drawing.Size(191, 40);
            this.button_ShowExemptFeeAllClass.TabIndex = 0;
            this.button_ShowExemptFeeAllClass.Text = "Show Exempt Fee of All Class";
            this.button_ShowExemptFeeAllClass.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_ShowExemptFeeAllClass.UseVisualStyleBackColor = true;
            this.button_ShowExemptFeeAllClass.Click += new System.EventHandler(this.button_ShowExemptFeeAllClass_Click);
            // 
            // comboBox_SessionYear
            // 
            this.comboBox_SessionYear.DataSource = this.tblSessionBindingSource;
            this.comboBox_SessionYear.DisplayMember = "Session_Desc";
            this.comboBox_SessionYear.FormattingEnabled = true;
            this.comboBox_SessionYear.Location = new System.Drawing.Point(12, 94);
            this.comboBox_SessionYear.Name = "comboBox_SessionYear";
            this.comboBox_SessionYear.Size = new System.Drawing.Size(121, 21);
            this.comboBox_SessionYear.TabIndex = 4;
            this.comboBox_SessionYear.ValueMember = "Session_ID";
            // 
            // tblSessionBindingSource
            // 
            this.tblSessionBindingSource.DataMember = "tbl_Session";
            this.tblSessionBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Session Year:";
            // 
            // cRViewer_FeeVoucher
            // 
            this.cRViewer_FeeVoucher.ActiveViewIndex = -1;
            this.cRViewer_FeeVoucher.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cRViewer_FeeVoucher.DisplayGroupTree = false;
            this.cRViewer_FeeVoucher.DisplayStatusBar = false;
            this.cRViewer_FeeVoucher.DisplayToolbar = false;
            this.cRViewer_FeeVoucher.Location = new System.Drawing.Point(12, 252);
            this.cRViewer_FeeVoucher.Name = "cRViewer_FeeVoucher";
            this.cRViewer_FeeVoucher.SelectionFormula = "";
            this.cRViewer_FeeVoucher.Size = new System.Drawing.Size(1000, 380);
            this.cRViewer_FeeVoucher.TabIndex = 0;
            this.cRViewer_FeeVoucher.ViewTimeSelectionFormula = "";
            // 
            // tbl_ClassTableAdapter
            // 
            this.tbl_ClassTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_SectionTableAdapter
            // 
            this.tbl_SectionTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_SessionTableAdapter
            // 
            this.tbl_SessionTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_ShiftTableAdapter
            // 
            this.tbl_ShiftTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_MediumTableAdapter
            // 
            this.tbl_MediumTableAdapter.ClearBeforeFill = true;
            // 
            // checkBox_FeeClosingCompleted
            // 
            this.checkBox_FeeClosingCompleted.AutoSize = true;
            this.checkBox_FeeClosingCompleted.Enabled = false;
            this.checkBox_FeeClosingCompleted.Location = new System.Drawing.Point(156, 80);
            this.checkBox_FeeClosingCompleted.Name = "checkBox_FeeClosingCompleted";
            this.checkBox_FeeClosingCompleted.Size = new System.Drawing.Size(134, 17);
            this.checkBox_FeeClosingCompleted.TabIndex = 1;
            this.checkBox_FeeClosingCompleted.Text = "Fee Closing Completed";
            this.checkBox_FeeClosingCompleted.UseVisualStyleBackColor = true;
            // 
            // label_SumFee
            // 
            this.label_SumFee.AutoSize = true;
            this.label_SumFee.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_SumFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SumFee.ForeColor = System.Drawing.Color.DarkRed;
            this.label_SumFee.Location = new System.Drawing.Point(156, 100);
            this.label_SumFee.Name = "label_SumFee";
            this.label_SumFee.Size = new System.Drawing.Size(71, 15);
            this.label_SumFee.TabIndex = 3;
            this.label_SumFee.Text = "Total Fee  ";
            // 
            // Form_Fee_Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 746);
            this.Controls.Add(this.comboBox_SessionYear);
            this.Controls.Add(this.label_SumFee);
            this.Controls.Add(this.cRViewer_FeeVoucher);
            this.Controls.Add(this.checkBox_FeeClosingCompleted);
            this.Controls.Add(this.tabControl_Fee_Report);
            this.Controls.Add(this.label3);
            this.Name = "Form_Fee_Reports";
            this.Text = "Fee Reports";
            this.Load += new System.EventHandler(this.Form_Fee_Reports_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Fee_Reports_FormClosing);
            this.tabControl_Fee_Report.ResumeLayout(false);
            this.tabPage_Report1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblClassBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSectionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblShiftBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblMediumBindingSource)).EndInit();
            this.tabPage_PaidFeeOfAllClass.ResumeLayout(false);
            this.tabPage_ExemptFeeOfAllClass.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tblSessionBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl_Fee_Report;
        private System.Windows.Forms.TabPage tabPage_Report1;
        private System.Windows.Forms.TabPage tabPage_PaidFeeOfAllClass;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer cRViewer_FeeVoucher;
        private System.Windows.Forms.Button btn_ShowReport;
        private System.Windows.Forms.ComboBox comboBox_Class;
        private System.Windows.Forms.ComboBox comboBox_Section;
        private System.Windows.Forms.ComboBox comboBox_SessionYear;
        private System.Windows.Forms.ComboBox comboBox_Shift;
        private System.Windows.Forms.ComboBox comboBox_Medium;
        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tblClassBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ClassTableAdapter tbl_ClassTableAdapter;
        private System.Windows.Forms.BindingSource tblSectionBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SectionTableAdapter tbl_SectionTableAdapter;
        private System.Windows.Forms.BindingSource tblSessionBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SessionTableAdapter tbl_SessionTableAdapter;
        private System.Windows.Forms.BindingSource tblShiftBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ShiftTableAdapter tbl_ShiftTableAdapter;
        private System.Windows.Forms.BindingSource tblMediumBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_MediumTableAdapter tbl_MediumTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox_FeeClosingCompleted;
        private System.Windows.Forms.Label label_SumFee;
        private System.Windows.Forms.TabPage tabPage_ExemptFeeOfAllClass;
        private System.Windows.Forms.Button button_ShowPaidFeeAllClass;
        private System.Windows.Forms.Button button_ShowExemptFeeAllClass;
    }
}