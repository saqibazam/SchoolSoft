using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_School : Form
    {
        public Form_School()
        {
            InitializeComponent();
        }

        private void tbl_SchoolBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_SchoolBindingSource.EndEdit();
            this.tbl_SchoolTableAdapter.Update(this.schoolDbDataSet.tbl_School);
            tbl_SchoolBindingNavigatorSaveItem.Enabled = false;
            MessageBox.Show("Record has been saved successfully.....Press OK to continue...", "Record has been saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            disableControls();
            btn_EditData.Enabled = true ;
        }

        private void Form_School_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_School' table. You can move, or remove it, as needed.
            this.tbl_SchoolTableAdapter.Fill(this.schoolDbDataSet.tbl_School);
            disableControls();

        }

       private void  disableControls()
        {
            school_NameTextBox.Enabled = false;
            owner_NameTextBox.Enabled = false;
            principal_NameTextBox.Enabled = false;
            established_DateDateTimePicker.Enabled = false;
            school_AddressTextBox.Enabled = false;
            school_PhoneTextBox.Enabled = false;
            school_WebsiteTextBox.Enabled = false;
            school_EmailTextBox.Enabled = false;
            tbl_SchoolBindingNavigatorSaveItem.Enabled = false ;
        }

        private void Form_School_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.School = false;
        }
        private Form_PasswordDialog _passDlg = new Form_PasswordDialog ();
        private Form_Login frmLogin = new Form_Login();
        private void btn_EditData_Click(object sender, EventArgs e)
        {
        DialogResult dialogResult = _passDlg.ShowDialog(this);
        if ((dialogResult == DialogResult.OK) && (_passDlg.Password == "15March2011915"))
        {
            _passDlg.textBoxPassword.Text = "";
            //get user/password values from dialog
            //MessageBox.Show(_passDlg.Password);
            school_NameTextBox.Enabled = true ;
            owner_NameTextBox.Enabled = true ;
            principal_NameTextBox.Enabled = true ;
            established_DateDateTimePicker.Enabled = true ;
            school_AddressTextBox.Enabled = true ;
            school_PhoneTextBox.Enabled = true ;
            school_WebsiteTextBox.Enabled = true ;
            school_EmailTextBox.Enabled = true;
            btn_EditData.Enabled = false;
            tbl_SchoolBindingNavigatorSaveItem.Enabled = true;
        }
        else if ((dialogResult == DialogResult.OK) && (_passDlg.Password == frmLogin.checkUserPass("Admin")))
        {
            _passDlg.textBoxPassword.Text = "";
            school_NameTextBox.Enabled = false;
            owner_NameTextBox.Enabled = true;
            principal_NameTextBox.Enabled = true;
            established_DateDateTimePicker.Enabled = true;
            school_AddressTextBox.Enabled = false;
            school_PhoneTextBox.Enabled = false;
            school_WebsiteTextBox.Enabled = true;
            school_EmailTextBox.Enabled = true;
            btn_EditData.Enabled = false;
            tbl_SchoolBindingNavigatorSaveItem.Enabled = true;
        }
        else if (dialogResult == DialogResult.Cancel)
        {}
        else 
        {
            _passDlg.textBoxPassword.Text = "";
            MessageBox.Show("Invalid Password.....Press OK to continue...", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Information);
          
        
        }
            
            
        }
    }
}