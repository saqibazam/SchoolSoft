namespace GeneralSchool
{
    partial class Form_Class_Section_Shift_Medium_Define
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label smcsd_IDLabel;
            System.Windows.Forms.Label class_CapacityLabel;
            System.Windows.Forms.Label class_RoomSizeLabel;
            System.Windows.Forms.Label class_RoomNoLabel;
            System.Windows.Forms.Label class_CodeLabel;
            System.Windows.Forms.Label shift_IDLabel;
            System.Windows.Forms.Label medium_IDLabel;
            System.Windows.Forms.Label class_IDLabel;
            System.Windows.Forms.Label section_IDLabel;
            System.Windows.Forms.Label class_DetailLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Class_Section_Shift_Medium_Define));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tbl_SMCS_DefineBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.tbl_SMCS_DefineBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_SMCS_DefineBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_Edit = new System.Windows.Forms.ToolStripButton();
            this.tbl_SMCS_DefineDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Class_Detail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.smcsd_IDTextBox = new System.Windows.Forms.TextBox();
            this.class_CapacityTextBox = new System.Windows.Forms.TextBox();
            this.class_RoomSizeTextBox = new System.Windows.Forms.TextBox();
            this.class_RoomNoTextBox = new System.Windows.Forms.TextBox();
            this.class_CodeTextBox = new System.Windows.Forms.TextBox();
            this.shift_IDComboBox = new System.Windows.Forms.ComboBox();
            this.tblShiftBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.medium_IDComboBox = new System.Windows.Forms.ComboBox();
            this.tblMediumBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.class_IDComboBox = new System.Windows.Forms.ComboBox();
            this.tblClassBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.section_IDComboBox = new System.Windows.Forms.ComboBox();
            this.tblSectionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.class_DetailTextBox = new System.Windows.Forms.TextBox();
            this.tbl_SMCS_DefineTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SMCS_DefineTableAdapter();
            this.tbl_ShiftTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ShiftTableAdapter();
            this.tbl_MediumTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_MediumTableAdapter();
            this.tbl_ClassTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ClassTableAdapter();
            this.tbl_SectionTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SectionTableAdapter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_EnableAddEdit = new System.Windows.Forms.Button();
            smcsd_IDLabel = new System.Windows.Forms.Label();
            class_CapacityLabel = new System.Windows.Forms.Label();
            class_RoomSizeLabel = new System.Windows.Forms.Label();
            class_RoomNoLabel = new System.Windows.Forms.Label();
            class_CodeLabel = new System.Windows.Forms.Label();
            shift_IDLabel = new System.Windows.Forms.Label();
            medium_IDLabel = new System.Windows.Forms.Label();
            class_IDLabel = new System.Windows.Forms.Label();
            section_IDLabel = new System.Windows.Forms.Label();
            class_DetailLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SMCS_DefineBindingNavigator)).BeginInit();
            this.tbl_SMCS_DefineBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SMCS_DefineBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SMCS_DefineDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblShiftBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblMediumBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblClassBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSectionBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // smcsd_IDLabel
            // 
            smcsd_IDLabel.AutoSize = true;
            smcsd_IDLabel.Location = new System.Drawing.Point(50, 28);
            smcsd_IDLabel.Name = "smcsd_IDLabel";
            smcsd_IDLabel.Size = new System.Drawing.Size(56, 13);
            smcsd_IDLabel.TabIndex = 2;
            smcsd_IDLabel.Text = "Smcsd ID:";
            // 
            // class_CapacityLabel
            // 
            class_CapacityLabel.AutoSize = true;
            class_CapacityLabel.Location = new System.Drawing.Point(27, 158);
            class_CapacityLabel.Name = "class_CapacityLabel";
            class_CapacityLabel.Size = new System.Drawing.Size(79, 13);
            class_CapacityLabel.TabIndex = 12;
            class_CapacityLabel.Text = "Class Capacity:";
            // 
            // class_RoomSizeLabel
            // 
            class_RoomSizeLabel.AutoSize = true;
            class_RoomSizeLabel.Location = new System.Drawing.Point(27, 184);
            class_RoomSizeLabel.Name = "class_RoomSizeLabel";
            class_RoomSizeLabel.Size = new System.Drawing.Size(89, 13);
            class_RoomSizeLabel.TabIndex = 14;
            class_RoomSizeLabel.Text = "Class Room Size:";
            // 
            // class_RoomNoLabel
            // 
            class_RoomNoLabel.AutoSize = true;
            class_RoomNoLabel.Location = new System.Drawing.Point(27, 210);
            class_RoomNoLabel.Name = "class_RoomNoLabel";
            class_RoomNoLabel.Size = new System.Drawing.Size(83, 13);
            class_RoomNoLabel.TabIndex = 16;
            class_RoomNoLabel.Text = "Class Room No:";
            // 
            // class_CodeLabel
            // 
            class_CodeLabel.AutoSize = true;
            class_CodeLabel.Location = new System.Drawing.Point(16, 488);
            class_CodeLabel.Name = "class_CodeLabel";
            class_CodeLabel.Size = new System.Drawing.Size(63, 13);
            class_CodeLabel.TabIndex = 18;
            class_CodeLabel.Text = "Class Code:";
            // 
            // shift_IDLabel
            // 
            shift_IDLabel.AutoSize = true;
            shift_IDLabel.Location = new System.Drawing.Point(61, 51);
            shift_IDLabel.Name = "shift_IDLabel";
            shift_IDLabel.Size = new System.Drawing.Size(45, 13);
            shift_IDLabel.TabIndex = 19;
            shift_IDLabel.Text = "Shift ID:";
            // 
            // medium_IDLabel
            // 
            medium_IDLabel.AutoSize = true;
            medium_IDLabel.Location = new System.Drawing.Point(45, 78);
            medium_IDLabel.Name = "medium_IDLabel";
            medium_IDLabel.Size = new System.Drawing.Size(61, 13);
            medium_IDLabel.TabIndex = 20;
            medium_IDLabel.Text = "Medium ID:";
            // 
            // class_IDLabel
            // 
            class_IDLabel.AutoSize = true;
            class_IDLabel.Location = new System.Drawing.Point(57, 105);
            class_IDLabel.Name = "class_IDLabel";
            class_IDLabel.Size = new System.Drawing.Size(49, 13);
            class_IDLabel.TabIndex = 21;
            class_IDLabel.Text = "Class ID:";
            // 
            // section_IDLabel
            // 
            section_IDLabel.AutoSize = true;
            section_IDLabel.Location = new System.Drawing.Point(46, 132);
            section_IDLabel.Name = "section_IDLabel";
            section_IDLabel.Size = new System.Drawing.Size(60, 13);
            section_IDLabel.TabIndex = 22;
            section_IDLabel.Text = "Section ID:";
            // 
            // class_DetailLabel
            // 
            class_DetailLabel.AutoSize = true;
            class_DetailLabel.Location = new System.Drawing.Point(184, 488);
            class_DetailLabel.Name = "class_DetailLabel";
            class_DetailLabel.Size = new System.Drawing.Size(65, 13);
            class_DetailLabel.TabIndex = 24;
            class_DetailLabel.Text = "Class Detail:";
            // 
            // tbl_SMCS_DefineBindingNavigator
            // 
            this.tbl_SMCS_DefineBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_SMCS_DefineBindingNavigator.BindingSource = this.tbl_SMCS_DefineBindingSource;
            this.tbl_SMCS_DefineBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_SMCS_DefineBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_SMCS_DefineBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.tbl_SMCS_DefineBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_SMCS_DefineBindingNavigatorSaveItem,
            this.toolStripButton_Edit});
            this.tbl_SMCS_DefineBindingNavigator.Location = new System.Drawing.Point(12, 356);
            this.tbl_SMCS_DefineBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_SMCS_DefineBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_SMCS_DefineBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_SMCS_DefineBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_SMCS_DefineBindingNavigator.Name = "tbl_SMCS_DefineBindingNavigator";
            this.tbl_SMCS_DefineBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_SMCS_DefineBindingNavigator.Size = new System.Drawing.Size(427, 25);
            this.tbl_SMCS_DefineBindingNavigator.TabIndex = 0;
            this.tbl_SMCS_DefineBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(69, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // tbl_SMCS_DefineBindingSource
            // 
            this.tbl_SMCS_DefineBindingSource.DataMember = "tbl_SMCS_Define";
            this.tbl_SMCS_DefineBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Enabled = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_SMCS_DefineBindingNavigatorSaveItem
            // 
            this.tbl_SMCS_DefineBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_SMCS_DefineBindingNavigatorSaveItem.Image")));
            this.tbl_SMCS_DefineBindingNavigatorSaveItem.Name = "tbl_SMCS_DefineBindingNavigatorSaveItem";
            this.tbl_SMCS_DefineBindingNavigatorSaveItem.Size = new System.Drawing.Size(77, 22);
            this.tbl_SMCS_DefineBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_SMCS_DefineBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_SMCS_DefineBindingNavigatorSaveItem_Click);
            // 
            // toolStripButton_Edit
            // 
            this.toolStripButton_Edit.Image = global::GeneralSchool.Properties.Resources.edit;
            this.toolStripButton_Edit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_Edit.Name = "toolStripButton_Edit";
            this.toolStripButton_Edit.Size = new System.Drawing.Size(71, 22);
            this.toolStripButton_Edit.Text = "Edit Data";
            this.toolStripButton_Edit.Click += new System.EventHandler(this.toolStripButton_Edit_Click);
            // 
            // tbl_SMCS_DefineDataGridView
            // 
            this.tbl_SMCS_DefineDataGridView.AllowUserToAddRows = false;
            this.tbl_SMCS_DefineDataGridView.AllowUserToDeleteRows = false;
            this.tbl_SMCS_DefineDataGridView.AllowUserToResizeColumns = false;
            this.tbl_SMCS_DefineDataGridView.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tbl_SMCS_DefineDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.tbl_SMCS_DefineDataGridView.AutoGenerateColumns = false;
            this.tbl_SMCS_DefineDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.tbl_SMCS_DefineDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.Class_Detail,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.tbl_SMCS_DefineDataGridView.DataSource = this.tbl_SMCS_DefineBindingSource;
            this.tbl_SMCS_DefineDataGridView.Location = new System.Drawing.Point(12, 384);
            this.tbl_SMCS_DefineDataGridView.Name = "tbl_SMCS_DefineDataGridView";
            this.tbl_SMCS_DefineDataGridView.ReadOnly = true;
            this.tbl_SMCS_DefineDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.tbl_SMCS_DefineDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tbl_SMCS_DefineDataGridView.Size = new System.Drawing.Size(752, 183);
            this.tbl_SMCS_DefineDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Smcsd_ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 30;
            // 
            // Class_Detail
            // 
            this.Class_Detail.DataPropertyName = "Class_Detail";
            this.Class_Detail.HeaderText = "Class Detail";
            this.Class_Detail.Name = "Class_Detail";
            this.Class_Detail.ReadOnly = true;
            this.Class_Detail.Width = 400;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Shift_ID";
            this.dataGridViewTextBoxColumn2.HeaderText = "Shift_ID";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Visible = false;
            this.dataGridViewTextBoxColumn2.Width = 50;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Medium_ID";
            this.dataGridViewTextBoxColumn3.HeaderText = "Medium_ID";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Class_ID";
            this.dataGridViewTextBoxColumn4.HeaderText = "Class_ID";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Visible = false;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Section_ID";
            this.dataGridViewTextBoxColumn5.HeaderText = "Section_ID";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Visible = false;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Class_Capacity";
            this.dataGridViewTextBoxColumn6.HeaderText = "Capacity";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 60;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Class_RoomSize";
            this.dataGridViewTextBoxColumn7.HeaderText = "Room Size";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 70;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Class_RoomNo";
            this.dataGridViewTextBoxColumn8.HeaderText = "Room No";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 60;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Class_Code";
            this.dataGridViewTextBoxColumn9.HeaderText = "Class Code";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 70;
            // 
            // smcsd_IDTextBox
            // 
            this.smcsd_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SMCS_DefineBindingSource, "Smcsd_ID", true));
            this.smcsd_IDTextBox.Enabled = false;
            this.smcsd_IDTextBox.Location = new System.Drawing.Point(122, 25);
            this.smcsd_IDTextBox.Name = "smcsd_IDTextBox";
            this.smcsd_IDTextBox.Size = new System.Drawing.Size(36, 20);
            this.smcsd_IDTextBox.TabIndex = 3;
            // 
            // class_CapacityTextBox
            // 
            this.class_CapacityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SMCS_DefineBindingSource, "Class_Capacity", true));
            this.class_CapacityTextBox.Location = new System.Drawing.Point(122, 155);
            this.class_CapacityTextBox.Name = "class_CapacityTextBox";
            this.class_CapacityTextBox.Size = new System.Drawing.Size(60, 20);
            this.class_CapacityTextBox.TabIndex = 13;
            // 
            // class_RoomSizeTextBox
            // 
            this.class_RoomSizeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SMCS_DefineBindingSource, "Class_RoomSize", true));
            this.class_RoomSizeTextBox.Location = new System.Drawing.Point(122, 181);
            this.class_RoomSizeTextBox.Name = "class_RoomSizeTextBox";
            this.class_RoomSizeTextBox.Size = new System.Drawing.Size(60, 20);
            this.class_RoomSizeTextBox.TabIndex = 15;
            // 
            // class_RoomNoTextBox
            // 
            this.class_RoomNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SMCS_DefineBindingSource, "Class_RoomNo", true));
            this.class_RoomNoTextBox.Location = new System.Drawing.Point(122, 207);
            this.class_RoomNoTextBox.Name = "class_RoomNoTextBox";
            this.class_RoomNoTextBox.Size = new System.Drawing.Size(60, 20);
            this.class_RoomNoTextBox.TabIndex = 17;
            // 
            // class_CodeTextBox
            // 
            this.class_CodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SMCS_DefineBindingSource, "Class_Code", true));
            this.class_CodeTextBox.Enabled = false;
            this.class_CodeTextBox.Location = new System.Drawing.Point(111, 485);
            this.class_CodeTextBox.Name = "class_CodeTextBox";
            this.class_CodeTextBox.Size = new System.Drawing.Size(60, 20);
            this.class_CodeTextBox.TabIndex = 19;
            // 
            // shift_IDComboBox
            // 
            this.shift_IDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tbl_SMCS_DefineBindingSource, "Shift_ID", true));
            this.shift_IDComboBox.DataSource = this.tblShiftBindingSource;
            this.shift_IDComboBox.DisplayMember = "Shift_Desc";
            this.shift_IDComboBox.FormattingEnabled = true;
            this.shift_IDComboBox.Location = new System.Drawing.Point(122, 51);
            this.shift_IDComboBox.Name = "shift_IDComboBox";
            this.shift_IDComboBox.Size = new System.Drawing.Size(100, 21);
            this.shift_IDComboBox.TabIndex = 20;
            this.shift_IDComboBox.ValueMember = "Shift_ID";
            // 
            // tblShiftBindingSource
            // 
            this.tblShiftBindingSource.DataMember = "tbl_Shift";
            this.tblShiftBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // medium_IDComboBox
            // 
            this.medium_IDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tbl_SMCS_DefineBindingSource, "Medium_ID", true));
            this.medium_IDComboBox.DataSource = this.tblMediumBindingSource;
            this.medium_IDComboBox.DisplayMember = "Medium_Desc";
            this.medium_IDComboBox.FormattingEnabled = true;
            this.medium_IDComboBox.Location = new System.Drawing.Point(122, 78);
            this.medium_IDComboBox.Name = "medium_IDComboBox";
            this.medium_IDComboBox.Size = new System.Drawing.Size(100, 21);
            this.medium_IDComboBox.TabIndex = 21;
            this.medium_IDComboBox.ValueMember = "Medium_ID";
            // 
            // tblMediumBindingSource
            // 
            this.tblMediumBindingSource.DataMember = "tbl_Medium";
            this.tblMediumBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // class_IDComboBox
            // 
            this.class_IDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tbl_SMCS_DefineBindingSource, "Class_ID", true));
            this.class_IDComboBox.DataSource = this.tblClassBindingSource;
            this.class_IDComboBox.DisplayMember = "Class_Desc";
            this.class_IDComboBox.FormattingEnabled = true;
            this.class_IDComboBox.Location = new System.Drawing.Point(122, 105);
            this.class_IDComboBox.Name = "class_IDComboBox";
            this.class_IDComboBox.Size = new System.Drawing.Size(100, 21);
            this.class_IDComboBox.TabIndex = 22;
            this.class_IDComboBox.ValueMember = "Class_ID";
            // 
            // tblClassBindingSource
            // 
            this.tblClassBindingSource.DataMember = "tbl_Class";
            this.tblClassBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // section_IDComboBox
            // 
            this.section_IDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tbl_SMCS_DefineBindingSource, "Section_ID", true));
            this.section_IDComboBox.DataSource = this.tblSectionBindingSource;
            this.section_IDComboBox.DisplayMember = "Section_Desc";
            this.section_IDComboBox.FormattingEnabled = true;
            this.section_IDComboBox.Location = new System.Drawing.Point(122, 132);
            this.section_IDComboBox.Name = "section_IDComboBox";
            this.section_IDComboBox.Size = new System.Drawing.Size(100, 21);
            this.section_IDComboBox.TabIndex = 23;
            this.section_IDComboBox.ValueMember = "Section_ID";
            // 
            // tblSectionBindingSource
            // 
            this.tblSectionBindingSource.DataMember = "tbl_Section";
            this.tblSectionBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // class_DetailTextBox
            // 
            this.class_DetailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SMCS_DefineBindingSource, "Class_Detail", true));
            this.class_DetailTextBox.Enabled = false;
            this.class_DetailTextBox.Location = new System.Drawing.Point(255, 485);
            this.class_DetailTextBox.Name = "class_DetailTextBox";
            this.class_DetailTextBox.Size = new System.Drawing.Size(337, 20);
            this.class_DetailTextBox.TabIndex = 25;
            // 
            // tbl_SMCS_DefineTableAdapter
            // 
            this.tbl_SMCS_DefineTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_ShiftTableAdapter
            // 
            this.tbl_ShiftTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_MediumTableAdapter
            // 
            this.tbl_MediumTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_ClassTableAdapter
            // 
            this.tbl_ClassTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_SectionTableAdapter
            // 
            this.tbl_SectionTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_EnableAddEdit);
            this.groupBox1.Controls.Add(this.shift_IDComboBox);
            this.groupBox1.Controls.Add(this.class_RoomNoTextBox);
            this.groupBox1.Controls.Add(class_RoomNoLabel);
            this.groupBox1.Controls.Add(this.class_RoomSizeTextBox);
            this.groupBox1.Controls.Add(section_IDLabel);
            this.groupBox1.Controls.Add(class_RoomSizeLabel);
            this.groupBox1.Controls.Add(this.section_IDComboBox);
            this.groupBox1.Controls.Add(this.class_CapacityTextBox);
            this.groupBox1.Controls.Add(class_IDLabel);
            this.groupBox1.Controls.Add(class_CapacityLabel);
            this.groupBox1.Controls.Add(this.class_IDComboBox);
            this.groupBox1.Controls.Add(this.smcsd_IDTextBox);
            this.groupBox1.Controls.Add(medium_IDLabel);
            this.groupBox1.Controls.Add(smcsd_IDLabel);
            this.groupBox1.Controls.Add(this.medium_IDComboBox);
            this.groupBox1.Controls.Add(shift_IDLabel);
            this.groupBox1.Location = new System.Drawing.Point(12, 90);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(402, 244);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Define Class, Section, Shift and Medium";
            // 
            // button_EnableAddEdit
            // 
            this.button_EnableAddEdit.Image = global::GeneralSchool.Properties.Resources.enable_add_edit;
            this.button_EnableAddEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_EnableAddEdit.Location = new System.Drawing.Point(256, 25);
            this.button_EnableAddEdit.Name = "button_EnableAddEdit";
            this.button_EnableAddEdit.Size = new System.Drawing.Size(129, 42);
            this.button_EnableAddEdit.TabIndex = 24;
            this.button_EnableAddEdit.Text = "Enable Add Edit";
            this.button_EnableAddEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_EnableAddEdit.UseVisualStyleBackColor = true;
            this.button_EnableAddEdit.Click += new System.EventHandler(this.button_EnableAddEdit_Click);
            // 
            // Form_Class_Section_Shift_Medium_Define
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(790, 615);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tbl_SMCS_DefineDataGridView);
            this.Controls.Add(class_DetailLabel);
            this.Controls.Add(this.class_DetailTextBox);
            this.Controls.Add(class_CodeLabel);
            this.Controls.Add(this.class_CodeTextBox);
            this.Controls.Add(this.tbl_SMCS_DefineBindingNavigator);
            this.Name = "Form_Class_Section_Shift_Medium_Define";
            this.Text = "Class Section Shift and Medium Define";
            this.Load += new System.EventHandler(this.Form_Class_Section_Shift_Medium_Define_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Class_Section_Shift_Medium_Define_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SMCS_DefineBindingNavigator)).EndInit();
            this.tbl_SMCS_DefineBindingNavigator.ResumeLayout(false);
            this.tbl_SMCS_DefineBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SMCS_DefineBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SMCS_DefineDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblShiftBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblMediumBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblClassBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSectionBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tbl_SMCS_DefineBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SMCS_DefineTableAdapter tbl_SMCS_DefineTableAdapter;
        private System.Windows.Forms.BindingNavigator tbl_SMCS_DefineBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_SMCS_DefineBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView tbl_SMCS_DefineDataGridView;
        private System.Windows.Forms.TextBox smcsd_IDTextBox;
        private System.Windows.Forms.TextBox class_CapacityTextBox;
        private System.Windows.Forms.TextBox class_RoomSizeTextBox;
        private System.Windows.Forms.TextBox class_RoomNoTextBox;
        private System.Windows.Forms.TextBox class_CodeTextBox;
        private System.Windows.Forms.ComboBox shift_IDComboBox;
        private System.Windows.Forms.ComboBox medium_IDComboBox;
        private System.Windows.Forms.ComboBox class_IDComboBox;
        private System.Windows.Forms.ComboBox section_IDComboBox;
        private System.Windows.Forms.BindingSource tblShiftBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ShiftTableAdapter tbl_ShiftTableAdapter;
        private System.Windows.Forms.BindingSource tblMediumBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_MediumTableAdapter tbl_MediumTableAdapter;
        private System.Windows.Forms.BindingSource tblClassBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ClassTableAdapter tbl_ClassTableAdapter;
        private System.Windows.Forms.BindingSource tblSectionBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SectionTableAdapter tbl_SectionTableAdapter;
        private System.Windows.Forms.TextBox class_DetailTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Class_Detail;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.ToolStripButton toolStripButton_Edit;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_EnableAddEdit;
    }
}