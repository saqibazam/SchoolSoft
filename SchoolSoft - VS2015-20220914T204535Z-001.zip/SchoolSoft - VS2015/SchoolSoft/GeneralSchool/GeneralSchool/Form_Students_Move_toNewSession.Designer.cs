namespace GeneralSchool
{
    partial class Form_Students_Move_toNewSession
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Students_Move_toNewSession));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl_Students_Move_Session = new System.Windows.Forms.TabControl();
            this.tabPage_PassOut_LastClass = new System.Windows.Forms.TabPage();
            this.checkBox_PassOutStudents = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_MarkPassOut = new System.Windows.Forms.Button();
            this.cmbClassDetail = new System.Windows.Forms.ComboBox();
            this.tabPage_MoveToNew_Session = new System.Windows.Forms.TabPage();
            this.checkBox_MovedAllStudentsToNewSession = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmb_Session = new System.Windows.Forms.ComboBox();
            this.tblSessionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.btn_MoveSession = new System.Windows.Forms.Button();
            this.tabPage_MoveTo_NewClass = new System.Windows.Forms.TabPage();
            this.checkBox_MovedToNewClass = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbClassDetailOne = new System.Windows.Forms.ComboBox();
            this.cmbClassDetailTwo = new System.Windows.Forms.ComboBox();
            this.btn_MoveToNewClass = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage_AssignRollNo = new System.Windows.Forms.TabPage();
            this.checkBox_AssignedRollNumbers = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_AssignRoll = new System.Windows.Forms.Button();
            this.cmb_ClassDetailThree = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage_IrRegularChanges = new System.Windows.Forms.TabPage();
            this.btn_Enable_Delete_Save = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbClassDetailFour = new System.Windows.Forms.ComboBox();
            this.tbl_Student_MovementBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.tbl_Student_MovementBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_Student_MovementBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.tblResultBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingSource_ClassDetail = new System.Windows.Forms.BindingSource(this.components);
            this.tblSMCSDefineBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_Student_MovementTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Student_MovementTableAdapter();
            this.tbl_SMCS_DefineTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SMCS_DefineTableAdapter();
            this.tbl_ResultTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ResultTableAdapter();
            this.tbl_SessionTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SessionTableAdapter();
            this.viewClassDetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view_ClassDetailTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.View_ClassDetailTableAdapter();
            this.viewClassDetailTwoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view_ClassDetailTwoTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.View_ClassDetailTwoTableAdapter();
            this.tbl_Student_MovementDataGridView = new System.Windows.Forms.DataGridView();
            this.stMovIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gRNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sessionIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.resultIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.percentageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rollDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.smcsdIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewClassDetailThreeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view_ClassDetailThreeTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.View_ClassDetailThreeTableAdapter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabControl_Students_Move_Session.SuspendLayout();
            this.tabPage_PassOut_LastClass.SuspendLayout();
            this.tabPage_MoveToNew_Session.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblSessionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            this.tabPage_MoveTo_NewClass.SuspendLayout();
            this.tabPage_AssignRollNo.SuspendLayout();
            this.tabPage_IrRegularChanges.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Student_MovementBindingNavigator)).BeginInit();
            this.tbl_Student_MovementBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Student_MovementBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblResultBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource_ClassDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSMCSDefineBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewClassDetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewClassDetailTwoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Student_MovementDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewClassDetailThreeBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl_Students_Move_Session
            // 
            this.tabControl_Students_Move_Session.Controls.Add(this.tabPage_PassOut_LastClass);
            this.tabControl_Students_Move_Session.Controls.Add(this.tabPage_MoveToNew_Session);
            this.tabControl_Students_Move_Session.Controls.Add(this.tabPage_MoveTo_NewClass);
            this.tabControl_Students_Move_Session.Controls.Add(this.tabPage_AssignRollNo);
            this.tabControl_Students_Move_Session.Controls.Add(this.tabPage_IrRegularChanges);
            this.tabControl_Students_Move_Session.Location = new System.Drawing.Point(6, 19);
            this.tabControl_Students_Move_Session.Name = "tabControl_Students_Move_Session";
            this.tabControl_Students_Move_Session.SelectedIndex = 0;
            this.tabControl_Students_Move_Session.Size = new System.Drawing.Size(735, 182);
            this.tabControl_Students_Move_Session.TabIndex = 3;
            this.tabControl_Students_Move_Session.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_Students_Move_Session_Selecting);
            this.tabControl_Students_Move_Session.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl_Students_Move_Session_Selected);
            // 
            // tabPage_PassOut_LastClass
            // 
            this.tabPage_PassOut_LastClass.AutoScroll = true;
            this.tabPage_PassOut_LastClass.Controls.Add(this.checkBox_PassOutStudents);
            this.tabPage_PassOut_LastClass.Controls.Add(this.label8);
            this.tabPage_PassOut_LastClass.Controls.Add(this.label2);
            this.tabPage_PassOut_LastClass.Controls.Add(this.btn_MarkPassOut);
            this.tabPage_PassOut_LastClass.Controls.Add(this.cmbClassDetail);
            this.tabPage_PassOut_LastClass.Location = new System.Drawing.Point(4, 22);
            this.tabPage_PassOut_LastClass.Name = "tabPage_PassOut_LastClass";
            this.tabPage_PassOut_LastClass.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_PassOut_LastClass.Size = new System.Drawing.Size(727, 156);
            this.tabPage_PassOut_LastClass.TabIndex = 0;
            this.tabPage_PassOut_LastClass.Text = "Pass Out Last Class";
            this.tabPage_PassOut_LastClass.UseVisualStyleBackColor = true;
            // 
            // checkBox_PassOutStudents
            // 
            this.checkBox_PassOutStudents.AutoSize = true;
            this.checkBox_PassOutStudents.Enabled = false;
            this.checkBox_PassOutStudents.ForeColor = System.Drawing.Color.Blue;
            this.checkBox_PassOutStudents.Location = new System.Drawing.Point(316, 43);
            this.checkBox_PassOutStudents.Name = "checkBox_PassOutStudents";
            this.checkBox_PassOutStudents.Size = new System.Drawing.Size(177, 17);
            this.checkBox_PassOutStudents.TabIndex = 9;
            this.checkBox_PassOutStudents.Text = "Passed Out Last Class Students";
            this.checkBox_PassOutStudents.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 80);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Search By Class:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(6, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(592, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Select Last Class in the Drop Down List, and Click on Mark Pass Out Button to Pas" +
                "s Out Last Class Students.";
            // 
            // btn_MarkPassOut
            // 
            this.btn_MarkPassOut.Image = global::GeneralSchool.Properties.Resources.check_2_;
            this.btn_MarkPassOut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_MarkPassOut.Location = new System.Drawing.Point(526, 67);
            this.btn_MarkPassOut.Name = "btn_MarkPassOut";
            this.btn_MarkPassOut.Size = new System.Drawing.Size(168, 39);
            this.btn_MarkPassOut.TabIndex = 1;
            this.btn_MarkPassOut.Text = "Mark Pass Out Last Class";
            this.btn_MarkPassOut.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_MarkPassOut.UseVisualStyleBackColor = true;
            this.btn_MarkPassOut.Click += new System.EventHandler(this.btn_MarkPassOut_Click);
            // 
            // cmbClassDetail
            // 
            this.cmbClassDetail.FormattingEnabled = true;
            this.cmbClassDetail.Location = new System.Drawing.Point(99, 77);
            this.cmbClassDetail.Name = "cmbClassDetail";
            this.cmbClassDetail.Size = new System.Drawing.Size(394, 21);
            this.cmbClassDetail.TabIndex = 0;
            this.cmbClassDetail.SelectedIndexChanged += new System.EventHandler(this.cmbClassDetail_SelectedIndexChanged);
            // 
            // tabPage_MoveToNew_Session
            // 
            this.tabPage_MoveToNew_Session.Controls.Add(this.checkBox_MovedAllStudentsToNewSession);
            this.tabPage_MoveToNew_Session.Controls.Add(this.label9);
            this.tabPage_MoveToNew_Session.Controls.Add(this.label3);
            this.tabPage_MoveToNew_Session.Controls.Add(this.cmb_Session);
            this.tabPage_MoveToNew_Session.Controls.Add(this.btn_MoveSession);
            this.tabPage_MoveToNew_Session.Location = new System.Drawing.Point(4, 22);
            this.tabPage_MoveToNew_Session.Name = "tabPage_MoveToNew_Session";
            this.tabPage_MoveToNew_Session.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_MoveToNew_Session.Size = new System.Drawing.Size(727, 156);
            this.tabPage_MoveToNew_Session.TabIndex = 1;
            this.tabPage_MoveToNew_Session.Text = "Move To New Session";
            this.tabPage_MoveToNew_Session.UseVisualStyleBackColor = true;
            // 
            // checkBox_MovedAllStudentsToNewSession
            // 
            this.checkBox_MovedAllStudentsToNewSession.AutoSize = true;
            this.checkBox_MovedAllStudentsToNewSession.Enabled = false;
            this.checkBox_MovedAllStudentsToNewSession.ForeColor = System.Drawing.Color.Blue;
            this.checkBox_MovedAllStudentsToNewSession.Location = new System.Drawing.Point(295, 36);
            this.checkBox_MovedAllStudentsToNewSession.Name = "checkBox_MovedAllStudentsToNewSession";
            this.checkBox_MovedAllStudentsToNewSession.Size = new System.Drawing.Size(195, 17);
            this.checkBox_MovedAllStudentsToNewSession.TabIndex = 10;
            this.checkBox_MovedAllStudentsToNewSession.Text = "Moved All Students to New Session";
            this.checkBox_MovedAllStudentsToNewSession.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(23, 80);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "Search By Session:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(6, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(611, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Select the Previous Session Year in Drop Down List and than Click on Move All Stu" +
                "dents to New Session button.";
            // 
            // cmb_Session
            // 
            this.cmb_Session.DataSource = this.tblSessionBindingSource;
            this.cmb_Session.DisplayMember = "Session_Desc";
            this.cmb_Session.FormattingEnabled = true;
            this.cmb_Session.Location = new System.Drawing.Point(138, 77);
            this.cmb_Session.Name = "cmb_Session";
            this.cmb_Session.Size = new System.Drawing.Size(119, 21);
            this.cmb_Session.TabIndex = 4;
            this.cmb_Session.ValueMember = "Session_ID";
            this.cmb_Session.SelectedIndexChanged += new System.EventHandler(this.cmb_Session_SelectedIndexChanged);
            // 
            // tblSessionBindingSource
            // 
            this.tblSessionBindingSource.DataMember = "tbl_Session";
            this.tblSessionBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btn_MoveSession
            // 
            this.btn_MoveSession.Image = global::GeneralSchool.Properties.Resources.update;
            this.btn_MoveSession.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_MoveSession.Location = new System.Drawing.Point(295, 65);
            this.btn_MoveSession.Name = "btn_MoveSession";
            this.btn_MoveSession.Size = new System.Drawing.Size(209, 42);
            this.btn_MoveSession.TabIndex = 3;
            this.btn_MoveSession.Text = "Move All Students to New Session";
            this.btn_MoveSession.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_MoveSession.UseVisualStyleBackColor = true;
            this.btn_MoveSession.Click += new System.EventHandler(this.btn_MoveSession_Click);
            // 
            // tabPage_MoveTo_NewClass
            // 
            this.tabPage_MoveTo_NewClass.Controls.Add(this.checkBox_MovedToNewClass);
            this.tabPage_MoveTo_NewClass.Controls.Add(this.label6);
            this.tabPage_MoveTo_NewClass.Controls.Add(this.label5);
            this.tabPage_MoveTo_NewClass.Controls.Add(this.label4);
            this.tabPage_MoveTo_NewClass.Controls.Add(this.cmbClassDetailOne);
            this.tabPage_MoveTo_NewClass.Controls.Add(this.cmbClassDetailTwo);
            this.tabPage_MoveTo_NewClass.Controls.Add(this.btn_MoveToNewClass);
            this.tabPage_MoveTo_NewClass.Controls.Add(this.label12);
            this.tabPage_MoveTo_NewClass.Location = new System.Drawing.Point(4, 22);
            this.tabPage_MoveTo_NewClass.Name = "tabPage_MoveTo_NewClass";
            this.tabPage_MoveTo_NewClass.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_MoveTo_NewClass.Size = new System.Drawing.Size(727, 156);
            this.tabPage_MoveTo_NewClass.TabIndex = 2;
            this.tabPage_MoveTo_NewClass.Text = "Move To New Class";
            this.tabPage_MoveTo_NewClass.UseVisualStyleBackColor = true;
            // 
            // checkBox_MovedToNewClass
            // 
            this.checkBox_MovedToNewClass.AutoSize = true;
            this.checkBox_MovedToNewClass.Enabled = false;
            this.checkBox_MovedToNewClass.ForeColor = System.Drawing.Color.Blue;
            this.checkBox_MovedToNewClass.Location = new System.Drawing.Point(580, 64);
            this.checkBox_MovedToNewClass.Name = "checkBox_MovedToNewClass";
            this.checkBox_MovedToNewClass.Size = new System.Drawing.Size(124, 17);
            this.checkBox_MovedToNewClass.TabIndex = 10;
            this.checkBox_MovedToNewClass.Text = "Moved to New Class";
            this.checkBox_MovedToNewClass.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 26);
            this.label6.TabIndex = 8;
            this.label6.Text = "Students Move \r\nto this Class:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Search By Class:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(6, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(612, 60);
            this.label4.TabIndex = 6;
            this.label4.Text = resources.GetString("label4.Text");
            // 
            // cmbClassDetailOne
            // 
            this.cmbClassDetailOne.FormattingEnabled = true;
            this.cmbClassDetailOne.Location = new System.Drawing.Point(103, 87);
            this.cmbClassDetailOne.Name = "cmbClassDetailOne";
            this.cmbClassDetailOne.Size = new System.Drawing.Size(394, 21);
            this.cmbClassDetailOne.TabIndex = 0;
            this.cmbClassDetailOne.SelectedIndexChanged += new System.EventHandler(this.cmbClassDetailOne_SelectedIndexChanged);
            // 
            // cmbClassDetailTwo
            // 
            this.cmbClassDetailTwo.FormattingEnabled = true;
            this.cmbClassDetailTwo.Location = new System.Drawing.Point(103, 118);
            this.cmbClassDetailTwo.Name = "cmbClassDetailTwo";
            this.cmbClassDetailTwo.Size = new System.Drawing.Size(394, 21);
            this.cmbClassDetailTwo.TabIndex = 1;
            this.cmbClassDetailTwo.SelectedIndexChanged += new System.EventHandler(this.cmbClassDetailTwo_SelectedIndexChanged);
            // 
            // btn_MoveToNewClass
            // 
            this.btn_MoveToNewClass.Image = global::GeneralSchool.Properties.Resources.update;
            this.btn_MoveToNewClass.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_MoveToNewClass.Location = new System.Drawing.Point(518, 97);
            this.btn_MoveToNewClass.Name = "btn_MoveToNewClass";
            this.btn_MoveToNewClass.Size = new System.Drawing.Size(187, 36);
            this.btn_MoveToNewClass.TabIndex = 2;
            this.btn_MoveToNewClass.Text = "Move Students to New Class";
            this.btn_MoveToNewClass.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_MoveToNewClass.UseVisualStyleBackColor = true;
            this.btn_MoveToNewClass.Click += new System.EventHandler(this.btn_MoveToNewClass_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(577, 109);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 13);
            this.label12.TabIndex = 9;
            this.label12.Text = "label12";
            // 
            // tabPage_AssignRollNo
            // 
            this.tabPage_AssignRollNo.Controls.Add(this.checkBox_AssignedRollNumbers);
            this.tabPage_AssignRollNo.Controls.Add(this.label10);
            this.tabPage_AssignRollNo.Controls.Add(this.btn_AssignRoll);
            this.tabPage_AssignRollNo.Controls.Add(this.cmb_ClassDetailThree);
            this.tabPage_AssignRollNo.Controls.Add(this.label7);
            this.tabPage_AssignRollNo.Location = new System.Drawing.Point(4, 22);
            this.tabPage_AssignRollNo.Name = "tabPage_AssignRollNo";
            this.tabPage_AssignRollNo.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_AssignRollNo.Size = new System.Drawing.Size(727, 156);
            this.tabPage_AssignRollNo.TabIndex = 3;
            this.tabPage_AssignRollNo.Text = "Assign Roll Numbers";
            this.tabPage_AssignRollNo.UseVisualStyleBackColor = true;
            // 
            // checkBox_AssignedRollNumbers
            // 
            this.checkBox_AssignedRollNumbers.AutoSize = true;
            this.checkBox_AssignedRollNumbers.Enabled = false;
            this.checkBox_AssignedRollNumbers.ForeColor = System.Drawing.Color.Blue;
            this.checkBox_AssignedRollNumbers.Location = new System.Drawing.Point(518, 40);
            this.checkBox_AssignedRollNumbers.Name = "checkBox_AssignedRollNumbers";
            this.checkBox_AssignedRollNumbers.Size = new System.Drawing.Size(135, 17);
            this.checkBox_AssignedRollNumbers.TabIndex = 10;
            this.checkBox_AssignedRollNumbers.Text = "Assigned Roll Numbers";
            this.checkBox_AssignedRollNumbers.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 81);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Search By Class:";
            // 
            // btn_AssignRoll
            // 
            this.btn_AssignRoll.Image = global::GeneralSchool.Properties.Resources.markbtn;
            this.btn_AssignRoll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AssignRoll.Location = new System.Drawing.Point(518, 70);
            this.btn_AssignRoll.Name = "btn_AssignRoll";
            this.btn_AssignRoll.Size = new System.Drawing.Size(152, 41);
            this.btn_AssignRoll.TabIndex = 8;
            this.btn_AssignRoll.Text = "Assign Roll Numbers";
            this.btn_AssignRoll.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_AssignRoll.UseVisualStyleBackColor = true;
            this.btn_AssignRoll.Click += new System.EventHandler(this.btn_AssignRoll_Click);
            // 
            // cmb_ClassDetailThree
            // 
            this.cmb_ClassDetailThree.FormattingEnabled = true;
            this.cmb_ClassDetailThree.Location = new System.Drawing.Point(99, 78);
            this.cmb_ClassDetailThree.Name = "cmb_ClassDetailThree";
            this.cmb_ClassDetailThree.Size = new System.Drawing.Size(394, 21);
            this.cmb_ClassDetailThree.TabIndex = 7;
            this.cmb_ClassDetailThree.SelectedIndexChanged += new System.EventHandler(this.cmb_ClassDetailThree_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(6, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(594, 30);
            this.label7.TabIndex = 6;
            this.label7.Text = "Select Class Detail from Drop Down List and Click on Assign Roll Numbers Button t" +
                "o Assign Roll to Students \r\naccording to the Percentage.";
            // 
            // tabPage_IrRegularChanges
            // 
            this.tabPage_IrRegularChanges.Controls.Add(this.btn_Enable_Delete_Save);
            this.tabPage_IrRegularChanges.Controls.Add(this.label11);
            this.tabPage_IrRegularChanges.Controls.Add(this.label1);
            this.tabPage_IrRegularChanges.Controls.Add(this.cmbClassDetailFour);
            this.tabPage_IrRegularChanges.Location = new System.Drawing.Point(4, 22);
            this.tabPage_IrRegularChanges.Name = "tabPage_IrRegularChanges";
            this.tabPage_IrRegularChanges.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_IrRegularChanges.Size = new System.Drawing.Size(727, 156);
            this.tabPage_IrRegularChanges.TabIndex = 4;
            this.tabPage_IrRegularChanges.Text = "IR-Regular Changes";
            this.tabPage_IrRegularChanges.UseVisualStyleBackColor = true;
            // 
            // btn_Enable_Delete_Save
            // 
            this.btn_Enable_Delete_Save.Image = global::GeneralSchool.Properties.Resources.enable_edit_save;
            this.btn_Enable_Delete_Save.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Enable_Delete_Save.Location = new System.Drawing.Point(538, 57);
            this.btn_Enable_Delete_Save.Name = "btn_Enable_Delete_Save";
            this.btn_Enable_Delete_Save.Size = new System.Drawing.Size(164, 38);
            this.btn_Enable_Delete_Save.TabIndex = 11;
            this.btn_Enable_Delete_Save.Text = "Enable Delete and Save";
            this.btn_Enable_Delete_Save.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Enable_Delete_Save.UseVisualStyleBackColor = true;
            this.btn_Enable_Delete_Save.Click += new System.EventHandler(this.btn_Enable_Delete_Save_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 70);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Search By Class:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(6, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(620, 30);
            this.label1.TabIndex = 7;
            this.label1.Text = "Select Class Detail from Drop Down List and Save Changes in your required fields " +
                " (Result, Percentage and Roll) \r\nand Click on Save Button to Save the records.";
            // 
            // cmbClassDetailFour
            // 
            this.cmbClassDetailFour.FormattingEnabled = true;
            this.cmbClassDetailFour.Location = new System.Drawing.Point(114, 67);
            this.cmbClassDetailFour.Name = "cmbClassDetailFour";
            this.cmbClassDetailFour.Size = new System.Drawing.Size(394, 21);
            this.cmbClassDetailFour.TabIndex = 0;
            this.cmbClassDetailFour.SelectedIndexChanged += new System.EventHandler(this.cmbClassDetailFour_SelectedIndexChanged);
            // 
            // tbl_Student_MovementBindingNavigator
            // 
            this.tbl_Student_MovementBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_Student_MovementBindingNavigator.BindingSource = this.tbl_Student_MovementBindingSource;
            this.tbl_Student_MovementBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_Student_MovementBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_Student_MovementBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.tbl_Student_MovementBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_Student_MovementBindingNavigatorSaveItem});
            this.tbl_Student_MovementBindingNavigator.Location = new System.Drawing.Point(11, 20);
            this.tbl_Student_MovementBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_Student_MovementBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_Student_MovementBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_Student_MovementBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_Student_MovementBindingNavigator.Name = "tbl_Student_MovementBindingNavigator";
            this.tbl_Student_MovementBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_Student_MovementBindingNavigator.Size = new System.Drawing.Size(345, 25);
            this.tbl_Student_MovementBindingNavigator.TabIndex = 1;
            this.tbl_Student_MovementBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Visible = false;
            // 
            // tbl_Student_MovementBindingSource
            // 
            this.tbl_Student_MovementBindingSource.DataMember = "tbl_Student_Movement";
            this.tbl_Student_MovementBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.Enabled = false;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(58, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Click += new System.EventHandler(this.bindingNavigatorDeleteItem_Click);
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_Student_MovementBindingNavigatorSaveItem
            // 
            this.tbl_Student_MovementBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_Student_MovementBindingNavigatorSaveItem.Image")));
            this.tbl_Student_MovementBindingNavigatorSaveItem.Name = "tbl_Student_MovementBindingNavigatorSaveItem";
            this.tbl_Student_MovementBindingNavigatorSaveItem.Size = new System.Drawing.Size(77, 22);
            this.tbl_Student_MovementBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_Student_MovementBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_Student_MovementBindingNavigatorSaveItem_Click);
            // 
            // tblResultBindingSource
            // 
            this.tblResultBindingSource.DataMember = "tbl_Result";
            this.tblResultBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tblSMCSDefineBindingSource
            // 
            this.tblSMCSDefineBindingSource.DataMember = "tbl_SMCS_Define";
            this.tblSMCSDefineBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tbl_Student_MovementTableAdapter
            // 
            this.tbl_Student_MovementTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_SMCS_DefineTableAdapter
            // 
            this.tbl_SMCS_DefineTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_ResultTableAdapter
            // 
            this.tbl_ResultTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_SessionTableAdapter
            // 
            this.tbl_SessionTableAdapter.ClearBeforeFill = true;
            // 
            // viewClassDetailBindingSource
            // 
            this.viewClassDetailBindingSource.DataMember = "View_ClassDetail";
            this.viewClassDetailBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // view_ClassDetailTableAdapter
            // 
            this.view_ClassDetailTableAdapter.ClearBeforeFill = true;
            // 
            // viewClassDetailTwoBindingSource
            // 
            this.viewClassDetailTwoBindingSource.DataMember = "View_ClassDetailTwo";
            this.viewClassDetailTwoBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // view_ClassDetailTwoTableAdapter
            // 
            this.view_ClassDetailTwoTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_Student_MovementDataGridView
            // 
            this.tbl_Student_MovementDataGridView.AllowUserToAddRows = false;
            this.tbl_Student_MovementDataGridView.AllowUserToDeleteRows = false;
            this.tbl_Student_MovementDataGridView.AllowUserToResizeColumns = false;
            this.tbl_Student_MovementDataGridView.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tbl_Student_MovementDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.tbl_Student_MovementDataGridView.AutoGenerateColumns = false;
            this.tbl_Student_MovementDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stMovIDDataGridViewTextBoxColumn,
            this.gRNoDataGridViewTextBoxColumn,
            this.sessionIDDataGridViewTextBoxColumn,
            this.resultIDDataGridViewTextBoxColumn,
            this.percentageDataGridViewTextBoxColumn,
            this.rollDataGridViewTextBoxColumn,
            this.smcsdIDDataGridViewTextBoxColumn});
            this.tbl_Student_MovementDataGridView.DataSource = this.tbl_Student_MovementBindingSource;
            this.tbl_Student_MovementDataGridView.Location = new System.Drawing.Point(11, 52);
            this.tbl_Student_MovementDataGridView.Name = "tbl_Student_MovementDataGridView";
            this.tbl_Student_MovementDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.tbl_Student_MovementDataGridView.Size = new System.Drawing.Size(684, 183);
            this.tbl_Student_MovementDataGridView.TabIndex = 2;
            // 
            // stMovIDDataGridViewTextBoxColumn
            // 
            this.stMovIDDataGridViewTextBoxColumn.DataPropertyName = "St_Mov_ID";
            this.stMovIDDataGridViewTextBoxColumn.HeaderText = "Student ID";
            this.stMovIDDataGridViewTextBoxColumn.Name = "stMovIDDataGridViewTextBoxColumn";
            // 
            // gRNoDataGridViewTextBoxColumn
            // 
            this.gRNoDataGridViewTextBoxColumn.DataPropertyName = "GR_No";
            this.gRNoDataGridViewTextBoxColumn.HeaderText = "GR Number";
            this.gRNoDataGridViewTextBoxColumn.Name = "gRNoDataGridViewTextBoxColumn";
            // 
            // sessionIDDataGridViewTextBoxColumn
            // 
            this.sessionIDDataGridViewTextBoxColumn.DataPropertyName = "Session_ID";
            this.sessionIDDataGridViewTextBoxColumn.DataSource = this.tblSessionBindingSource;
            this.sessionIDDataGridViewTextBoxColumn.DisplayMember = "Session_Desc";
            this.sessionIDDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.sessionIDDataGridViewTextBoxColumn.HeaderText = "Session Year";
            this.sessionIDDataGridViewTextBoxColumn.Name = "sessionIDDataGridViewTextBoxColumn";
            this.sessionIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.sessionIDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.sessionIDDataGridViewTextBoxColumn.ValueMember = "Session_ID";
            // 
            // resultIDDataGridViewTextBoxColumn
            // 
            this.resultIDDataGridViewTextBoxColumn.DataPropertyName = "Result_ID";
            this.resultIDDataGridViewTextBoxColumn.DataSource = this.tblResultBindingSource;
            this.resultIDDataGridViewTextBoxColumn.DisplayMember = "Result_Desc";
            this.resultIDDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.resultIDDataGridViewTextBoxColumn.HeaderText = "Result";
            this.resultIDDataGridViewTextBoxColumn.Name = "resultIDDataGridViewTextBoxColumn";
            this.resultIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.resultIDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.resultIDDataGridViewTextBoxColumn.ValueMember = "Result_ID";
            // 
            // percentageDataGridViewTextBoxColumn
            // 
            this.percentageDataGridViewTextBoxColumn.DataPropertyName = "Percentage";
            this.percentageDataGridViewTextBoxColumn.HeaderText = "Percentage";
            this.percentageDataGridViewTextBoxColumn.Name = "percentageDataGridViewTextBoxColumn";
            // 
            // rollDataGridViewTextBoxColumn
            // 
            this.rollDataGridViewTextBoxColumn.DataPropertyName = "Roll";
            this.rollDataGridViewTextBoxColumn.HeaderText = "Roll";
            this.rollDataGridViewTextBoxColumn.Name = "rollDataGridViewTextBoxColumn";
            // 
            // smcsdIDDataGridViewTextBoxColumn
            // 
            this.smcsdIDDataGridViewTextBoxColumn.DataPropertyName = "Smcsd_ID";
            this.smcsdIDDataGridViewTextBoxColumn.HeaderText = "Smcsd_ID";
            this.smcsdIDDataGridViewTextBoxColumn.Name = "smcsdIDDataGridViewTextBoxColumn";
            this.smcsdIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // viewClassDetailThreeBindingSource
            // 
            this.viewClassDetailThreeBindingSource.DataMember = "View_ClassDetailThree";
            this.viewClassDetailThreeBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // view_ClassDetailThreeTableAdapter
            // 
            this.view_ClassDetailThreeTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tabControl_Students_Move_Session);
            this.groupBox1.Location = new System.Drawing.Point(16, 88);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(757, 212);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Students Session Movement";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbl_Student_MovementBindingNavigator);
            this.groupBox2.Controls.Add(this.tbl_Student_MovementDataGridView);
            this.groupBox2.Location = new System.Drawing.Point(16, 319);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(757, 252);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Students Detail";
            // 
            // Form_Students_Move_toNewSession
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 655);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form_Students_Move_toNewSession";
            this.Text = "Students Move To New Session";
            this.Load += new System.EventHandler(this.Form_Students_Move_toNewSession_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Students_Move_toNewSession_FormClosing);
            this.tabControl_Students_Move_Session.ResumeLayout(false);
            this.tabPage_PassOut_LastClass.ResumeLayout(false);
            this.tabPage_PassOut_LastClass.PerformLayout();
            this.tabPage_MoveToNew_Session.ResumeLayout(false);
            this.tabPage_MoveToNew_Session.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblSessionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            this.tabPage_MoveTo_NewClass.ResumeLayout(false);
            this.tabPage_MoveTo_NewClass.PerformLayout();
            this.tabPage_AssignRollNo.ResumeLayout(false);
            this.tabPage_AssignRollNo.PerformLayout();
            this.tabPage_IrRegularChanges.ResumeLayout(false);
            this.tabPage_IrRegularChanges.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Student_MovementBindingNavigator)).EndInit();
            this.tbl_Student_MovementBindingNavigator.ResumeLayout(false);
            this.tbl_Student_MovementBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Student_MovementBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblResultBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource_ClassDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSMCSDefineBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewClassDetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewClassDetailTwoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Student_MovementDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewClassDetailThreeBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl_Students_Move_Session;
        private System.Windows.Forms.TabPage tabPage_PassOut_LastClass;
        private System.Windows.Forms.TabPage tabPage_MoveToNew_Session;
        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tbl_Student_MovementBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Student_MovementTableAdapter tbl_Student_MovementTableAdapter;
        private System.Windows.Forms.BindingNavigator tbl_Student_MovementBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_Student_MovementBindingNavigatorSaveItem;
        private System.Windows.Forms.BindingSource tblSMCSDefineBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SMCS_DefineTableAdapter tbl_SMCS_DefineTableAdapter;
        private System.Windows.Forms.Button btn_MoveSession;
        private System.Windows.Forms.BindingSource tblResultBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ResultTableAdapter tbl_ResultTableAdapter;
        private System.Windows.Forms.BindingSource tblSessionBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SessionTableAdapter tbl_SessionTableAdapter;
        private System.Windows.Forms.Button btn_MoveToNewClass;
        private System.Windows.Forms.ComboBox cmbClassDetailTwo;
        private System.Windows.Forms.ComboBox cmbClassDetailOne;
        private System.Windows.Forms.BindingSource bindingSource_ClassDetail;
        private System.Windows.Forms.BindingSource viewClassDetailBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.View_ClassDetailTableAdapter view_ClassDetailTableAdapter;
        private System.Windows.Forms.BindingSource viewClassDetailTwoBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.View_ClassDetailTwoTableAdapter view_ClassDetailTwoTableAdapter;
        private System.Windows.Forms.ComboBox cmb_Session;
        private System.Windows.Forms.TabPage tabPage_MoveTo_NewClass;
        private System.Windows.Forms.ComboBox cmbClassDetail;
        private System.Windows.Forms.Button btn_MarkPassOut;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView tbl_Student_MovementDataGridView;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabPage_AssignRollNo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmb_ClassDetailThree;
        private System.Windows.Forms.Button btn_AssignRoll;
        private System.Windows.Forms.TabPage tabPage_IrRegularChanges;
        private System.Windows.Forms.ComboBox cmbClassDetailFour;
        private System.Windows.Forms.BindingSource viewClassDetailThreeBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.View_ClassDetailThreeTableAdapter view_ClassDetailThreeTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn stMovIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gRNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn sessionIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn resultIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn percentageDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rollDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn smcsdIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn_Enable_Delete_Save;
        private System.Windows.Forms.CheckBox checkBox_PassOutStudents;
        private System.Windows.Forms.CheckBox checkBox_MovedAllStudentsToNewSession;
        private System.Windows.Forms.CheckBox checkBox_MovedToNewClass;
        private System.Windows.Forms.CheckBox checkBox_AssignedRollNumbers;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}