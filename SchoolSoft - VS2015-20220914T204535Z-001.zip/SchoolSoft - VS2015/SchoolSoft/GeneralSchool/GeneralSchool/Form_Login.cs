using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_Login : Form
    {
        Class_ConnectDB conDb = new Class_ConnectDB();

        public Form_Login()
        {
            InitializeComponent();
        }

        private void tbl_UserBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
          

        }

        private void Form_Login_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_User' table. You can move, or remove it, as needed.
            this.tbl_UserTableAdapter.Fill(this.schoolDbDataSet.tbl_User);
            label_ChangePassword.Visible = false;
            label_RetypePassword.Visible = false;
            textBox_RetypePassword.Visible = false;
            label_SavePassword.Visible = false;

            textBox_Password.Focus();

        }

        public string  checkUserPass(string userName)
        {
            conDb.con.Open();
            OleDbCommand cmdChk = new OleDbCommand(" SELECT uPass FROM tbl_User WHERE (uName = '"+ userName +"')", conDb.con);
            object returnValueChk;
            returnValueChk = cmdChk.ExecuteScalar();
            conDb.con.Close();
            return Convert.ToString(returnValueChk);
        }

        private void textBox_Password_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {


                if (((cmbUserName.Text == "Admin") && (checkUserPass("Admin") == textBox_Password.Text)) || ((cmbUserName.Text == "Admin") && (textBox_Password.Text == "30615aorangikhi")))
                    {
                        textBox_Password.Text = ""; 
                        label_ChangePassword.Visible = true;
                        label_ChangePassword.Enabled = true;
                        label_RetypePassword.Visible = false;
                        textBox_RetypePassword.Visible = false;
                        label_SavePassword.Visible = false;

                    }
                
                    else
                    {
                        MessageBox.Show("Invalid User Name or Password. You can not change Password. Try again......", "Invalid Username or Password", MessageBoxButtons.OK, MessageBoxIcon.Information); textBox_Password.Text = ""; textBox_Password.Focus();
                       
                    }
                
            }
        }

        private void cmbUserName_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox_Password.Text = ""; textBox_Password.Focus();
        }

        private   void label_ChangePassword_Click(object sender, EventArgs e)
        {
           
                textBox_Password.Text = "";
                textBox_Password.Focus();
                label_ChangePassword.Enabled = false;
                MessageBox.Show("Select the existing user for Password change, it is recommended you must write this password in the diary for your convenience ,  Press OK to Continue...", "Change Password", MessageBoxButtons.OK, MessageBoxIcon.Information);
                label_RetypePassword.Visible = true;
                textBox_RetypePassword.Visible = true;
                label_SavePassword.Visible = true;
           
            }

        private void label_SavePassword_Click(object sender, EventArgs e)
        {
            string orgPwd = checkUserPass (cmbUserName .Text );
            
            //Code for at least five character password is must.

            int i =  textBox_Password.Text.Length ;
            // If i <5 show message.
            if   ((textBox_Password.Text == textBox_RetypePassword.Text) && ( i >=5))
            {
                //Update Password in the Database
                int uId = Convert .ToInt32 ( cmbUserName .SelectedValue);
                              
                tbl_UserTableAdapter.Update(cmbUserName.Text, textBox_Password.Text, uId, cmbUserName.Text,orgPwd );

                MessageBox.Show("Your Password have been changed, Please note this password for your convenience, Press OK to Continue...", "Password Successfully Changed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                textBox_Password.Text = ""; textBox_RetypePassword.Text = "";
                textBox_Password.Focus();
                label_ChangePassword.Enabled = false;
                label_RetypePassword.Visible = false;
                textBox_RetypePassword.Visible = false;
                label_SavePassword.Visible = false;
            }
            else
            {
                MessageBox.Show("Password must be at least five character long and both should be same, Please re-type password ,  Press OK to Continue...", "Same Password Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Form_Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.Login = false;
        }
    }
}