using System;
using System.IO;
//using System.Security.AccessControl;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Ionic.Zip;

namespace GeneralSchool
{
    public partial class Form_Backup_Restore : Form
    {
        //Here Archive file will be, after installation archieve will be save on this parth
        private static string arcfilePath = @"C:\Program Files\General Solutions\SetupGSchool\Data\GS_Archieve.zip";

        public Form_Backup_Restore()
        {
            InitializeComponent();
        }

        private void btn_BackupData_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog_Backup.ShowDialog() == DialogResult.OK)
            {
                try
                {

                    using (ZipFile zip = new ZipFile())
                    {
                        zip.Password = "30615aorangikhi75800";
                        zip.AddFile("C:\\Program Files\\General Solutions\\SetupGSchool\\Data\\SchoolDb.mdb", "");
                        zip.AddFile("C:\\Program Files\\General Solutions\\SetupGSchool\\Data\\schoollogo.JPG", "");
                        zip.AddFile("C:\\Program Files\\General Solutions\\SetupGSchool\\Data\\App.ico", "");
                        zip.AddFile("C:\\Program Files\\General Solutions\\SetupGSchool\\Data\\docm.ico", "");
                        zip.AddFile("C:\\Program Files\\General Solutions\\SetupGSchool\\Data\\School Soft Help.chm", "");
                        zip.Save("C:\\Program Files\\General Solutions\\SetupGSchool\\Data\\GS_Archieve.zip");
                    }
                
               
                    DateTime dt = DateTime.Now;
                    string datetimestring;
                    datetimestring = string.Format("Backup SchoolSoft {0:d-M-yy hh-mm}", dt);

                    string arcBackupPath = folderBrowserDialog_Backup.SelectedPath.ToString() + "\\" + datetimestring;
                    if (!Directory.Exists(arcBackupPath))
                        Directory.CreateDirectory(arcBackupPath);

                    // Copy the archieve file.
                    File.Copy(arcfilePath, arcBackupPath + "\\" + "GS_Archieve.zip", true);


                  MessageBox.Show("Database Backup has been Completed Successfully.", "Data Backup Completed",
                      MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                catch (Exception ex) { MessageBox.Show(Convert.ToString(ex)); }
                
                
                btn_BackupData.Enabled = false;

            }
        }

       

        private void btn_RestoreData_Click(object sender, EventArgs e)
        {
           openFileDialogBackupDB.Filter = "zip files (*.zip)|*.zip|All files (*.*)|*.*";
           if (openFileDialogBackupDB.ShowDialog() == DialogResult.OK)
           {
               try
               {
                   string backup_archieve_name = openFileDialogBackupDB.FileName;
                   StringBuilder sbResPath = new StringBuilder(backup_archieve_name);
                   sbResPath.Replace("\\GS_Archieve.zip", "");

                   //In resDirectory variable eliminate database file name
                   string resDirectory = Convert.ToString(sbResPath);

                   //This will copy Database file to c:/program files/....
                   File.Copy(backup_archieve_name, arcfilePath, true);
                   using (ZipFile zip = ZipFile.Read(arcfilePath ))
                   {
                       zip.Password = "30615aorangikhi75800";
                       foreach (ZipEntry ez in zip)
                       {
                           ez.Extract("C:\\Program Files\\General Solutions\\SetupGSchool\\Data\\", ExtractExistingFileAction.OverwriteSilently);
                       }
                   }

                
               }
               catch (System.UnauthorizedAccessException)
               {
                   //MessageBox.Show(Convert .ToString (ex)); 
               }

               btn_RestoreData.Enabled = false;
               MessageBox.Show("Database file is Restore Succesfully.", "Restore Completed Successfully",
               MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
           }
           else
           {
               MessageBox.Show("Database file is not correct, Choose the correct file.", "File not correct",
               MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
           }

        }

        private void Form_Backup_Restore_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_User' table. You can move, or remove it, as needed.
            this.tbl_UserTableAdapter.Fill(this.schoolDbDataSet.tbl_User);
            btn_BackupData.Enabled = false;
            btn_RestoreData.Enabled = false;
        }

        private void cmbUserName_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox_Password.Text = ""; textBox_Password.Focus(); 
        }
        Form_Login frmLogin2 = new Form_Login();
        private void textBox_Password_KeyPress(object sender, KeyPressEventArgs e)
        {
            
            if (e.KeyChar == 13)
            {


                if (((cmbUserName.Text == "Admin") && (frmLogin2.checkUserPass("Admin") == textBox_Password.Text)) || ((cmbUserName.Text == "Admin") && (textBox_Password.Text == "30615aorangikhi")))
                {
                    textBox_Password.Text = "";
                    btn_BackupData.Enabled = true ;
                    btn_RestoreData.Enabled = true ;
                  

                }
                else
                {
                    MessageBox.Show("Invalid User Name or Password. Try again......", "Invalid Username or Password", MessageBoxButtons.OK, MessageBoxIcon.Information); textBox_Password.Text = ""; textBox_Password.Focus();

                }
            }
        }

        private void Form_Backup_Restore_FormClosing(object sender, FormClosingEventArgs e)
        {
           MDIParent_Form .BackupRestoreData  = false;
        }
 


    
    
    
    }
}


/*

 * 
 * 
 * 
 * 
 * 
 *    ////Student Image Data Directory on C:\Program Files.. where Image files wil be save
                   //string dataDirectory = @"C:\Program Files\Dynamic Solutions\SetupSmartOne\Image\student";

                   //// diSource is a path of Student Image folder in C:\Program Files\Dynamic Solutions\SetupSmartOne\Image\student
                   //DirectoryInfo diSource = new DirectoryInfo(dataDirectory);

                   //// diTarget is a path of Student Image folder where user have taken there backup.
                   //DirectoryInfo diTarget = new DirectoryInfo(resDirectory + "\\Image\\student");

                   //// This loop will copy each image file from Student Image folder to C:\Program Files ... Student image folder.
                   //foreach (FileInfo fi in diTarget.GetFiles())
                   //{
                   //    fi.CopyTo(Path.Combine(diSource.ToString(), fi.Name), true);
                   //}
 * 
 * 
 * 
 * 
 * 
                   //Add the access control entry to the file.
                   //File.GetAccessControl(dbpath);
                   //Add the access control entry to the file.


                   //AddFileSecurity(dbpath, @"hfp-server\Admin",
                   //    FileSystemRights.ReadData, AccessControlType.Deny);



                   // Remove the access control entry from the file.
                   RemoveFileSecurity(dbpath, @"hfp-server\Admin",
                       FileSystemRights.ReadData, AccessControlType.Deny);


                   //This will copy Database file to c:/program files/....
                   File.Copy(respath, dbpath, true);


                   // Now the issue is to get the Domain Name and Active user of this computer
                   // And Save in to the Database 




 * 
 * 
 * 
 * 
 * 
 * 
 *  // Adds an ACL entry on the specified file for the specified account.
        public static void AddFileSecurity(string fileName, string account,
            FileSystemRights rights, AccessControlType controlType)
        {


            // Get a FileSecurity object that represents the 
            // current security settings.
            FileSecurity fSecurity = File.GetAccessControl(fileName);

            // Add the FileSystemAccessRule to the security settings. 
            fSecurity.AddAccessRule(new FileSystemAccessRule(account,
                rights, controlType));

            // Set the new access settings.
            File.SetAccessControl(fileName, fSecurity);

        }

        // Removes an ACL entry on the specified file for the specified account.
        public static void RemoveFileSecurity(string fileName, string account,
            FileSystemRights rights, AccessControlType controlType)
        {

            // Get a FileSecurity object that represents the 
            // current security settings.
            FileSecurity fSecurity = File.GetAccessControl(fileName);

            // Add the FileSystemAccessRule to the security settings. 
            fSecurity.RemoveAccessRule(new FileSystemAccessRule(account,
                rights, controlType));

            // Set the new access settings.
            File.SetAccessControl(fileName, fSecurity);

        }
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
*/

