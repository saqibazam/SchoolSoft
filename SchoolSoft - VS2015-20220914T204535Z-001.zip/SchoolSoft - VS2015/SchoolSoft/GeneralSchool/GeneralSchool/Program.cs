using System;
using System.Collections.Generic;
using System.Windows.Forms;



namespace GeneralSchool
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                //Application.Run(new Form_Class_Fee_Define());
                //Application.Run(new Form_General_Student_Info());
                //Application.Run(new Form_NewStudent_Registration());
                //Application.Run(new Form_New_Student_Info());
                Application.Run(new MDIParent_Form());
                //Application.Run(new Form_Class());
                //Application.Run(new Form_School());
                //Application.Run(new Testing());

                //Application.Run(new Form_Students_Move_toNewSession());
                
                //Application.Run(new Form_Class_Section_Shift_Medium_Define());
                //Application.Run(new Form_Backup_Restore());

                //Application.Run(new Form_Session());
                
                //Application.Run(new Form_Session_Progress_Status ());
                //Application.Run(new Form_Fee_Reports());
            }
            catch (Exception ex) { MessageBox.Show(Convert.ToString(ex)); }
        }
    }
}