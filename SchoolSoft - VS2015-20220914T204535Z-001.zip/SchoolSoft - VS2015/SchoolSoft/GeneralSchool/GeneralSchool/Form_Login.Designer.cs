namespace GeneralSchool
{
    partial class Form_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbUserName = new System.Windows.Forms.ComboBox();
            this.tblUserBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.textBox_Password = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbl_UserTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_UserTableAdapter();
            this.label_ChangePassword = new System.Windows.Forms.Label();
            this.textBox_RetypePassword = new System.Windows.Forms.TextBox();
            this.label_RetypePassword = new System.Windows.Forms.Label();
            this.label_SavePassword = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.tblUserBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(148, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "User Name";
            // 
            // cmbUserName
            // 
            this.cmbUserName.DataSource = this.tblUserBindingSource;
            this.cmbUserName.DisplayMember = "uName";
            this.cmbUserName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUserName.FormattingEnabled = true;
            this.cmbUserName.Location = new System.Drawing.Point(218, 60);
            this.cmbUserName.Name = "cmbUserName";
            this.cmbUserName.Size = new System.Drawing.Size(121, 21);
            this.cmbUserName.TabIndex = 4;
            this.cmbUserName.ValueMember = "uID";
            this.cmbUserName.SelectedIndexChanged += new System.EventHandler(this.cmbUserName_SelectedIndexChanged);
            // 
            // tblUserBindingSource
            // 
            this.tblUserBindingSource.DataMember = "tbl_User";
            this.tblUserBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // textBox_Password
            // 
            this.textBox_Password.Location = new System.Drawing.Point(218, 100);
            this.textBox_Password.Name = "textBox_Password";
            this.textBox_Password.PasswordChar = '*';
            this.textBox_Password.Size = new System.Drawing.Size(121, 20);
            this.textBox_Password.TabIndex = 0;
            this.textBox_Password.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_Password_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(148, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Password";
            // 
            // tbl_UserTableAdapter
            // 
            this.tbl_UserTableAdapter.ClearBeforeFill = true;
            // 
            // label_ChangePassword
            // 
            this.label_ChangePassword.AutoSize = true;
            this.label_ChangePassword.BackColor = System.Drawing.SystemColors.Window;
            this.label_ChangePassword.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_ChangePassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_ChangePassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ChangePassword.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_ChangePassword.Location = new System.Drawing.Point(218, 217);
            this.label_ChangePassword.Name = "label_ChangePassword";
            this.label_ChangePassword.Size = new System.Drawing.Size(110, 15);
            this.label_ChangePassword.TabIndex = 2;
            this.label_ChangePassword.Text = "Change Password";
            this.label_ChangePassword.Click += new System.EventHandler(this.label_ChangePassword_Click);
            // 
            // textBox_RetypePassword
            // 
            this.textBox_RetypePassword.Location = new System.Drawing.Point(218, 137);
            this.textBox_RetypePassword.Name = "textBox_RetypePassword";
            this.textBox_RetypePassword.PasswordChar = '*';
            this.textBox_RetypePassword.Size = new System.Drawing.Size(121, 20);
            this.textBox_RetypePassword.TabIndex = 1;
            // 
            // label_RetypePassword
            // 
            this.label_RetypePassword.AutoSize = true;
            this.label_RetypePassword.Location = new System.Drawing.Point(111, 140);
            this.label_RetypePassword.Name = "label_RetypePassword";
            this.label_RetypePassword.Size = new System.Drawing.Size(90, 13);
            this.label_RetypePassword.TabIndex = 6;
            this.label_RetypePassword.Text = "Retype Password";
            // 
            // label_SavePassword
            // 
            this.label_SavePassword.AutoSize = true;
            this.label_SavePassword.BackColor = System.Drawing.SystemColors.Menu;
            this.label_SavePassword.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_SavePassword.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label_SavePassword.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label_SavePassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SavePassword.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_SavePassword.Location = new System.Drawing.Point(225, 190);
            this.label_SavePassword.Name = "label_SavePassword";
            this.label_SavePassword.Size = new System.Drawing.Size(96, 15);
            this.label_SavePassword.TabIndex = 3;
            this.label_SavePassword.Text = "Save Password";
            this.label_SavePassword.Click += new System.EventHandler(this.label_SavePassword_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(35, 278);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(240, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Note: Only Admin Can Change Password.";
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImage = global::GeneralSchool.Properties.Resources.login2;
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox1.Controls.Add(this.cmbUserName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label_SavePassword);
            this.groupBox1.Controls.Add(this.textBox_Password);
            this.groupBox1.Controls.Add(this.label_ChangePassword);
            this.groupBox1.Controls.Add(this.label_RetypePassword);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox_RetypePassword);
            this.groupBox1.Location = new System.Drawing.Point(70, 120);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(541, 321);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Change Password";
            // 
            // Form_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(717, 464);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form_Login";
            this.Text = "Change Password";
            this.Load += new System.EventHandler(this.Form_Login_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Login_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.tblUserBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbUserName;
        private System.Windows.Forms.TextBox textBox_Password;
        private System.Windows.Forms.Label label2;
        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tblUserBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_UserTableAdapter tbl_UserTableAdapter;
        private System.Windows.Forms.Label label_ChangePassword;
        private System.Windows.Forms.TextBox textBox_RetypePassword;
        private System.Windows.Forms.Label label_RetypePassword;
        private System.Windows.Forms.Label label_SavePassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;

    }
}