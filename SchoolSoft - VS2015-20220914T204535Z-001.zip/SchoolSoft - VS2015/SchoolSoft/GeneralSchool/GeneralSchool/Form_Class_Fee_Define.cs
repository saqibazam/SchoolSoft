using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_Class_Fee_Define : Form
    {
        Class_ConnectDB conDb = new Class_ConnectDB();
        MDIParent_Form mdiForm = new MDIParent_Form();

        public Form_Class_Fee_Define()
        {
            InitializeComponent();
        }
        // On Click Add Button remove this class from the comboBox and show this Class in a Seperate Label 
        ////string imageName = this.flagsCombo.SelectedItem as string;
        // // Remove from the ComboBox (don't allow adding the same item twice)
        //    this.flagsCombo.Items.Remove(imageName);
        //    // Set Position
        //    this.flagsBindingSource.Position = this.flagsBindingSource.Count - 1;

        private void tbl_Fee_Define_MasterBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.tbl_Fee_Define_MasterBindingSource.EndEdit();
                this.tbl_Fee_Define_MasterTableAdapter.Update(this.schoolDbDataSet.tbl_Fee_Define_Master);


                this.tbl_Fee_Define_DetailBindingSource.EndEdit();
                this.tbl_Fee_Define_DetailTableAdapter.Update(this.schoolDbDataSet.tbl_Fee_Define_Detail);
                disableControl();
                MessageBox.Show("Record has been saved successfully.....Press OK to continue...", "Record has been saved", MessageBoxButtons.OK, MessageBoxIcon.Information); 
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Convert.ToString(Ex));
            }
            bindingNavigatorAddNewItem.Enabled = true ;
            toolStripButton_Edit_Data.Enabled = true;
            tbl_Fee_Define_MasterBindingNavigatorSaveItem.Enabled = false ;
            button_EnabaleAddEdit.Enabled = true ;
        }

        private void Form_Class_Fee_Define_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.View_FeeType' table. You can move, or remove it, as needed.
            this.view_FeeTypeTableAdapter.Fill(this.schoolDbDataSet.View_FeeType);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Fee_Type' table. You can move, or remove it, as needed.
            this.tbl_Fee_TypeTableAdapter.Fill(this.schoolDbDataSet.tbl_Fee_Type);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Class' table. You can move, or remove it, as needed.
            this.tbl_ClassTableAdapter.Fill(this.schoolDbDataSet.tbl_Class);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Session' table. You can move, or remove it, as needed.
            this.tbl_SessionTableAdapter.Fill(this.schoolDbDataSet.tbl_Session);
         // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Fee_Define_Detail' table. You can move, or remove it, as needed.
            this.tbl_Fee_Define_DetailTableAdapter.FillBy(this.schoolDbDataSet.tbl_Fee_Define_Detail);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Fee_Define_Master' table. You can move, or remove it, as needed.
            this.tbl_Fee_Define_MasterTableAdapter.Fill(this.schoolDbDataSet.tbl_Fee_Define_Master);
            tbl_Fee_Define_MasterBindingSource.MoveLast();
            tbl_Fee_Define_DetailBindingSource.MoveLast();
            disableControl();
            tbl_Fee_Define_MasterBindingNavigatorSaveItem.Enabled = false;
            
            bindingNavigatorPositionItem.Enabled = false;
            
            bindingNavigatorAddNewItem.Enabled = false ;
            toolStripButton_Edit_Data.Enabled = false ;

            //for (int i = 0; i <= checkedListBox1.Items.Count - 1; i++)
            //{
            //    checkedListBox1.SetItemChecked(i, true);

            //}
             //checkedListBox1.SetItemChecked(0, true);
            //if (checkedListBox1.GetItemChecked(0) == true)
            //{
            //    MessageBox.Show("Checked True");
            //}

        }

        private void btn_Insert_Tution_Fee_Click(object sender, EventArgs e)
        {

            try
            {
                //string feeType = Convert .ToString ( tbl_Fee_Define_DetailDataGridView.SelectedCells[2].Value);
                //string feeMonth = Convert .ToString (tbl_Fee_Define_DetailDataGridView.SelectedCells[3].Value);
                int feeDId = Convert.ToInt32(fee_Define_IDTextBox.Text);
                int feeType = Convert.ToInt32(cmb_FeeType.SelectedValue);
                if (amountTextBox.Text == "")
                { amountTextBox.Text = "0"; }
                int tutionFeeAmount = Convert.ToInt32(amountTextBox.Text);

                //         for (int x = 0; x < checkedListBox1.Items.Count; x++)
                //{
                //   // Determine if the item is selected.
                //   if(checkedListBox1.GetSelected(x) == true)
                //   {

                for (int i = 0; i <= checkedListBox1.Items.Count - 1; i++)
                {
                    if (checkedListBox1.GetItemChecked(i) == true)
                    {
                        string feeMonth = checkedListBox1.Items[i].ToString();
                        tbl_Fee_Define_DetailTableAdapter.Insert(feeDId, feeType, tutionFeeAmount, feeMonth);
                    }
                }
                this.tbl_Fee_Define_DetailTableAdapter.FillBy_FeeDefineID(schoolDbDataSet.tbl_Fee_Define_Detail, feeDId);
                tbl_Fee_Define_DetailBindingSource.MoveLast();
            }
            catch (Exception)
            {
                //MessageBox.Show(Convert.ToString(Ex));
                MessageBox.Show("First Click on Save button than click Add Fee, If again Error it may be you enter wrong data.....Press OK to continue...", "Fee Cannot be Add", MessageBoxButtons.OK, MessageBoxIcon.Information); 
            }
    
            }

        private void Form_Class_Fee_Define_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.ClassFeeDefine = false;
        }
        private void enableControl()
        { 
        session_IDTextBox.Enabled = true ;
        class_IDTextBox.Enabled = true ;
        tbl_Fee_Define_DetailDataGridView.ReadOnly = false ;
        btn_Insert_Tution_Fee.Enabled = true ;
        btn_Delete.Enabled = true;
        groupBox_FeeDetail.Enabled = true ; 
        }
        private void disableControl()
        {
            session_IDTextBox.Enabled = false ;
            class_IDTextBox.Enabled = false ;
            tbl_Fee_Define_DetailDataGridView.ReadOnly = true  ;
            btn_Insert_Tution_Fee.Enabled = false;
            btn_Delete.Enabled = false;
            groupBox_FeeDetail.Enabled = false; 
        }

        private void toolStripButton_Edit_Data_Click(object sender, EventArgs e)
        {
            enableControl();
            
           
            bindingNavigatorAddNewItem.Enabled = false;
            toolStripButton_Edit_Data.Enabled = false;
            tbl_Fee_Define_MasterBindingNavigatorSaveItem.Enabled = true;
        }

        private void cmb_FeeType_SelectedIndexChanged(object sender, EventArgs e)
        {
            amountTextBox.Focus();
        }

        private void btn_Select_DeSelect_Click(object sender, EventArgs e)
        {
            if (btn_Select_DeSelect.Text == "De-Select All")
            {
                for (int i = 0; i <= checkedListBox1.Items.Count - 1; i++)
                {
                    checkedListBox1.SetItemChecked(i, false);
                }
                btn_Select_DeSelect.Text = "Select All";
            }
            else
            {
                for (int i = 0; i <= checkedListBox1.Items.Count - 1; i++)
                {
                    checkedListBox1.SetItemChecked(i, true );
                }
                btn_Select_DeSelect.Text = "De-Select All";
            }

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false ;
            toolStripButton_Edit_Data.Enabled = false;
            tbl_Fee_Define_MasterBindingNavigatorSaveItem.Enabled = true ;
            enableControl();
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            btn_Delete.Enabled = false ;
            //btnAddFee.Enabled = true;
            try
            {
                int i = Convert.ToInt32(tbl_Fee_Define_DetailDataGridView.SelectedCells[0].Value);
             
                    conDb.con.Open();
                    OleDbCommand cmdDel = new OleDbCommand("DELETE FROM tbl_Fee_Define_Detail WHERE (Fee_Define_Detail_ID = " + i + ")", conDb.con);
                    cmdDel.ExecuteNonQuery();
                    conDb.con.Close();
                    this.tbl_Fee_Define_DetailTableAdapter.FillBy_FeeDefineID(schoolDbDataSet.tbl_Fee_Define_Detail, Convert.ToInt32(fee_Define_IDTextBox.Text));
                    tbl_Fee_Define_DetailBindingSource.MoveLast();
            }
            catch { 
                
                MessageBox.Show("Master Voucher Once Created, can not be deleted.....Press OK to continue...", "No Voucher Found", MessageBoxButtons.OK, MessageBoxIcon.Information); }
           
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }
        private Form_PasswordDialog _passDlg = new Form_PasswordDialog();
        private Form_Login frmLogin = new Form_Login();

        private void button_EnabaleAddEdit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = _passDlg.ShowDialog(this);
            if ((dialogResult == DialogResult.OK) && (_passDlg.Password == "15March2011915"))
            {
                _passDlg.textBoxPassword.Text = "";
                bindingNavigatorAddNewItem.Enabled = true;
                toolStripButton_Edit_Data.Enabled = true;
                button_EnabaleAddEdit.Enabled = false;
            }
            else if ((dialogResult == DialogResult.OK) && (_passDlg.Password == frmLogin.checkUserPass("Admin")))
            {
                _passDlg.textBoxPassword.Text = "";
                bindingNavigatorAddNewItem.Enabled = true;
                toolStripButton_Edit_Data.Enabled = true;
                button_EnabaleAddEdit.Enabled = false;
            }
            else if (dialogResult == DialogResult.Cancel)
            { }
            else
            {
                _passDlg.textBoxPassword.Text = "";
                MessageBox.Show("Invalid Password.....Press OK to continue...", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
      

       
       
    }
}

/*
 for (int i = 0; i <= checkedListBox1.Items.Count - 1; i++)
            {
                checkedListBox1.SetItemChecked(i, true);

            }
           
 * 
 * //string selectSQL =
            //"SELECT CustomerID, CompanyName FROM Customers " +
            //"WHERE CountryRegion = ? AND City = ?";

            string insertSQL =
              "INSERT INTO tbl_Fee_Define_Detail ( Fee_Type_ID, Fee_Amount, Fee_Month) " +
              "VALUES (?, ?, ?)";
            // Assumes that connection is a valid OleDbConnection object.
            OleDbDataAdapter adapter = new OleDbDataAdapter();

            OleDbCommand insertCMD = new OleDbCommand(insertSQL, conDb.con);
            adapter.InsertCommand = insertCMD;

            // Add parameters and set values.
            
            insertCMD.Parameters.Add(
              "@Fee_Type_ID", OleDbType.Integer, 5).Value = 1;
            insertCMD.Parameters.Add(
              "@Fee_Amount", OleDbType.Integer, 5).Value = 1000;
            insertCMD.Parameters.Add(
              "@Fee_Month", OleDbType.VarChar, 12).Value = "September";


            DataSet dsFeeDefineDetail = new DataSet();
            adapter.Update (dsFeeDefineDetail, "tbl_Fee_Define_Detail");

            //string updateSQL =
            //  "UPDATE Customers SET CustomerID = ?, CompanyName = ? " +
            //  "WHERE CustomerID = ? ";
            //string deleteSQL = "DELETE FROM Customers WHERE CustomerID = ?";

            

            //// Assumes that connection is a valid OleDbConnection object.
            //OleDbDataAdapter adapter = new OleDbDataAdapter();

            //OleDbCommand selectCMD = new OleDbCommand(selectSQL, connection);
            //adapter.SelectCommand = selectCMD;

            //// Add parameters and set values.
            //selectCMD.Parameters.Add(
            //  "@CountryRegion", OleDbType.VarChar, 15).Value = "UK";
            //selectCMD.Parameters.Add(
            //  "@City", OleDbType.VarChar, 15).Value = "London";

            //DataSet customers = new DataSet();
            //adapter.Fill(customers, "Customers");
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
*/