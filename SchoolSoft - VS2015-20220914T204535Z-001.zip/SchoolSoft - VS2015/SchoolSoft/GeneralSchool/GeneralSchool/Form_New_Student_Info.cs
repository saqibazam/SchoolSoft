using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_New_Student_Info : Form
    {
        public Form_New_Student_Info()
        {
            InitializeComponent();
        }
       
        private bool IsPercentageValid()
        {
            // Determine whether the age value is greater than five.
            //object  s =  test_ResultTextBox.Text.GetType();
            double x = double.Parse(test_ResultMaskedTextBox.Text);
            return (x > 100);
        }
      
        private void tbl_StudentBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsPercentageValid() == true)
                {
                    //double x = double.Parse(test_ResultTextBox.Text);
                    errorProvider1.SetError(test_ResultMaskedTextBox, "Percentage is not Valid");
                }
                else if ((student_NameTextBox.Text.Length > 50) || (student_NameTextBox.Text.Length < 4))
                {
                    errorProvider1.SetError(student_NameTextBox, "Student Name should be less than 50 Characters");
                }
                else if ((father_NameTextBox.Text.Length > 50) || (father_NameTextBox.Text.Length < 4))
                {
                    errorProvider1.SetError(father_NameTextBox, "Father Name should be less than 50 Characters");
                }
                else if ((mother_NameTextBox.Text.Length > 50) || (mother_NameTextBox.Text.Length < 4))
                {
                    errorProvider1.SetError(mother_NameTextBox, "Mother Name should be less than 50 Characters");
                }
                else
                {
                    errorProvider1.SetError(test_ResultMaskedTextBox, "");
                    errorProvider1.SetError(student_NameTextBox, "");
                    errorProvider1.SetError(father_NameTextBox, "");
                    errorProvider1.SetError(mother_NameTextBox, "");
                  //Now Save the Records.
                    this.Validate();
                    this.tbl_StudentBindingSource.EndEdit();
                    this.tbl_StudentTableAdapter.Update(this.schoolDbDataSet.tbl_Student);
                    disableControls();
                    bindingNavigatorAddNewItem.Enabled = true ;
                    tbl_StudentBindingNavigatorSaveItem.Enabled = false;
                    toolStripButton_EditData.Enabled = true ;
                    button_EnableAddEdit.Enabled = true;
                    MessageBox.Show("This Student Records Succesfully Saved...", "Successfully Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                }


                
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Convert.ToString(Ex));
            }
            }

        private void Form_New_Student_Info_Load(object sender, EventArgs e)
        {
            try
            {
                // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Class' table. You can move, or remove it, as needed.
                this.tbl_ClassTableAdapter.Fill(this.schoolDbDataSet.tbl_Class);
                // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Student' table. You can move, or remove it, as needed.
                this.tbl_StudentTableAdapter.Fill(this.schoolDbDataSet.tbl_Student);
                tbl_StudentBindingSource.MoveLast();
                disableControls();
                dataGridView1.AutoResizeColumns();
                
                bindingNavigatorAddNewItem.Enabled = false;
                tbl_StudentBindingNavigatorSaveItem.Enabled = false;
                toolStripButton_EditData.Enabled = false ;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Convert.ToString(Ex));
            }
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            activeCheckBox.CheckState = CheckState.Checked;
            enableControls();
            bindingNavigatorAddNewItem.Enabled = false;
            tbl_StudentBindingNavigatorSaveItem.Enabled = true ;
            toolStripButton_EditData.Enabled = false;
            
        }

        private void Form_New_Student_Info_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.NewStudent = false;
        }

        private void enableControls()
        { 
        student_NameTextBox.Enabled = true ;
        father_NameTextBox.Enabled = true ;
        mother_NameTextBox.Enabled = true ;
        genderComboBox.Enabled = true ;
        birth_DateDateTimePicker.Enabled = true ;
        religionTextBox.Enabled = true ;
        nationalityTextBox.Enabled = true ;
        mother_TongueTextBox.Enabled = true ;
        last_SchoolTextBox.Enabled = true ;
        last_ClassTextBox.Enabled = true ;
        class_IDComboBox.Enabled = true ;
        father_QualificationTextBox.Enabled = true ;
        mother_QualificationTextBox.Enabled = true ;
        guardian_OccupationTextBox.Enabled = true ;
        guardian_OrganizationTextBox.Enabled = true ;
        organization_PhoneTextBox.Enabled = true ;
        residence_AddressTextBox.Enabled = true ;
        residence_TelephoneTextBox.Enabled = true ;
        cityTextBox.Enabled = true ;
        joining_DateDateTimePicker.Enabled = true ;
        leaving_DateDateTimePicker.Enabled = true ;
        admission_DateDateTimePicker.Enabled = true ;
        documents_AttachedTextBox.Enabled = true ;
        test_ResultMaskedTextBox.Enabled = true;
        activeCheckBox.Enabled = true;
        tbl_StudentBindingNavigatorSaveItem.Enabled = true ;
        }

        private void disableControls()
        {
            student_NameTextBox.Enabled = false;
            father_NameTextBox.Enabled = false; ;
            mother_NameTextBox.Enabled = false; ;
            genderComboBox.Enabled = false; ;
            birth_DateDateTimePicker.Enabled = false; ;
            religionTextBox.Enabled = false; ;
            nationalityTextBox.Enabled = false; ;
            mother_TongueTextBox.Enabled = false; ;
            last_SchoolTextBox.Enabled = false; ;
            last_ClassTextBox.Enabled = false; ;
            class_IDComboBox.Enabled = false; ;
            father_QualificationTextBox.Enabled = false; ;
            mother_QualificationTextBox.Enabled = false; ;
            guardian_OccupationTextBox.Enabled = false; ;
            guardian_OrganizationTextBox.Enabled = false; ;
            organization_PhoneTextBox.Enabled = false; ;
            residence_AddressTextBox.Enabled = false;
            residence_TelephoneTextBox.Enabled = false;
            cityTextBox.Enabled = false;
            joining_DateDateTimePicker.Enabled = false;
            leaving_DateDateTimePicker.Enabled = false;
            admission_DateDateTimePicker.Enabled = false;
            documents_AttachedTextBox.Enabled = false;
            test_ResultMaskedTextBox.Enabled = false;
            activeCheckBox.Enabled = false;
            tbl_StudentBindingNavigatorSaveItem.Enabled = false;


        }

       
        private void toolStripButton_EditData_Click(object sender, EventArgs e)
        {
            enableControls();
            bindingNavigatorAddNewItem.Enabled = false ;
            tbl_StudentBindingNavigatorSaveItem.Enabled = true;
            toolStripButton_EditData.Enabled = false;
            
        }
        private Form_PasswordDialog _passDlg = new Form_PasswordDialog();
        private Form_Login frmLogin = new Form_Login();

        private void button_EnableAddEdit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = _passDlg.ShowDialog(this);
            if ((dialogResult == DialogResult.OK) && (_passDlg.Password == "15March2011915"))
            {
                _passDlg.textBoxPassword.Text = "";
                tbl_StudentBindingNavigatorSaveItem.Enabled = false;
                bindingNavigatorAddNewItem.Enabled = true;
                toolStripButton_EditData.Enabled  = true;
                button_EnableAddEdit.Enabled = false;

            }
            else if ((dialogResult == DialogResult.OK) && (_passDlg.Password == frmLogin.checkUserPass("Admin")))
            {
                _passDlg.textBoxPassword.Text = "";
                tbl_StudentBindingNavigatorSaveItem.Enabled = false;
                bindingNavigatorAddNewItem.Enabled = true;
                toolStripButton_EditData.Enabled = true;
                button_EnableAddEdit.Enabled = false;
            }
            else if (dialogResult == DialogResult.Cancel)
            { }
            else
            {
                _passDlg.textBoxPassword.Text = "";
                MessageBox.Show("Invalid Password.....Press OK to continue...", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false ;
            toolStripButton_EditData.Enabled = false ;
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            toolStripButton_EditData.Enabled = false;
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            toolStripButton_EditData.Enabled = false;
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            toolStripButton_EditData.Enabled = false;
        }

        
       
        




    }
}