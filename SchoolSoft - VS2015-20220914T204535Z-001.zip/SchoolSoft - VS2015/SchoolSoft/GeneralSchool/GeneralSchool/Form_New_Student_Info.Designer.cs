namespace GeneralSchool
{
    partial class Form_New_Student_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label student_IDLabel;
            System.Windows.Forms.Label student_NameLabel;
            System.Windows.Forms.Label father_NameLabel;
            System.Windows.Forms.Label mother_NameLabel;
            System.Windows.Forms.Label genderLabel;
            System.Windows.Forms.Label birth_DateLabel;
            System.Windows.Forms.Label religionLabel;
            System.Windows.Forms.Label nationalityLabel;
            System.Windows.Forms.Label mother_TongueLabel;
            System.Windows.Forms.Label last_SchoolLabel;
            System.Windows.Forms.Label last_ClassLabel;
            System.Windows.Forms.Label admission_InClassLabel;
            System.Windows.Forms.Label father_QualificationLabel;
            System.Windows.Forms.Label mother_QualificationLabel;
            System.Windows.Forms.Label guardian_OccupationLabel;
            System.Windows.Forms.Label guardian_OrganizationLabel;
            System.Windows.Forms.Label organization_PhoneLabel;
            System.Windows.Forms.Label residence_AddressLabel;
            System.Windows.Forms.Label cityLabel;
            System.Windows.Forms.Label residence_TelephoneLabel;
            System.Windows.Forms.Label joining_DateLabel;
            System.Windows.Forms.Label leaving_DateLabel;
            System.Windows.Forms.Label admission_DateLabel;
            System.Windows.Forms.Label documents_AttachedLabel;
            System.Windows.Forms.Label activeLabel;
            System.Windows.Forms.Label test_ResultLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_New_Student_Info));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.tbl_StudentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_StudentTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_StudentTableAdapter();
            this.tbl_StudentBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_StudentBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_EditData = new System.Windows.Forms.ToolStripButton();
            this.student_IDTextBox = new System.Windows.Forms.TextBox();
            this.student_NameTextBox = new System.Windows.Forms.TextBox();
            this.father_NameTextBox = new System.Windows.Forms.TextBox();
            this.mother_NameTextBox = new System.Windows.Forms.TextBox();
            this.birth_DateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.religionTextBox = new System.Windows.Forms.TextBox();
            this.nationalityTextBox = new System.Windows.Forms.TextBox();
            this.mother_TongueTextBox = new System.Windows.Forms.TextBox();
            this.last_SchoolTextBox = new System.Windows.Forms.TextBox();
            this.last_ClassTextBox = new System.Windows.Forms.TextBox();
            this.father_QualificationTextBox = new System.Windows.Forms.TextBox();
            this.mother_QualificationTextBox = new System.Windows.Forms.TextBox();
            this.guardian_OccupationTextBox = new System.Windows.Forms.TextBox();
            this.guardian_OrganizationTextBox = new System.Windows.Forms.TextBox();
            this.organization_PhoneTextBox = new System.Windows.Forms.TextBox();
            this.residence_AddressTextBox = new System.Windows.Forms.TextBox();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.residence_TelephoneTextBox = new System.Windows.Forms.TextBox();
            this.joining_DateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.leaving_DateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.admission_DateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.documents_AttachedTextBox = new System.Windows.Forms.TextBox();
            this.activeCheckBox = new System.Windows.Forms.CheckBox();
            this.tblClassBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_ClassTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ClassTableAdapter();
            this.class_IDComboBox = new System.Windows.Forms.ComboBox();
            this.genderComboBox = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.studentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fatherNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.motherNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.religionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nationalityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.motherTongueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastSchoolDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastClassDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fatherQualificationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.motherQualificationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.guardianOccupationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.guardianOrganizationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.organizationPhoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.residenceAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.residenceTelephoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.joiningDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.leavingDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.documentsAttachedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activeDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.classIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.admissionDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.testResultDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_EnableAddEdit = new System.Windows.Forms.Button();
            this.test_ResultMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            student_IDLabel = new System.Windows.Forms.Label();
            student_NameLabel = new System.Windows.Forms.Label();
            father_NameLabel = new System.Windows.Forms.Label();
            mother_NameLabel = new System.Windows.Forms.Label();
            genderLabel = new System.Windows.Forms.Label();
            birth_DateLabel = new System.Windows.Forms.Label();
            religionLabel = new System.Windows.Forms.Label();
            nationalityLabel = new System.Windows.Forms.Label();
            mother_TongueLabel = new System.Windows.Forms.Label();
            last_SchoolLabel = new System.Windows.Forms.Label();
            last_ClassLabel = new System.Windows.Forms.Label();
            admission_InClassLabel = new System.Windows.Forms.Label();
            father_QualificationLabel = new System.Windows.Forms.Label();
            mother_QualificationLabel = new System.Windows.Forms.Label();
            guardian_OccupationLabel = new System.Windows.Forms.Label();
            guardian_OrganizationLabel = new System.Windows.Forms.Label();
            organization_PhoneLabel = new System.Windows.Forms.Label();
            residence_AddressLabel = new System.Windows.Forms.Label();
            cityLabel = new System.Windows.Forms.Label();
            residence_TelephoneLabel = new System.Windows.Forms.Label();
            joining_DateLabel = new System.Windows.Forms.Label();
            leaving_DateLabel = new System.Windows.Forms.Label();
            admission_DateLabel = new System.Windows.Forms.Label();
            documents_AttachedLabel = new System.Windows.Forms.Label();
            activeLabel = new System.Windows.Forms.Label();
            test_ResultLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_StudentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_StudentBindingNavigator)).BeginInit();
            this.tbl_StudentBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblClassBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // student_IDLabel
            // 
            student_IDLabel.AutoSize = true;
            student_IDLabel.Location = new System.Drawing.Point(9, 27);
            student_IDLabel.Name = "student_IDLabel";
            student_IDLabel.Size = new System.Drawing.Size(61, 13);
            student_IDLabel.TabIndex = 1;
            student_IDLabel.Text = "Student ID:";
            // 
            // student_NameLabel
            // 
            student_NameLabel.AutoSize = true;
            student_NameLabel.Location = new System.Drawing.Point(9, 53);
            student_NameLabel.Name = "student_NameLabel";
            student_NameLabel.Size = new System.Drawing.Size(78, 13);
            student_NameLabel.TabIndex = 3;
            student_NameLabel.Text = "Student Name:";
            // 
            // father_NameLabel
            // 
            father_NameLabel.AutoSize = true;
            father_NameLabel.Location = new System.Drawing.Point(9, 79);
            father_NameLabel.Name = "father_NameLabel";
            father_NameLabel.Size = new System.Drawing.Size(71, 13);
            father_NameLabel.TabIndex = 5;
            father_NameLabel.Text = "Father Name:";
            // 
            // mother_NameLabel
            // 
            mother_NameLabel.AutoSize = true;
            mother_NameLabel.Location = new System.Drawing.Point(9, 105);
            mother_NameLabel.Name = "mother_NameLabel";
            mother_NameLabel.Size = new System.Drawing.Size(74, 13);
            mother_NameLabel.TabIndex = 7;
            mother_NameLabel.Text = "Mother Name:";
            // 
            // genderLabel
            // 
            genderLabel.AutoSize = true;
            genderLabel.Location = new System.Drawing.Point(9, 131);
            genderLabel.Name = "genderLabel";
            genderLabel.Size = new System.Drawing.Size(45, 13);
            genderLabel.TabIndex = 9;
            genderLabel.Text = "Gender:";
            // 
            // birth_DateLabel
            // 
            birth_DateLabel.AutoSize = true;
            birth_DateLabel.Location = new System.Drawing.Point(9, 158);
            birth_DateLabel.Name = "birth_DateLabel";
            birth_DateLabel.Size = new System.Drawing.Size(57, 13);
            birth_DateLabel.TabIndex = 11;
            birth_DateLabel.Text = "Birth Date:";
            // 
            // religionLabel
            // 
            religionLabel.AutoSize = true;
            religionLabel.Location = new System.Drawing.Point(9, 183);
            religionLabel.Name = "religionLabel";
            religionLabel.Size = new System.Drawing.Size(48, 13);
            religionLabel.TabIndex = 13;
            religionLabel.Text = "Religion:";
            // 
            // nationalityLabel
            // 
            nationalityLabel.AutoSize = true;
            nationalityLabel.Location = new System.Drawing.Point(9, 209);
            nationalityLabel.Name = "nationalityLabel";
            nationalityLabel.Size = new System.Drawing.Size(59, 13);
            nationalityLabel.TabIndex = 15;
            nationalityLabel.Text = "Nationality:";
            // 
            // mother_TongueLabel
            // 
            mother_TongueLabel.AutoSize = true;
            mother_TongueLabel.Location = new System.Drawing.Point(9, 235);
            mother_TongueLabel.Name = "mother_TongueLabel";
            mother_TongueLabel.Size = new System.Drawing.Size(83, 13);
            mother_TongueLabel.TabIndex = 17;
            mother_TongueLabel.Text = "Mother Tongue:";
            // 
            // last_SchoolLabel
            // 
            last_SchoolLabel.AutoSize = true;
            last_SchoolLabel.Location = new System.Drawing.Point(9, 260);
            last_SchoolLabel.Name = "last_SchoolLabel";
            last_SchoolLabel.Size = new System.Drawing.Size(66, 13);
            last_SchoolLabel.TabIndex = 19;
            last_SchoolLabel.Text = "Last School:";
            // 
            // last_ClassLabel
            // 
            last_ClassLabel.AutoSize = true;
            last_ClassLabel.Location = new System.Drawing.Point(317, 49);
            last_ClassLabel.Name = "last_ClassLabel";
            last_ClassLabel.Size = new System.Drawing.Size(58, 13);
            last_ClassLabel.TabIndex = 21;
            last_ClassLabel.Text = "Last Class:";
            // 
            // admission_InClassLabel
            // 
            admission_InClassLabel.AutoSize = true;
            admission_InClassLabel.Location = new System.Drawing.Point(315, 75);
            admission_InClassLabel.Name = "admission_InClassLabel";
            admission_InClassLabel.Size = new System.Drawing.Size(97, 13);
            admission_InClassLabel.TabIndex = 23;
            admission_InClassLabel.Text = "Admission In Class:";
            // 
            // father_QualificationLabel
            // 
            father_QualificationLabel.AutoSize = true;
            father_QualificationLabel.Location = new System.Drawing.Point(315, 101);
            father_QualificationLabel.Name = "father_QualificationLabel";
            father_QualificationLabel.Size = new System.Drawing.Size(101, 13);
            father_QualificationLabel.TabIndex = 25;
            father_QualificationLabel.Text = "Father Qualification:";
            // 
            // mother_QualificationLabel
            // 
            mother_QualificationLabel.AutoSize = true;
            mother_QualificationLabel.Location = new System.Drawing.Point(315, 127);
            mother_QualificationLabel.Name = "mother_QualificationLabel";
            mother_QualificationLabel.Size = new System.Drawing.Size(104, 13);
            mother_QualificationLabel.TabIndex = 27;
            mother_QualificationLabel.Text = "Mother Qualification:";
            // 
            // guardian_OccupationLabel
            // 
            guardian_OccupationLabel.AutoSize = true;
            guardian_OccupationLabel.Location = new System.Drawing.Point(315, 153);
            guardian_OccupationLabel.Name = "guardian_OccupationLabel";
            guardian_OccupationLabel.Size = new System.Drawing.Size(111, 13);
            guardian_OccupationLabel.TabIndex = 29;
            guardian_OccupationLabel.Text = "Guardian Occupation:";
            // 
            // guardian_OrganizationLabel
            // 
            guardian_OrganizationLabel.AutoSize = true;
            guardian_OrganizationLabel.Location = new System.Drawing.Point(315, 179);
            guardian_OrganizationLabel.Name = "guardian_OrganizationLabel";
            guardian_OrganizationLabel.Size = new System.Drawing.Size(115, 13);
            guardian_OrganizationLabel.TabIndex = 31;
            guardian_OrganizationLabel.Text = "Guardian Organization:";
            // 
            // organization_PhoneLabel
            // 
            organization_PhoneLabel.AutoSize = true;
            organization_PhoneLabel.Location = new System.Drawing.Point(315, 205);
            organization_PhoneLabel.Name = "organization_PhoneLabel";
            organization_PhoneLabel.Size = new System.Drawing.Size(103, 13);
            organization_PhoneLabel.TabIndex = 33;
            organization_PhoneLabel.Text = "Organization Phone:";
            // 
            // residence_AddressLabel
            // 
            residence_AddressLabel.AutoSize = true;
            residence_AddressLabel.Location = new System.Drawing.Point(315, 231);
            residence_AddressLabel.Name = "residence_AddressLabel";
            residence_AddressLabel.Size = new System.Drawing.Size(102, 13);
            residence_AddressLabel.TabIndex = 35;
            residence_AddressLabel.Text = "Residence Address:";
            // 
            // cityLabel
            // 
            cityLabel.AutoSize = true;
            cityLabel.Location = new System.Drawing.Point(720, 50);
            cityLabel.Name = "cityLabel";
            cityLabel.Size = new System.Drawing.Size(27, 13);
            cityLabel.TabIndex = 37;
            cityLabel.Text = "City:";
            // 
            // residence_TelephoneLabel
            // 
            residence_TelephoneLabel.AutoSize = true;
            residence_TelephoneLabel.Location = new System.Drawing.Point(315, 283);
            residence_TelephoneLabel.Name = "residence_TelephoneLabel";
            residence_TelephoneLabel.Size = new System.Drawing.Size(115, 13);
            residence_TelephoneLabel.TabIndex = 39;
            residence_TelephoneLabel.Text = "Residence Telephone:";
            // 
            // joining_DateLabel
            // 
            joining_DateLabel.AutoSize = true;
            joining_DateLabel.Location = new System.Drawing.Point(678, 75);
            joining_DateLabel.Name = "joining_DateLabel";
            joining_DateLabel.Size = new System.Drawing.Size(69, 13);
            joining_DateLabel.TabIndex = 41;
            joining_DateLabel.Text = "Joining Date:";
            // 
            // leaving_DateLabel
            // 
            leaving_DateLabel.AutoSize = true;
            leaving_DateLabel.Location = new System.Drawing.Point(678, 101);
            leaving_DateLabel.Name = "leaving_DateLabel";
            leaving_DateLabel.Size = new System.Drawing.Size(74, 13);
            leaving_DateLabel.TabIndex = 43;
            leaving_DateLabel.Text = "Leaving Date:";
            // 
            // admission_DateLabel
            // 
            admission_DateLabel.AutoSize = true;
            admission_DateLabel.Location = new System.Drawing.Point(669, 127);
            admission_DateLabel.Name = "admission_DateLabel";
            admission_DateLabel.Size = new System.Drawing.Size(83, 13);
            admission_DateLabel.TabIndex = 45;
            admission_DateLabel.Text = "Admission Date:";
            // 
            // documents_AttachedLabel
            // 
            documents_AttachedLabel.AutoSize = true;
            documents_AttachedLabel.Location = new System.Drawing.Point(642, 153);
            documents_AttachedLabel.Name = "documents_AttachedLabel";
            documents_AttachedLabel.Size = new System.Drawing.Size(110, 13);
            documents_AttachedLabel.TabIndex = 47;
            documents_AttachedLabel.Text = "Documents Attached:";
            // 
            // activeLabel
            // 
            activeLabel.AutoSize = true;
            activeLabel.Location = new System.Drawing.Point(707, 235);
            activeLabel.Name = "activeLabel";
            activeLabel.Size = new System.Drawing.Size(40, 13);
            activeLabel.TabIndex = 49;
            activeLabel.Text = "Active:";
            // 
            // test_ResultLabel
            // 
            test_ResultLabel.AutoSize = true;
            test_ResultLabel.Location = new System.Drawing.Point(661, 205);
            test_ResultLabel.Name = "test_ResultLabel";
            test_ResultLabel.Size = new System.Drawing.Size(86, 13);
            test_ResultLabel.TabIndex = 55;
            test_ResultLabel.Text = "Test Result in %:";
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_StudentBindingSource
            // 
            this.tbl_StudentBindingSource.DataMember = "tbl_Student";
            this.tbl_StudentBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tbl_StudentTableAdapter
            // 
            this.tbl_StudentTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_StudentBindingNavigator
            // 
            this.tbl_StudentBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_StudentBindingNavigator.BindingSource = this.tbl_StudentBindingSource;
            this.tbl_StudentBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_StudentBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_StudentBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.tbl_StudentBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_StudentBindingNavigatorSaveItem,
            this.toolStripButton_EditData});
            this.tbl_StudentBindingNavigator.Location = new System.Drawing.Point(15, 393);
            this.tbl_StudentBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_StudentBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_StudentBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_StudentBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_StudentBindingNavigator.Name = "tbl_StudentBindingNavigator";
            this.tbl_StudentBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_StudentBindingNavigator.Size = new System.Drawing.Size(427, 25);
            this.tbl_StudentBindingNavigator.TabIndex = 0;
            this.tbl_StudentBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(69, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.ReadOnly = true;
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_StudentBindingNavigatorSaveItem
            // 
            this.tbl_StudentBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_StudentBindingNavigatorSaveItem.Image")));
            this.tbl_StudentBindingNavigatorSaveItem.Name = "tbl_StudentBindingNavigatorSaveItem";
            this.tbl_StudentBindingNavigatorSaveItem.Size = new System.Drawing.Size(77, 22);
            this.tbl_StudentBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_StudentBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_StudentBindingNavigatorSaveItem_Click);
            // 
            // toolStripButton_EditData
            // 
            this.toolStripButton_EditData.Image = global::GeneralSchool.Properties.Resources.edit;
            this.toolStripButton_EditData.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_EditData.Name = "toolStripButton_EditData";
            this.toolStripButton_EditData.Size = new System.Drawing.Size(71, 22);
            this.toolStripButton_EditData.Text = "Edit Data";
            this.toolStripButton_EditData.Click += new System.EventHandler(this.toolStripButton_EditData_Click);
            // 
            // student_IDTextBox
            // 
            this.student_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Student_ID", true));
            this.student_IDTextBox.Enabled = false;
            this.student_IDTextBox.Location = new System.Drawing.Point(93, 24);
            this.student_IDTextBox.Name = "student_IDTextBox";
            this.student_IDTextBox.Size = new System.Drawing.Size(42, 20);
            this.student_IDTextBox.TabIndex = 2;
            // 
            // student_NameTextBox
            // 
            this.student_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Student_Name", true));
            this.student_NameTextBox.Location = new System.Drawing.Point(93, 50);
            this.student_NameTextBox.Name = "student_NameTextBox";
            this.student_NameTextBox.Size = new System.Drawing.Size(200, 20);
            this.student_NameTextBox.TabIndex = 0;
            // 
            // father_NameTextBox
            // 
            this.father_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Father_Name", true));
            this.father_NameTextBox.Location = new System.Drawing.Point(93, 76);
            this.father_NameTextBox.Name = "father_NameTextBox";
            this.father_NameTextBox.Size = new System.Drawing.Size(200, 20);
            this.father_NameTextBox.TabIndex = 1;
            // 
            // mother_NameTextBox
            // 
            this.mother_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Mother_Name", true));
            this.mother_NameTextBox.Location = new System.Drawing.Point(93, 102);
            this.mother_NameTextBox.Name = "mother_NameTextBox";
            this.mother_NameTextBox.Size = new System.Drawing.Size(200, 20);
            this.mother_NameTextBox.TabIndex = 2;
            // 
            // birth_DateDateTimePicker
            // 
            this.birth_DateDateTimePicker.CustomFormat = "dd-MMM-yyyy";
            this.birth_DateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tbl_StudentBindingSource, "Birth_Date", true));
            this.birth_DateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.birth_DateDateTimePicker.Location = new System.Drawing.Point(93, 154);
            this.birth_DateDateTimePicker.Name = "birth_DateDateTimePicker";
            this.birth_DateDateTimePicker.Size = new System.Drawing.Size(89, 20);
            this.birth_DateDateTimePicker.TabIndex = 4;
            // 
            // religionTextBox
            // 
            this.religionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Religion", true));
            this.religionTextBox.Location = new System.Drawing.Point(93, 180);
            this.religionTextBox.Name = "religionTextBox";
            this.religionTextBox.Size = new System.Drawing.Size(119, 20);
            this.religionTextBox.TabIndex = 5;
            // 
            // nationalityTextBox
            // 
            this.nationalityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Nationality", true));
            this.nationalityTextBox.Location = new System.Drawing.Point(93, 206);
            this.nationalityTextBox.Name = "nationalityTextBox";
            this.nationalityTextBox.Size = new System.Drawing.Size(119, 20);
            this.nationalityTextBox.TabIndex = 6;
            // 
            // mother_TongueTextBox
            // 
            this.mother_TongueTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Mother_Tongue", true));
            this.mother_TongueTextBox.Location = new System.Drawing.Point(93, 232);
            this.mother_TongueTextBox.Name = "mother_TongueTextBox";
            this.mother_TongueTextBox.Size = new System.Drawing.Size(119, 20);
            this.mother_TongueTextBox.TabIndex = 7;
            // 
            // last_SchoolTextBox
            // 
            this.last_SchoolTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Last_School", true));
            this.last_SchoolTextBox.Location = new System.Drawing.Point(93, 258);
            this.last_SchoolTextBox.Multiline = true;
            this.last_SchoolTextBox.Name = "last_SchoolTextBox";
            this.last_SchoolTextBox.Size = new System.Drawing.Size(200, 38);
            this.last_SchoolTextBox.TabIndex = 8;
            // 
            // last_ClassTextBox
            // 
            this.last_ClassTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Last_Class", true));
            this.last_ClassTextBox.Location = new System.Drawing.Point(436, 46);
            this.last_ClassTextBox.Name = "last_ClassTextBox";
            this.last_ClassTextBox.Size = new System.Drawing.Size(119, 20);
            this.last_ClassTextBox.TabIndex = 9;
            // 
            // father_QualificationTextBox
            // 
            this.father_QualificationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Father_Qualification", true));
            this.father_QualificationTextBox.Location = new System.Drawing.Point(436, 98);
            this.father_QualificationTextBox.Name = "father_QualificationTextBox";
            this.father_QualificationTextBox.Size = new System.Drawing.Size(119, 20);
            this.father_QualificationTextBox.TabIndex = 11;
            // 
            // mother_QualificationTextBox
            // 
            this.mother_QualificationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Mother_Qualification", true));
            this.mother_QualificationTextBox.Location = new System.Drawing.Point(436, 124);
            this.mother_QualificationTextBox.Name = "mother_QualificationTextBox";
            this.mother_QualificationTextBox.Size = new System.Drawing.Size(126, 20);
            this.mother_QualificationTextBox.TabIndex = 12;
            // 
            // guardian_OccupationTextBox
            // 
            this.guardian_OccupationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Guardian_Occupation", true));
            this.guardian_OccupationTextBox.Location = new System.Drawing.Point(436, 150);
            this.guardian_OccupationTextBox.Name = "guardian_OccupationTextBox";
            this.guardian_OccupationTextBox.Size = new System.Drawing.Size(126, 20);
            this.guardian_OccupationTextBox.TabIndex = 13;
            // 
            // guardian_OrganizationTextBox
            // 
            this.guardian_OrganizationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Guardian_Organization", true));
            this.guardian_OrganizationTextBox.Location = new System.Drawing.Point(436, 176);
            this.guardian_OrganizationTextBox.Name = "guardian_OrganizationTextBox";
            this.guardian_OrganizationTextBox.Size = new System.Drawing.Size(126, 20);
            this.guardian_OrganizationTextBox.TabIndex = 14;
            // 
            // organization_PhoneTextBox
            // 
            this.organization_PhoneTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Organization_Phone", true));
            this.organization_PhoneTextBox.Location = new System.Drawing.Point(436, 202);
            this.organization_PhoneTextBox.Name = "organization_PhoneTextBox";
            this.organization_PhoneTextBox.Size = new System.Drawing.Size(200, 20);
            this.organization_PhoneTextBox.TabIndex = 15;
            // 
            // residence_AddressTextBox
            // 
            this.residence_AddressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Residence_Address", true));
            this.residence_AddressTextBox.Location = new System.Drawing.Point(436, 228);
            this.residence_AddressTextBox.Multiline = true;
            this.residence_AddressTextBox.Name = "residence_AddressTextBox";
            this.residence_AddressTextBox.Size = new System.Drawing.Size(200, 43);
            this.residence_AddressTextBox.TabIndex = 16;
            // 
            // cityTextBox
            // 
            this.cityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "City", true));
            this.cityTextBox.Location = new System.Drawing.Point(763, 47);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(126, 20);
            this.cityTextBox.TabIndex = 18;
            // 
            // residence_TelephoneTextBox
            // 
            this.residence_TelephoneTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Residence_Telephone", true));
            this.residence_TelephoneTextBox.Location = new System.Drawing.Point(436, 280);
            this.residence_TelephoneTextBox.Name = "residence_TelephoneTextBox";
            this.residence_TelephoneTextBox.Size = new System.Drawing.Size(200, 20);
            this.residence_TelephoneTextBox.TabIndex = 17;
            // 
            // joining_DateDateTimePicker
            // 
            this.joining_DateDateTimePicker.CustomFormat = "dd-MMM-yyyy";
            this.joining_DateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tbl_StudentBindingSource, "Joining_Date", true));
            this.joining_DateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.joining_DateDateTimePicker.Location = new System.Drawing.Point(763, 71);
            this.joining_DateDateTimePicker.Name = "joining_DateDateTimePicker";
            this.joining_DateDateTimePicker.Size = new System.Drawing.Size(92, 20);
            this.joining_DateDateTimePicker.TabIndex = 19;
            // 
            // leaving_DateDateTimePicker
            // 
            this.leaving_DateDateTimePicker.CustomFormat = "dd-MMM-yyyy";
            this.leaving_DateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tbl_StudentBindingSource, "Leaving_Date", true));
            this.leaving_DateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.leaving_DateDateTimePicker.Location = new System.Drawing.Point(763, 97);
            this.leaving_DateDateTimePicker.Name = "leaving_DateDateTimePicker";
            this.leaving_DateDateTimePicker.Size = new System.Drawing.Size(92, 20);
            this.leaving_DateDateTimePicker.TabIndex = 20;
            // 
            // admission_DateDateTimePicker
            // 
            this.admission_DateDateTimePicker.CustomFormat = "dd-MMM-yyyy";
            this.admission_DateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tbl_StudentBindingSource, "Admission_Date", true));
            this.admission_DateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.admission_DateDateTimePicker.Location = new System.Drawing.Point(763, 123);
            this.admission_DateDateTimePicker.Name = "admission_DateDateTimePicker";
            this.admission_DateDateTimePicker.Size = new System.Drawing.Size(92, 20);
            this.admission_DateDateTimePicker.TabIndex = 21;
            // 
            // documents_AttachedTextBox
            // 
            this.documents_AttachedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Documents_Attached", true));
            this.documents_AttachedTextBox.Location = new System.Drawing.Point(763, 150);
            this.documents_AttachedTextBox.Multiline = true;
            this.documents_AttachedTextBox.Name = "documents_AttachedTextBox";
            this.documents_AttachedTextBox.Size = new System.Drawing.Size(170, 42);
            this.documents_AttachedTextBox.TabIndex = 22;
            // 
            // activeCheckBox
            // 
            this.activeCheckBox.Checked = true;
            this.activeCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.activeCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.tbl_StudentBindingSource, "Active", true));
            this.activeCheckBox.Location = new System.Drawing.Point(763, 230);
            this.activeCheckBox.Name = "activeCheckBox";
            this.activeCheckBox.Size = new System.Drawing.Size(24, 24);
            this.activeCheckBox.TabIndex = 24;
            // 
            // tblClassBindingSource
            // 
            this.tblClassBindingSource.DataMember = "tbl_Class";
            this.tblClassBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tbl_ClassTableAdapter
            // 
            this.tbl_ClassTableAdapter.ClearBeforeFill = true;
            // 
            // class_IDComboBox
            // 
            this.class_IDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tbl_StudentBindingSource, "Class_ID", true));
            this.class_IDComboBox.DataSource = this.tblClassBindingSource;
            this.class_IDComboBox.DisplayMember = "Class_Desc";
            this.class_IDComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.class_IDComboBox.FormattingEnabled = true;
            this.class_IDComboBox.Location = new System.Drawing.Point(436, 72);
            this.class_IDComboBox.Name = "class_IDComboBox";
            this.class_IDComboBox.Size = new System.Drawing.Size(119, 21);
            this.class_IDComboBox.TabIndex = 10;
            this.class_IDComboBox.ValueMember = "Class_ID";
            // 
            // genderComboBox
            // 
            this.genderComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Gender", true));
            this.genderComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.genderComboBox.FormattingEnabled = true;
            this.genderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.genderComboBox.Location = new System.Drawing.Point(93, 127);
            this.genderComboBox.Name = "genderComboBox";
            this.genderComboBox.Size = new System.Drawing.Size(89, 21);
            this.genderComboBox.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentIDDataGridViewTextBoxColumn,
            this.studentNameDataGridViewTextBoxColumn,
            this.fatherNameDataGridViewTextBoxColumn,
            this.motherNameDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn,
            this.birthDateDataGridViewTextBoxColumn,
            this.religionDataGridViewTextBoxColumn,
            this.nationalityDataGridViewTextBoxColumn,
            this.motherTongueDataGridViewTextBoxColumn,
            this.lastSchoolDataGridViewTextBoxColumn,
            this.lastClassDataGridViewTextBoxColumn,
            this.fatherQualificationDataGridViewTextBoxColumn,
            this.motherQualificationDataGridViewTextBoxColumn,
            this.guardianOccupationDataGridViewTextBoxColumn,
            this.guardianOrganizationDataGridViewTextBoxColumn,
            this.organizationPhoneDataGridViewTextBoxColumn,
            this.residenceAddressDataGridViewTextBoxColumn,
            this.cityDataGridViewTextBoxColumn,
            this.residenceTelephoneDataGridViewTextBoxColumn,
            this.joiningDateDataGridViewTextBoxColumn,
            this.leavingDateDataGridViewTextBoxColumn,
            this.documentsAttachedDataGridViewTextBoxColumn,
            this.activeDataGridViewCheckBoxColumn,
            this.classIDDataGridViewTextBoxColumn,
            this.admissionDateDataGridViewTextBoxColumn,
            this.testResultDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tbl_StudentBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 421);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(933, 199);
            this.dataGridView1.TabIndex = 56;
            // 
            // studentIDDataGridViewTextBoxColumn
            // 
            this.studentIDDataGridViewTextBoxColumn.DataPropertyName = "Student_ID";
            this.studentIDDataGridViewTextBoxColumn.HeaderText = "Student ID";
            this.studentIDDataGridViewTextBoxColumn.Name = "studentIDDataGridViewTextBoxColumn";
            this.studentIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // studentNameDataGridViewTextBoxColumn
            // 
            this.studentNameDataGridViewTextBoxColumn.DataPropertyName = "Student_Name";
            this.studentNameDataGridViewTextBoxColumn.HeaderText = "Student Name";
            this.studentNameDataGridViewTextBoxColumn.Name = "studentNameDataGridViewTextBoxColumn";
            this.studentNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fatherNameDataGridViewTextBoxColumn
            // 
            this.fatherNameDataGridViewTextBoxColumn.DataPropertyName = "Father_Name";
            this.fatherNameDataGridViewTextBoxColumn.HeaderText = "Father Name";
            this.fatherNameDataGridViewTextBoxColumn.Name = "fatherNameDataGridViewTextBoxColumn";
            this.fatherNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // motherNameDataGridViewTextBoxColumn
            // 
            this.motherNameDataGridViewTextBoxColumn.DataPropertyName = "Mother_Name";
            this.motherNameDataGridViewTextBoxColumn.HeaderText = "Mother Name";
            this.motherNameDataGridViewTextBoxColumn.Name = "motherNameDataGridViewTextBoxColumn";
            this.motherNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.motherNameDataGridViewTextBoxColumn.Visible = false;
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "Gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "Gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            this.genderDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // birthDateDataGridViewTextBoxColumn
            // 
            this.birthDateDataGridViewTextBoxColumn.DataPropertyName = "Birth_Date";
            this.birthDateDataGridViewTextBoxColumn.HeaderText = "Birth Date";
            this.birthDateDataGridViewTextBoxColumn.Name = "birthDateDataGridViewTextBoxColumn";
            this.birthDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.birthDateDataGridViewTextBoxColumn.Visible = false;
            // 
            // religionDataGridViewTextBoxColumn
            // 
            this.religionDataGridViewTextBoxColumn.DataPropertyName = "Religion";
            this.religionDataGridViewTextBoxColumn.HeaderText = "Religion";
            this.religionDataGridViewTextBoxColumn.Name = "religionDataGridViewTextBoxColumn";
            this.religionDataGridViewTextBoxColumn.ReadOnly = true;
            this.religionDataGridViewTextBoxColumn.Visible = false;
            // 
            // nationalityDataGridViewTextBoxColumn
            // 
            this.nationalityDataGridViewTextBoxColumn.DataPropertyName = "Nationality";
            this.nationalityDataGridViewTextBoxColumn.HeaderText = "Nationality";
            this.nationalityDataGridViewTextBoxColumn.Name = "nationalityDataGridViewTextBoxColumn";
            this.nationalityDataGridViewTextBoxColumn.ReadOnly = true;
            this.nationalityDataGridViewTextBoxColumn.Visible = false;
            // 
            // motherTongueDataGridViewTextBoxColumn
            // 
            this.motherTongueDataGridViewTextBoxColumn.DataPropertyName = "Mother_Tongue";
            this.motherTongueDataGridViewTextBoxColumn.HeaderText = "Mother Tongue";
            this.motherTongueDataGridViewTextBoxColumn.Name = "motherTongueDataGridViewTextBoxColumn";
            this.motherTongueDataGridViewTextBoxColumn.ReadOnly = true;
            this.motherTongueDataGridViewTextBoxColumn.Visible = false;
            // 
            // lastSchoolDataGridViewTextBoxColumn
            // 
            this.lastSchoolDataGridViewTextBoxColumn.DataPropertyName = "Last_School";
            this.lastSchoolDataGridViewTextBoxColumn.HeaderText = "Last School";
            this.lastSchoolDataGridViewTextBoxColumn.Name = "lastSchoolDataGridViewTextBoxColumn";
            this.lastSchoolDataGridViewTextBoxColumn.ReadOnly = true;
            this.lastSchoolDataGridViewTextBoxColumn.Visible = false;
            // 
            // lastClassDataGridViewTextBoxColumn
            // 
            this.lastClassDataGridViewTextBoxColumn.DataPropertyName = "Last_Class";
            this.lastClassDataGridViewTextBoxColumn.HeaderText = "Last Class";
            this.lastClassDataGridViewTextBoxColumn.Name = "lastClassDataGridViewTextBoxColumn";
            this.lastClassDataGridViewTextBoxColumn.ReadOnly = true;
            this.lastClassDataGridViewTextBoxColumn.Visible = false;
            // 
            // fatherQualificationDataGridViewTextBoxColumn
            // 
            this.fatherQualificationDataGridViewTextBoxColumn.DataPropertyName = "Father_Qualification";
            this.fatherQualificationDataGridViewTextBoxColumn.HeaderText = "Father_Qualification";
            this.fatherQualificationDataGridViewTextBoxColumn.Name = "fatherQualificationDataGridViewTextBoxColumn";
            this.fatherQualificationDataGridViewTextBoxColumn.ReadOnly = true;
            this.fatherQualificationDataGridViewTextBoxColumn.Visible = false;
            // 
            // motherQualificationDataGridViewTextBoxColumn
            // 
            this.motherQualificationDataGridViewTextBoxColumn.DataPropertyName = "Mother_Qualification";
            this.motherQualificationDataGridViewTextBoxColumn.HeaderText = "Mother_Qualification";
            this.motherQualificationDataGridViewTextBoxColumn.Name = "motherQualificationDataGridViewTextBoxColumn";
            this.motherQualificationDataGridViewTextBoxColumn.ReadOnly = true;
            this.motherQualificationDataGridViewTextBoxColumn.Visible = false;
            // 
            // guardianOccupationDataGridViewTextBoxColumn
            // 
            this.guardianOccupationDataGridViewTextBoxColumn.DataPropertyName = "Guardian_Occupation";
            this.guardianOccupationDataGridViewTextBoxColumn.HeaderText = "Guardian_Occupation";
            this.guardianOccupationDataGridViewTextBoxColumn.Name = "guardianOccupationDataGridViewTextBoxColumn";
            this.guardianOccupationDataGridViewTextBoxColumn.ReadOnly = true;
            this.guardianOccupationDataGridViewTextBoxColumn.Visible = false;
            // 
            // guardianOrganizationDataGridViewTextBoxColumn
            // 
            this.guardianOrganizationDataGridViewTextBoxColumn.DataPropertyName = "Guardian_Organization";
            this.guardianOrganizationDataGridViewTextBoxColumn.HeaderText = "Guardian_Organization";
            this.guardianOrganizationDataGridViewTextBoxColumn.Name = "guardianOrganizationDataGridViewTextBoxColumn";
            this.guardianOrganizationDataGridViewTextBoxColumn.ReadOnly = true;
            this.guardianOrganizationDataGridViewTextBoxColumn.Visible = false;
            // 
            // organizationPhoneDataGridViewTextBoxColumn
            // 
            this.organizationPhoneDataGridViewTextBoxColumn.DataPropertyName = "Organization_Phone";
            this.organizationPhoneDataGridViewTextBoxColumn.HeaderText = "Organization_Phone";
            this.organizationPhoneDataGridViewTextBoxColumn.Name = "organizationPhoneDataGridViewTextBoxColumn";
            this.organizationPhoneDataGridViewTextBoxColumn.ReadOnly = true;
            this.organizationPhoneDataGridViewTextBoxColumn.Visible = false;
            // 
            // residenceAddressDataGridViewTextBoxColumn
            // 
            this.residenceAddressDataGridViewTextBoxColumn.DataPropertyName = "Residence_Address";
            this.residenceAddressDataGridViewTextBoxColumn.HeaderText = "Residence_Address";
            this.residenceAddressDataGridViewTextBoxColumn.Name = "residenceAddressDataGridViewTextBoxColumn";
            this.residenceAddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.residenceAddressDataGridViewTextBoxColumn.Visible = false;
            // 
            // cityDataGridViewTextBoxColumn
            // 
            this.cityDataGridViewTextBoxColumn.DataPropertyName = "City";
            this.cityDataGridViewTextBoxColumn.HeaderText = "City";
            this.cityDataGridViewTextBoxColumn.Name = "cityDataGridViewTextBoxColumn";
            this.cityDataGridViewTextBoxColumn.ReadOnly = true;
            this.cityDataGridViewTextBoxColumn.Visible = false;
            // 
            // residenceTelephoneDataGridViewTextBoxColumn
            // 
            this.residenceTelephoneDataGridViewTextBoxColumn.DataPropertyName = "Residence_Telephone";
            this.residenceTelephoneDataGridViewTextBoxColumn.HeaderText = "Residence_Telephone";
            this.residenceTelephoneDataGridViewTextBoxColumn.Name = "residenceTelephoneDataGridViewTextBoxColumn";
            this.residenceTelephoneDataGridViewTextBoxColumn.ReadOnly = true;
            this.residenceTelephoneDataGridViewTextBoxColumn.Visible = false;
            // 
            // joiningDateDataGridViewTextBoxColumn
            // 
            this.joiningDateDataGridViewTextBoxColumn.DataPropertyName = "Joining_Date";
            this.joiningDateDataGridViewTextBoxColumn.HeaderText = "Joining_Date";
            this.joiningDateDataGridViewTextBoxColumn.Name = "joiningDateDataGridViewTextBoxColumn";
            this.joiningDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.joiningDateDataGridViewTextBoxColumn.Visible = false;
            // 
            // leavingDateDataGridViewTextBoxColumn
            // 
            this.leavingDateDataGridViewTextBoxColumn.DataPropertyName = "Leaving_Date";
            this.leavingDateDataGridViewTextBoxColumn.HeaderText = "Leaving_Date";
            this.leavingDateDataGridViewTextBoxColumn.Name = "leavingDateDataGridViewTextBoxColumn";
            this.leavingDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.leavingDateDataGridViewTextBoxColumn.Visible = false;
            // 
            // documentsAttachedDataGridViewTextBoxColumn
            // 
            this.documentsAttachedDataGridViewTextBoxColumn.DataPropertyName = "Documents_Attached";
            this.documentsAttachedDataGridViewTextBoxColumn.HeaderText = "Documents_Attached";
            this.documentsAttachedDataGridViewTextBoxColumn.Name = "documentsAttachedDataGridViewTextBoxColumn";
            this.documentsAttachedDataGridViewTextBoxColumn.ReadOnly = true;
            this.documentsAttachedDataGridViewTextBoxColumn.Visible = false;
            // 
            // activeDataGridViewCheckBoxColumn
            // 
            this.activeDataGridViewCheckBoxColumn.DataPropertyName = "Active";
            this.activeDataGridViewCheckBoxColumn.HeaderText = "Active";
            this.activeDataGridViewCheckBoxColumn.Name = "activeDataGridViewCheckBoxColumn";
            this.activeDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // classIDDataGridViewTextBoxColumn
            // 
            this.classIDDataGridViewTextBoxColumn.DataPropertyName = "Class_ID";
            this.classIDDataGridViewTextBoxColumn.DataSource = this.tblClassBindingSource;
            this.classIDDataGridViewTextBoxColumn.DisplayMember = "Class_Desc";
            this.classIDDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.classIDDataGridViewTextBoxColumn.HeaderText = "Admission in Class";
            this.classIDDataGridViewTextBoxColumn.Name = "classIDDataGridViewTextBoxColumn";
            this.classIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.classIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.classIDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.classIDDataGridViewTextBoxColumn.ValueMember = "Class_ID";
            // 
            // admissionDateDataGridViewTextBoxColumn
            // 
            this.admissionDateDataGridViewTextBoxColumn.DataPropertyName = "Admission_Date";
            this.admissionDateDataGridViewTextBoxColumn.HeaderText = "Admission Date";
            this.admissionDateDataGridViewTextBoxColumn.Name = "admissionDateDataGridViewTextBoxColumn";
            this.admissionDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // testResultDataGridViewTextBoxColumn
            // 
            this.testResultDataGridViewTextBoxColumn.DataPropertyName = "Test_Result";
            dataGridViewCellStyle2.Format = "N2";
            dataGridViewCellStyle2.NullValue = null;
            this.testResultDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.testResultDataGridViewTextBoxColumn.HeaderText = "Test %";
            this.testResultDataGridViewTextBoxColumn.Name = "testResultDataGridViewTextBoxColumn";
            this.testResultDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_EnableAddEdit);
            this.groupBox1.Controls.Add(this.test_ResultMaskedTextBox);
            this.groupBox1.Controls.Add(this.residence_AddressTextBox);
            this.groupBox1.Controls.Add(this.activeCheckBox);
            this.groupBox1.Controls.Add(test_ResultLabel);
            this.groupBox1.Controls.Add(activeLabel);
            this.groupBox1.Controls.Add(this.documents_AttachedTextBox);
            this.groupBox1.Controls.Add(this.genderComboBox);
            this.groupBox1.Controls.Add(documents_AttachedLabel);
            this.groupBox1.Controls.Add(this.class_IDComboBox);
            this.groupBox1.Controls.Add(this.admission_DateDateTimePicker);
            this.groupBox1.Controls.Add(admission_DateLabel);
            this.groupBox1.Controls.Add(student_IDLabel);
            this.groupBox1.Controls.Add(this.leaving_DateDateTimePicker);
            this.groupBox1.Controls.Add(this.student_IDTextBox);
            this.groupBox1.Controls.Add(leaving_DateLabel);
            this.groupBox1.Controls.Add(student_NameLabel);
            this.groupBox1.Controls.Add(this.joining_DateDateTimePicker);
            this.groupBox1.Controls.Add(this.student_NameTextBox);
            this.groupBox1.Controls.Add(joining_DateLabel);
            this.groupBox1.Controls.Add(father_NameLabel);
            this.groupBox1.Controls.Add(this.residence_TelephoneTextBox);
            this.groupBox1.Controls.Add(this.father_NameTextBox);
            this.groupBox1.Controls.Add(residence_TelephoneLabel);
            this.groupBox1.Controls.Add(mother_NameLabel);
            this.groupBox1.Controls.Add(this.cityTextBox);
            this.groupBox1.Controls.Add(this.mother_NameTextBox);
            this.groupBox1.Controls.Add(cityLabel);
            this.groupBox1.Controls.Add(genderLabel);
            this.groupBox1.Controls.Add(residence_AddressLabel);
            this.groupBox1.Controls.Add(birth_DateLabel);
            this.groupBox1.Controls.Add(this.organization_PhoneTextBox);
            this.groupBox1.Controls.Add(this.birth_DateDateTimePicker);
            this.groupBox1.Controls.Add(organization_PhoneLabel);
            this.groupBox1.Controls.Add(religionLabel);
            this.groupBox1.Controls.Add(this.guardian_OrganizationTextBox);
            this.groupBox1.Controls.Add(this.religionTextBox);
            this.groupBox1.Controls.Add(guardian_OrganizationLabel);
            this.groupBox1.Controls.Add(nationalityLabel);
            this.groupBox1.Controls.Add(this.guardian_OccupationTextBox);
            this.groupBox1.Controls.Add(this.nationalityTextBox);
            this.groupBox1.Controls.Add(guardian_OccupationLabel);
            this.groupBox1.Controls.Add(mother_TongueLabel);
            this.groupBox1.Controls.Add(this.mother_QualificationTextBox);
            this.groupBox1.Controls.Add(this.mother_TongueTextBox);
            this.groupBox1.Controls.Add(mother_QualificationLabel);
            this.groupBox1.Controls.Add(last_SchoolLabel);
            this.groupBox1.Controls.Add(this.father_QualificationTextBox);
            this.groupBox1.Controls.Add(this.last_SchoolTextBox);
            this.groupBox1.Controls.Add(father_QualificationLabel);
            this.groupBox1.Controls.Add(last_ClassLabel);
            this.groupBox1.Controls.Add(admission_InClassLabel);
            this.groupBox1.Controls.Add(this.last_ClassTextBox);
            this.groupBox1.Location = new System.Drawing.Point(12, 73);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(953, 320);
            this.groupBox1.TabIndex = 57;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Student Complete Information";
            // 
            // button_EnableAddEdit
            // 
            this.button_EnableAddEdit.Image = global::GeneralSchool.Properties.Resources.enable_add_edit;
            this.button_EnableAddEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_EnableAddEdit.Location = new System.Drawing.Point(681, 266);
            this.button_EnableAddEdit.Name = "button_EnableAddEdit";
            this.button_EnableAddEdit.Size = new System.Drawing.Size(131, 48);
            this.button_EnableAddEdit.TabIndex = 57;
            this.button_EnableAddEdit.Text = "Enable Add Edit";
            this.button_EnableAddEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_EnableAddEdit.UseVisualStyleBackColor = true;
            this.button_EnableAddEdit.Click += new System.EventHandler(this.button_EnableAddEdit_Click);
            // 
            // test_ResultMaskedTextBox
            // 
            this.test_ResultMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_StudentBindingSource, "Test_Result", true));
            this.test_ResultMaskedTextBox.Location = new System.Drawing.Point(763, 202);
            this.test_ResultMaskedTextBox.Mask = "00.00";
            this.test_ResultMaskedTextBox.Name = "test_ResultMaskedTextBox";
            this.test_ResultMaskedTextBox.Size = new System.Drawing.Size(49, 20);
            this.test_ResultMaskedTextBox.TabIndex = 56;
            this.test_ResultMaskedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Form_New_Student_Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 746);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tbl_StudentBindingNavigator);
            this.Name = "Form_New_Student_Info";
            this.Text = "Student Information Form";
            this.Load += new System.EventHandler(this.Form_New_Student_Info_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_New_Student_Info_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_StudentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_StudentBindingNavigator)).EndInit();
            this.tbl_StudentBindingNavigator.ResumeLayout(false);
            this.tbl_StudentBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblClassBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tbl_StudentBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_StudentTableAdapter tbl_StudentTableAdapter;
        private System.Windows.Forms.BindingNavigator tbl_StudentBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_StudentBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox student_IDTextBox;
        private System.Windows.Forms.TextBox student_NameTextBox;
        private System.Windows.Forms.TextBox father_NameTextBox;
        private System.Windows.Forms.TextBox mother_NameTextBox;
        private System.Windows.Forms.DateTimePicker birth_DateDateTimePicker;
        private System.Windows.Forms.TextBox religionTextBox;
        private System.Windows.Forms.TextBox nationalityTextBox;
        private System.Windows.Forms.TextBox mother_TongueTextBox;
        private System.Windows.Forms.TextBox last_SchoolTextBox;
        private System.Windows.Forms.TextBox last_ClassTextBox;
        private System.Windows.Forms.TextBox father_QualificationTextBox;
        private System.Windows.Forms.TextBox mother_QualificationTextBox;
        private System.Windows.Forms.TextBox guardian_OccupationTextBox;
        private System.Windows.Forms.TextBox guardian_OrganizationTextBox;
        private System.Windows.Forms.TextBox organization_PhoneTextBox;
        private System.Windows.Forms.TextBox residence_AddressTextBox;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.TextBox residence_TelephoneTextBox;
        private System.Windows.Forms.DateTimePicker joining_DateDateTimePicker;
        private System.Windows.Forms.DateTimePicker leaving_DateDateTimePicker;
        private System.Windows.Forms.DateTimePicker admission_DateDateTimePicker;
        private System.Windows.Forms.TextBox documents_AttachedTextBox;
        private System.Windows.Forms.CheckBox activeCheckBox;
        private System.Windows.Forms.BindingSource tblClassBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ClassTableAdapter tbl_ClassTableAdapter;
        private System.Windows.Forms.ComboBox class_IDComboBox;
        private System.Windows.Forms.ComboBox genderComboBox;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStripButton toolStripButton_EditData;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.MaskedTextBox test_ResultMaskedTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fatherNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn motherNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn religionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nationalityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn motherTongueDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastSchoolDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastClassDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fatherQualificationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn motherQualificationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn guardianOccupationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn guardianOrganizationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn organizationPhoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn residenceAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn residenceTelephoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn joiningDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn leavingDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn documentsAttachedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn activeDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn classIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn admissionDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn testResultDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button_EnableAddEdit;
    }
}