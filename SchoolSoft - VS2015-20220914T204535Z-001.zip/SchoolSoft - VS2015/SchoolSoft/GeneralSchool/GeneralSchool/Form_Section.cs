using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_Section : Form
    {
        public Form_Section()
        {
            InitializeComponent();
        }

        private void tbl_SectionBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_SectionBindingSource.EndEdit();
            this.tbl_SectionTableAdapter.Update(this.schoolDbDataSet.tbl_Section);
            section_DescTextBox.Enabled = false;
            button_EnableAdd.Enabled = true;
            bindingNavigatorAddNewItem.Enabled = false;
            tbl_SectionBindingNavigatorSaveItem.Enabled = false;
            MessageBox.Show("Record has been saved successfully.....Press OK to continue...", "Record has been saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form_Section_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Section' table. You can move, or remove it, as needed.
            this.tbl_SectionTableAdapter.Fill(this.schoolDbDataSet.tbl_Section);
            bindingNavigatorAddNewItem.Enabled = false;
            tbl_SectionBindingNavigatorSaveItem.Enabled = false ;
            section_DescTextBox.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void Form_Section_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.Section = false;
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            tbl_SectionBindingNavigatorSaveItem.Enabled = true;
            button_EnableAdd.Enabled = false ;
            section_DescTextBox.Enabled = true ;
        }

        private Form_PasswordDialog _passDlg = new Form_PasswordDialog();
        private Form_Login frmLogin = new Form_Login();

        private void button_EnableAdd_Click(object sender, EventArgs e)
        {
            
            DialogResult dialogResult = _passDlg.ShowDialog(this);
            if ((dialogResult == DialogResult.OK) && (_passDlg.Password == "15March2011915"))
            {
                _passDlg.textBoxPassword.Text = "";
                bindingNavigatorAddNewItem.Enabled = true ;
                button_EnableAdd.Enabled = false;
            }
            else if ((dialogResult == DialogResult.OK) && (_passDlg.Password == frmLogin.checkUserPass("Admin")))
            {
                _passDlg.textBoxPassword.Text = "";
                bindingNavigatorAddNewItem.Enabled = true;
                button_EnableAdd.Enabled = false;
            }
            else if (dialogResult == DialogResult.Cancel)
            { }
            else
            {
                _passDlg.textBoxPassword.Text = "";
                MessageBox.Show("Invalid Password.....Press OK to continue...", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
 
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }
    }
}