using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_Class : Form
    {
        public Form_Class()
        {
            InitializeComponent();
        }

        private void tbl_ClassBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.tbl_ClassBindingSource.EndEdit();
                this.tbl_ClassTableAdapter.Update(this.schoolDbDataSet.tbl_Class);
                disableControl();
                MessageBox.Show("Record has been saved successfully.....Press OK to continue...", "Record has been saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                button_EnableAddEdit.Enabled = true ;
                bindingNavigatorAddNewItem.Enabled = true;
                toolStripButton_Edit.Enabled = true;
                tbl_ClassBindingNavigatorSaveItem.Enabled = false;
                
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Convert.ToString(Ex));
            }
            }

        private void Form_Class_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Class' table. You can move, or remove it, as needed.
            this.tbl_ClassTableAdapter.Fill(this.schoolDbDataSet.tbl_Class);
            this.tbl_ClassBindingSource.MoveLast();
            disableControl();
            bindingNavigatorAddNewItem.Enabled = false ;
            toolStripButton_Edit.Enabled = false ;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void Form_Class_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.Class = false;
        }

        private void enableControl()
        { 
          class_CodeTextBox.Enabled = true ;
          class_DescTextBox.Enabled = true;
            bindingNavigatorAddNewItem.Enabled = true;
            
        }
        private void disableControl()
        {
            class_CodeTextBox.Enabled = false;
            class_DescTextBox.Enabled = false;
            tbl_ClassBindingNavigatorSaveItem.Enabled = false;
            
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            enableControl();
            tbl_ClassBindingNavigatorSaveItem.Enabled = true;
            toolStripButton_Edit.Enabled = false;
            bindingNavigatorAddNewItem.Enabled = false;
        }

        private void toolStripButton_Edit_Click(object sender, EventArgs e)
        {
            enableControl();
            bindingNavigatorAddNewItem.Enabled = false;
            toolStripButton_Edit.Enabled = false;
            tbl_ClassBindingNavigatorSaveItem.Enabled = true;

        }
        private Form_PasswordDialog _passDlg = new Form_PasswordDialog();
        private Form_Login frmLogin = new Form_Login();
       
        private void button_EnableAddEdit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = _passDlg.ShowDialog(this);
            if ((dialogResult == DialogResult.OK) && (_passDlg.Password == "15March2011915"))
            {
                _passDlg.textBoxPassword.Text = "";
                enableControl();
                button_EnableAddEdit.Enabled = false;
                toolStripButton_Edit.Enabled = true;
            }
            else if ((dialogResult == DialogResult.OK) && (_passDlg.Password == frmLogin.checkUserPass("Admin")))
            {
                _passDlg.textBoxPassword.Text = "";
                enableControl();
                button_EnableAddEdit.Enabled = false;
                toolStripButton_Edit.Enabled = true;
            }
            else if (dialogResult == DialogResult.Cancel)
            { }
            else
            {
                _passDlg.textBoxPassword.Text = "";
                MessageBox.Show("Invalid Password.....Press OK to continue...", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
 
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
 
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.Enabled = false;
            bindingNavigatorPositionItem.Enabled = false;
 
        }


    }
}