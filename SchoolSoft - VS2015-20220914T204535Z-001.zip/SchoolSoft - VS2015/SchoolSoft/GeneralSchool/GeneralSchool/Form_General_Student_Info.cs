using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;


namespace GeneralSchool
{
    public partial class Form_General_Student_Info : Form
    {
        Class_ConnectDB conDb = new Class_ConnectDB();
        MDIParent_Form mdiForm = new MDIParent_Form();
        
        public Form_General_Student_Info()
        {
           
            InitializeComponent();
        }
     
        private void Form_General_Student_Info_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Exemp_FV_Detail' table. You can move, or remove it, as needed.
            //this.tbl_Exemp_FV_DetailTableAdapter.Fill(this.schoolDbDataSet.tbl_Exemp_FV_Detail);
            //// TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Exemp_FV_Master' table. You can move, or remove it, as needed.
            //this.tbl_Exemp_FV_MasterTableAdapter.Fill(this.schoolDbDataSet.tbl_Exemp_FV_Master);
           
            ////Show School Data
            //textBoxHeader.Text = conDb._schoolName + "\r\n"  + conDb._address + "\r\n Tel: "  + conDb._phone +
            //"\r\n Session: " + conDb.returnSessionDesc();
            //////here we called string returnSessionID() function to retreive sessionID from Class_ConnectDB.cs
            this.label_Session_Id.Text = conDb.returnSessionID();
            //this.label_Session_Desc.Text = conDb.returnSessionDesc();
            //label_Session_Desc.Text = label_Session_Desc.Text;
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Fee_Voucher_Detail' table. You can move, or remove it, as needed.
            //this.tbl_Fee_Voucher_DetailTableAdapter.Fill(this.schoolDbDataSet.tbl_Fee_Voucher_Detail);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Fee_Voucher_Master' table. You can move, or remove it, as needed.
            //this.tbl_Fee_Voucher_MasterTableAdapter.Fill(this.schoolDbDataSet.tbl_Fee_Voucher_Master);
            //bindingNavigatorAddNewItem.Enabled = true;
            gR_NoTextBox.Focus();
           
            btnAddFee.Enabled = false;
            btn_DeleteVoucher.Enabled = false;
            btn_Add_FeeForExemption.Enabled  = false;
            btn_Delete_Exempt_Voucher_Detail.Enabled  = false;
            btnPrintVoucher.Enabled = false;
            btn_Print_Exempt_Voucher.Enabled = false;
           
        }

        private void gR_NoTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                //If Enter is pressed
                if (e.KeyChar == 13)
                {
                    
                    
                    int i = Convert.ToInt32(gR_NoTextBox.Text);

                    if (i != 0 && i >= 1000)
                    {

                        conDb.con.Open();
                        // Show StudentMovement Detail Table Data
                        OleDbCommand cmd3 = new OleDbCommand("Select * from View_Student_Information Where GR_No= " + Convert.ToInt32(gR_NoTextBox.Text) + " and Session_ID= " + Convert.ToInt32(label_Session_Id.Text) + "", conDb.con);
                        //OleDbCommand cmd3 = new OleDbCommand("Select * from View_Student_Information Where GR_No= " + Convert.ToInt32(gR_NoTextBox.Text) + " ", conDb.con);
                        OleDbDataReader reader3 = cmd3.ExecuteReader();
                        if (reader3.HasRows == true)
                        {
                            while (reader3.Read())
                            {
                                st_Mov_IDLabel1.Text = reader3["st_Mov_ID"].ToString();
                                session_DescLabel1.Text = reader3["Session_Desc"].ToString();


                                ClassID_label.Text = reader3["Class_ID"].ToString();
                                label_ClassDetail.Text = reader3["class_Detail"].ToString();

                                result_DescLabel1.Text = reader3["result_Desc"].ToString();
                                percentageLabel1.Text = reader3["percentage"].ToString();
                                rollLabel1.Text = reader3["roll"].ToString();
                                result_DescLabel1.Text = reader3["Result_Desc"].ToString();

                                student_NameLabel1.Text = reader3["Student_Name"].ToString();
                                father_NameLabel1.Text = reader3["Father_Name"].ToString();
                                genderLabel1.Text = reader3["Gender"].ToString();
                                
                                birth_DateLabel1.Text = reader3["Birth_Date"].ToString();
                                if (birth_DateLabel1.Text != "")
                                {
                                    DateTime dt = Convert.ToDateTime(birth_DateLabel1.Text);
                                    string datetimestring;
                                    datetimestring = string.Format("{0:MMM-dd-yyyy}", dt);
                                    birth_DateLabel1.Text = datetimestring;
                                }
                                //else { }
                                residence_AddressLabel1.Text = reader3["Residence_Address"].ToString();
                                residence_TelephoneLabel1.Text = reader3["Residence_Telephone"].ToString();
                                organization_PhoneLabel1.Text = reader3["Organization_Phone"].ToString();
                                admission_DateLabel1.Text = reader3["Admission_Date"].ToString();
                                if (admission_DateLabel1.Text != "")
                                {
                                    DateTime dt2 = Convert.ToDateTime(admission_DateLabel1.Text);
                                    string datetimestring2;
                                    datetimestring2 = string.Format("{0:MMM-dd-yyyy}", dt2);
                                    admission_DateLabel1.Text = datetimestring2;
                                }
                                mother_NameLabel1.Text = reader3["Mother_Name"].ToString();
                                religionLabel1.Text = reader3["Religion"].ToString();
                                mother_TongueLabel1.Text = reader3["Mother_Tongue"].ToString();
                                father_QualificationLabel1.Text = reader3["Father_Qualification"].ToString();
                                mother_QualificationLabel1.Text = reader3["Mother_Qualification"].ToString();

                            }
                        }
                        else
                        {
                            st_Mov_IDLabel1.Text = "";
                            session_DescLabel1.Text = "";
                            label_ClassDetail.Text = "";

                            result_DescLabel1.Text = "";
                            percentageLabel1.Text = "";
                            rollLabel1.Text = "";
                            result_DescLabel1.Text = "";

                            student_NameLabel1.Text = "";
                            father_NameLabel1.Text = "";
                            genderLabel1.Text = "";
                            birth_DateLabel1.Text = "";
                            residence_AddressLabel1.Text = "";
                            residence_TelephoneLabel1.Text = "";
                            organization_PhoneLabel1.Text = "";
                            admission_DateLabel1.Text = "";
                            mother_NameLabel1.Text = "";
                            religionLabel1.Text = "";
                            mother_TongueLabel1.Text = "";
                            father_QualificationLabel1.Text = "";
                            mother_QualificationLabel1.Text = "";

                            MessageBox.Show("No Record Found, Type a Valid GR Number,  Press OK to Continue...", "No Record Found", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        }
                        reader3.Close();
                        conDb.con.Close();
                        
                        tabControl_GeneralInfo.Enabled = true;

                        //Issue is that On first click on tab exempfeedetailgridvew not load
                        // in second click on this table it is load , solve this issue, it is pending.
                        loadExemptFeeTab();
                        btn_Print_Exempt_Voucher.Enabled = true;
                        //if (exemp_FVM_IDTextBox.Text != "")
                        //{
                        //    btn_Print_Exempt_Voucher.Enabled = true;

                        //}
                        //else { btn_Print_Exempt_Voucher.Enabled = false; }


                        loadFeeVoucherTab();
                        if (fee_Voucher_IDTextBox.Text != "")
                        {
                            btnPrintVoucher.Enabled = true;
                        }
                        else { btnPrintVoucher.Enabled = false; }

                       
                     }
                    

                }

               
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Convert.ToString(Ex));
                //MessageBox.Show("No Record Found, Type a Valid GR Number,  Press OK to Continue...", "No Record Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void feeDetailGridViewLoad()
        {
            //GeneralSchool.Properties.Settings.SchoolDbConnectionString
            //GeneralSchool.Properties .Settings .s

           try
            {

                //string Con = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Program Files\General Solutions\SetupGSchool\Data\SchoolDB.mdb";

                if (fee_Voucher_IDTextBox.Text != "")
                {
                   
                    string SqlFeeDetailVoucher = "SELECT Fee_Voucher_Detail_ID, Fee_Voucher_ID, Voucher_Date, Fee_Type, Fee_Amount, Fee_Month FROM View_Fee_Paid_History WHERE (Fee_Voucher_ID = " + Convert.ToInt32(fee_Voucher_IDTextBox.Text) + ") AND (Std_Mov_ID =" + Convert.ToInt32(st_Mov_IDLabel1.Text) + ") ";
                    // Pass connection string to the OledbConnection object
                    OleDbConnection OledbConn = new OleDbConnection(conDb.returnConString());

                    //Unpaid Fee Voucher Grid View Fill
                    OleDbDataAdapter daFee = new OleDbDataAdapter(SqlFeeDetailVoucher, conDb.returnConString());
                    DataTable dtFee = new DataTable();
                    daFee.Fill(dtFee);
                    FeeDetailCurrentVoucherBindingSource.DataSource = dtFee;
                    dgvFeeDetailCurrentVoucher.DataSource = FeeDetailCurrentVoucherBindingSource;

                    dgvFeeDetailCurrentVoucher.Columns[0].Width = 65;
                    dgvFeeDetailCurrentVoucher.Columns[0].HeaderText = "Fee ID";
                    dgvFeeDetailCurrentVoucher.Columns[1].Visible = false;
                    dgvFeeDetailCurrentVoucher.Columns[2].Visible = false;
                    dgvFeeDetailCurrentVoucher.Columns[3].HeaderText = "Fee Type";
                    //dgvFeeDetailCurrentVoucher.Columns[4].Width = 90;
                    dgvFeeDetailCurrentVoucher.Columns[4].HeaderText = "Fee Amount";
                    dgvFeeDetailCurrentVoucher.Columns[5].HeaderText = "Fee Month";
                }
                else {
                    dgvFeeDetailCurrentVoucher.DataSource = "";
                    MessageBox.Show("Fee Voucher Not Created, First Add Fee Voucher...", "No Fee Voucher Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Convert.ToString(Ex));
            }

     }
       
        private void UnpaidFeeGridViewLoad()
        {
            //issue AND STD_MOV_ID will be include in where clause
            try
            {
                //string Con = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Program Files\General Solutions\SetupGSchool\Data\SchoolDB.mdb";
                //string SqlUnPaid = "SELECT Paid, Fee_Define_Detail_ID, Session_ID, Class_ID, Fee_Type_ID, Fee_Type, Fee_Amount, Fee_Month FROM View_Fee WHERE (NOT (Fee_Define_Detail_ID IN (SELECT Fee_Define_Detail_ID FROM  view_Fee_Master_Detail where Std_Mov_ID =" + Convert.ToInt32(st_Mov_IDLabel1.Text) + "   ))) AND (Session_ID = " + Convert.ToInt32(label_Session_Id.Text) + ") AND (Class_ID = " + Convert.ToInt32(ClassID_label.Text) + ") order by Fee_Define_Detail_ID";
                string SqlUnPaid = "SELECT     Paid, Fee_Define_Detail_ID, Session_ID, Class_ID, Fee_Type_ID, Fee_Type, Fee_Amount, Fee_Month "+
                                    "FROM     View_Fee "+
                                    "WHERE     (NOT (Fee_Define_Detail_ID IN "+
                                    "(SELECT     Fee_Define_Detail_ID "+
                                    "FROM          View_Exemp_Fee_Master_Detail "+
                                    "WHERE      (Std_Mov_ID = " + Convert.ToInt32(st_Mov_IDLabel1.Text) + ")))) AND (NOT (Fee_Define_Detail_ID IN "+
                                    "(SELECT     Fee_Define_Detail_ID "+
                                    "FROM          view_Fee_Master_Detail "+
                                    "WHERE      (Std_Mov_ID = " + Convert.ToInt32(st_Mov_IDLabel1.Text) + ")))) AND (Session_ID = " + Convert.ToInt32(label_Session_Id.Text) + ") AND (Class_ID = " + Convert.ToInt32(ClassID_label.Text) + ") "+
                                    "ORDER BY Fee_Define_Detail_ID";

                // Pass connection string to the OledbConnection object
                OleDbConnection OledbConn = new OleDbConnection(conDb.returnConString());

                //Unpaid Fee Voucher Grid View Fill
                OleDbDataAdapter da = new OleDbDataAdapter(SqlUnPaid, conDb.returnConString());
                DataTable dt = new DataTable();
                da.Fill(dt);
                unpaidFeeBindingSource.DataSource = dt;

                dgvUnpaidFeeVoucher.DataSource = unpaidFeeBindingSource;
                //dgvUnpaidFeeVoucher.AutoResizeColumnHeadersHeight();
                //dgvUnpaidFeeVoucher.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.ColumnHeader);
                dgvUnpaidFeeVoucher.Columns[0].Width = 40;
                dgvUnpaidFeeVoucher.Columns[1].Visible = false;
                dgvUnpaidFeeVoucher.Columns[2].Visible = false;
                dgvUnpaidFeeVoucher.Columns[3].Visible = false;
                dgvUnpaidFeeVoucher.Columns[4].Visible = false;
                dgvUnpaidFeeVoucher.Columns[5].HeaderText = "Fee Type";
                dgvUnpaidFeeVoucher.Columns[5].Width = 110;
                dgvUnpaidFeeVoucher.Columns[5].ReadOnly = true;
                dgvUnpaidFeeVoucher.Columns[6].HeaderText = "Fee Amount";
                dgvUnpaidFeeVoucher.Columns[6].Width = 80;
                dgvUnpaidFeeVoucher.Columns[6].ReadOnly = true;
                dgvUnpaidFeeVoucher.Columns[7].HeaderText = "Fee Month";
                dgvUnpaidFeeVoucher.Columns[7].Width = 90;
                dgvUnpaidFeeVoucher.Columns[7].ReadOnly = true;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Convert.ToString(Ex));
            }

        }

        private void PaidFeeGridViewLoad()
        {
            try{
            //string Con = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Program Files\General Solutions\SetupGSchool\Data\SchoolDB.mdb";
           
            string SqlFeePaidHistory = "SELECT Fee_Voucher_ID, Voucher_Date, Std_Mov_ID, Fee_Define_Detail_ID, Fee_Type_ID, Fee_Type, Fee_Amount, Fee_Month FROM View_Fee_Paid_History WHERE (Std_Mov_ID =" + Convert.ToInt32(st_Mov_IDLabel1.Text) + ") ";

           
            //FeePaidHistory DataGridView Fill
            OleDbDataAdapter da2 = new OleDbDataAdapter(SqlFeePaidHistory, conDb.returnConString());
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);
            paidHistorybindingSource.DataSource = dt2;
            dgv_FeePaidHistory.DataSource = paidHistorybindingSource;
            //dgv_FeePaidHistory.AutoResizeColumnHeadersHeight();
            //dgv_FeePaidHistory.AutoResizeColumns(
            //DataGridViewAutoSizeColumnsMode.ColumnHeader);
            //dgv_FeePaidHistory.Columns[1].
            dgv_FeePaidHistory.Columns[0].Width = 50;
            dgv_FeePaidHistory.Columns[0].HeaderText = "Voucher";
            dgv_FeePaidHistory.Columns[1].HeaderText = "Voucher Date";
            dgv_FeePaidHistory.Columns[2].Visible = false;
            dgv_FeePaidHistory.Columns[3].Visible = false;
            dgv_FeePaidHistory.Columns[4].Visible = false;
            dgv_FeePaidHistory.Columns[5].HeaderText = "Fee Type";
            dgv_FeePaidHistory.Columns[6].HeaderText = "Fee Amount";
            dgv_FeePaidHistory.Columns[7].HeaderText = "Fee Month";
        }
        catch (Exception Ex)
        {
            MessageBox.Show(Convert.ToString(Ex));
        }

            }

       
        private void loadFeeVoucherTab()
        {
            //tabControl_GeneralInfo.SelectTab(0);

            this.tbl_Fee_Voucher_MasterTableAdapter.FillBy(this.schoolDbDataSet.tbl_Fee_Voucher_Master, Convert.ToInt32(st_Mov_IDLabel1.Text));
            this.tbl_Fee_Voucher_MasterBindingSource.MoveLast();
            Tf_lbl_GRNo.Text = gR_NoTextBox.Text;

            UnpaidFeeGridViewLoad();
            PaidFeeGridViewLoad();
            feeTotals();
            feeDetailGridViewLoad();

            //bindingNavigatorAddNewItem.Enabled = true;
            ////tbl_Fee_Voucher_MasterBindingNavigatorSaveItem.Enabled = false;
            //btnAddFee.Enabled = false;
            
        }


        private void btnAddFee_Click(object sender, EventArgs e)
        {
            btnAddFee.Enabled = false;
            btn_DeleteVoucher.Enabled = true;


                for (int counter = 0; counter < (dgvUnpaidFeeVoucher.Rows.Count);
                counter++)
            {
                if (Convert .ToBoolean ( dgvUnpaidFeeVoucher.Rows[counter].Cells["Paid"].Value) == true)
                {
                    int fee_Voucher_ID;
                    fee_Voucher_ID = Convert.ToInt32(fee_Voucher_IDTextBox.Text);
                    int fee_Define_Detail_ID;
                  
                    fee_Define_Detail_ID = Convert.ToInt32(dgvUnpaidFeeVoucher.Rows[counter].Cells[1].Value);
                    this.tbl_Fee_Voucher_DetailTableAdapter.Insert(fee_Voucher_ID, fee_Define_Detail_ID);
                }
                else
                {
                    //In Future to do coding for select at least one row.....
                    //MessageBox.Show("Select at least One Row... ", "Select Row", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //btnAddFee.Enabled = true;
                    continue;
                }
            }
            this.tbl_Fee_Voucher_DetailBindingSource.EndEdit();
            this.tbl_Fee_Voucher_DetailTableAdapter.Update(schoolDbDataSet.tbl_Fee_Voucher_Detail);
                            
                
                feeDetailGridViewLoad();
                feeTotals();
                UnpaidFeeGridViewLoad();
                PaidFeeGridViewLoad();

                bindingNavigatorAddNewItem.Enabled = false;
                
                btnAddFee.Enabled = false;
           
        }


        private void tbl_Fee_Voucher_MasterBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
           

            //bindingNavigatorAddNewItem.Enabled = false;
            //tbl_Fee_Voucher_MasterBindingNavigatorSaveItem.Enabled = false;
            //btnAddFee.Enabled = false;

            //feeTotals();
            //feeDetailGridViewLoad();
        }

        private void maxFeeVoucher()
        {
            conDb.con.Open();
            OleDbCommand cmdMax = new OleDbCommand("SELECT Max(Fee_Voucher_ID) AS Expr1 FROM tbl_Fee_Voucher_Master HAVING Std_Mov_ID = " + Convert.ToInt32(st_Mov_IDLabel1.Text) + "", conDb.con);

            object returnValueMax;
            returnValueMax = cmdMax.ExecuteScalar();
            conDb.con.Close();
            fee_Voucher_IDTextBox.Text = Convert.ToString(returnValueMax);
           
        }

        private void feeTotals() 
        {
            try {
            conDb.con.Open();

                //Sum Total Student Fee Paid
            OleDbCommand cmd2 = new OleDbCommand("SELECT SUM(Fee_Amount) AS Expr1 FROM View_Fee_Paid_History HAVING Std_Mov_ID = " + Convert.ToInt32(st_Mov_IDLabel1.Text) +"" , conDb.con);
            
            object returnValueFeePaid;
            returnValueFeePaid = cmd2.ExecuteScalar();
            label_feePaid.Text = Convert.ToString(returnValueFeePaid);
            if (label_feePaid.Text == "")
            {
                label_feePaid.Text = "0";
            }

                //Sum Total Exemption Fee
            OleDbCommand cmdEF = new OleDbCommand("SELECT SUM(Fee_Amount) AS Expr1 FROM View_Exemp_Fee_History HAVING Std_Mov_ID = " + Convert.ToInt32(st_Mov_IDLabel1.Text) + "", conDb.con);

            object returnValueEF;
            returnValueEF = cmdEF.ExecuteScalar();
           lbl_totalFeeExemption.Text = Convert.ToString(returnValueEF);
           if (lbl_totalFeeExemption.Text == "")
            {
                lbl_totalFeeExemption.Text = "0";
            }

                //Sum Total Academic Fee
            OleDbCommand cmd3 = new OleDbCommand("SELECT SUM(Fee_Amount) AS Expr2 FROM View_Fee HAVING (Session_ID = " + Convert.ToInt32(label_Session_Id .Text ) + ")AND (Class_ID = " + Convert.ToInt32(ClassID_label .Text  ) + ")", conDb.con);
            object returnValueTotalFee;
            returnValueTotalFee = cmd3.ExecuteScalar();
            label_totalFee.Text = Convert.ToString(returnValueTotalFee);
            
          
            int balanceFee;
            if (label_totalFee.Text != "")
            {
                balanceFee = Convert.ToInt32(returnValueTotalFee) - (Convert.ToInt32(label_feePaid.Text) + int.Parse (lbl_totalFeeExemption .Text ) );
                label_feeBalance.Text = Convert.ToString(balanceFee);
            }
            else
            {MessageBox.Show("This Session Year Fee is not Define First Define Fee and than create Voucher... ", "Session Year Fee Not Define", MessageBoxButtons.OK, MessageBoxIcon.Information); }
                         
             conDb.con.Close();
            }
            catch (Exception Ex)
            {
              MessageBox.Show(Convert.ToString(Ex)); 
            }
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
           
        }

      
        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            feeDetailGridViewLoad();
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            feeDetailGridViewLoad();
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            feeDetailGridViewLoad();
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            feeDetailGridViewLoad();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
           
        }

        private void btnPrintVoucher_Click(object sender, EventArgs e)
        {
            try
            {
                // ReportDocument cr = new ReportDocument();
                CrystalReport_Fee_Voucher crFV = new CrystalReport_Fee_Voucher();
                crFV.Load("C://SchoolSoft//GeneralSchool//GeneralSchool//CrystalReport_Fee_Voucher.rpt");
                crystalReportViewer_VoucherReport.ReportSource = crFV;
                crystalReportViewer_VoucherReport.DisplayToolbar = true;
                crystalReportViewer_VoucherReport.Zoom(80);
                //crystalReportViewer_VoucherReport.Right;
                crFV.SetParameterValue("schoolName", conDb._schoolName);
                crFV.SetParameterValue("addressSchool", conDb._address);
                crFV.SetParameterValue("phoneSchool", conDb._phone);
                string compNamAdd = conDb._companyName + " URL: " + conDb._website + " Email: " + conDb._email;
                crFV.SetParameterValue("_companyNameAddress", compNamAdd);


                int i = int.Parse(fee_Voucher_IDTextBox.Text);
                crFV.SetParameterValue("FeeVouchNo", i);

                ConnectionInfo connectionInfo = new ConnectionInfo();
                connectionInfo.Password = "30615aorangikhi75800";
                SetDBLogonForReport(connectionInfo);


                tabControl_GeneralInfo.SelectTab(2);
            }
            catch (Exception )
            {
                MessageBox.Show("Fee Voucher Not Found, First Create Voucher... ", "Voucher Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //MessageBox.Show(Convert.ToString(Ex));
            }
        }

        private void Form_General_Student_Info_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.GeneralStudent = false;
        }

        

       
        private void loadExemptFeeTab()
        {
            //tabControl_GeneralInfo.SelectTab(1);

            this.tbl_Exemp_FV_MasterTableAdapter.FillByStd_Mov_ID(this.schoolDbDataSet.tbl_Exemp_FV_Master, Convert.ToInt32(st_Mov_IDLabel1.Text));
            this.tbl_Exemp_FV_MasterBindingSource.MoveLast();
            Tf_lbl_GRNo.Text = gR_NoTextBox.Text;

            //DateTime dt = DateTime.Now;
            //string datetimestring;
            //datetimestring = string.Format("{0:MMM-dd-yyyy}", dt);

            //exemp_FV_DateDateTimePicker.Text = datetimestring;

            UnpaidFeeGridViewLoad();
            PaidFeeGridViewLoad();
            feeTotals();

            exemptFeeDetailGridViewLoad();
           
            //bindingNavigatorAddNewItem.Enabled = true;
            ////tbl_Fee_Voucher_MasterBindingNavigatorSaveItem.Enabled = false;
            //btnAddFee.Enabled = false;
        }

        private void btn_Add_FeeForExemption_Click(object sender, EventArgs e)
        {
            btn_Add_FeeForExemption.Enabled = false ;
            btn_Delete_Exempt_Voucher_Detail.Enabled = true;

            for (int counter = 0; counter < (dgvUnpaidFeeVoucher.Rows.Count);
                counter++)
            {
                if (Convert.ToBoolean(dgvUnpaidFeeVoucher.Rows[counter].Cells["Paid"].Value) == true)
                {
                    int exemp_FVM_ID = int.Parse(exemp_FVM_IDTextBox.Text);
                    int fee_Define_Detail_ID = Convert .ToInt32 (dgvUnpaidFeeVoucher.Rows[counter].Cells[1].Value);
                    this.tbl_Exemp_FV_DetailTableAdapter.Insert(exemp_FVM_ID,fee_Define_Detail_ID);
                }
                else
                {

                    //MessageBox.Show("Select at least One Row... ", "Select Row", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //btnAddFee.Enabled = true;
                    continue;
                }
            }
            this.tbl_Exemp_FV_DetailBindingSource.EndEdit();
            this.tbl_Exemp_FV_DetailTableAdapter.Update(schoolDbDataSet.tbl_Exemp_FV_Detail);


            exemptFeeDetailGridViewLoad();
            feeTotals();
            UnpaidFeeGridViewLoad();
            PaidFeeGridViewLoad();

            //bindingNavigatorAddNewItem.Enabled = false;

            //btnAddFee.Enabled = false;
        }

        private void exemptFeeDetailGridViewLoad()
        {
            //GeneralSchool.Properties.Settings.SchoolDbConnectionString
            //GeneralSchool.Properties .Settings .s

            try
            {
                // Use a return string in a Function()in Base class, and use it here, to do it.
                //string Con = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Program Files\General Solutions\SetupGSchool\Data\SchoolDB.mdb";
                //One Record In Master Detail Exempt Vouchere Table Must Add, If not Add an Error will be Occurd and next time it will oK.
                
                           
                if (exemp_FVM_IDTextBox.Text != "")
                {

                    string SqlExmpFeeDetailVoucher = "SELECT Exemp_FVD_ID, Exemp_FVM_ID, Exemp_FV_Date, Fee_Type, Fee_Amount, Fee_Month FROM View_Exemp_Fee_History WHERE (Exemp_FVM_ID = " + Convert.ToInt32(exemp_FVM_IDTextBox.Text) + ") AND (Std_Mov_ID =" + Convert.ToInt32(st_Mov_IDLabel1.Text) + ") ";
                    // Pass connection string to the OledbConnection object
                    OleDbConnection OledbConn = new OleDbConnection(conDb.returnConString());

                    //Unpaid Fee Voucher Grid View Fill
                    OleDbDataAdapter daExmpFee = new OleDbDataAdapter(SqlExmpFeeDetailVoucher, conDb.returnConString());
                    DataTable dtExmpFee = new DataTable();
                    daExmpFee.Fill(dtExmpFee);
                    ExemptFeeDetailVoucherBindingSource.DataSource = dtExmpFee;
                    dgvExemptFeeDetailVoucher.DataSource = ExemptFeeDetailVoucherBindingSource;

                    dgvExemptFeeDetailVoucher.Columns[0].Width = 65;
                    dgvExemptFeeDetailVoucher.Columns[0].HeaderText = "Fee ID";
                    dgvExemptFeeDetailVoucher.Columns[1].Visible = false;
                    dgvExemptFeeDetailVoucher.Columns[2].Visible = false;
                    dgvExemptFeeDetailVoucher.Columns[3].HeaderText = "Fee Type";
                    //dgvFeeDetailCurrentVoucher.Columns[4].Width = 90;
                    dgvExemptFeeDetailVoucher.Columns[4].HeaderText = "Fee Amount";
                    dgvExemptFeeDetailVoucher.Columns[5].HeaderText = "Fee Month";
                }
                else
                {
                    dgvExemptFeeDetailVoucher.DataSource = "";
                    //MessageBox.Show("Exempt Fee Voucher Not Created, First Add Exempt Fee Voucher...", "No Exempt Fee Voucher Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Convert.ToString(Ex));
            }

        }

        private void btn_Add_Exempt_Voucher_Click(object sender, EventArgs e)
        {
            btn_Add_Exempt_Voucher.Enabled = false;
            btn_Add_FeeForExemption.Enabled = true;

            DateTime dt = DateTime.Now;
            string datetimestring;
            datetimestring = string.Format("{0:MMM-dd-yyyy}", dt);

            exemp_FV_DateTextBox.Text = datetimestring;
            //std_Mov_IDTextBox.Text = st_Mov_IDLabel1.Text;
            
            this.tbl_Exemp_FV_MasterTableAdapter.Insert(DateTime.Today.Date, Convert.ToInt32(st_Mov_IDLabel1.Text));

            maxExmpFeeVoucher();

            dgvExemptFeeDetailVoucher.DataSource = "";

            //bindingNavigatorAddNewItem.Enabled = false;

            //btnAddFee.Enabled = true;
        }

        private void maxExmpFeeVoucher()
        {
            conDb.con.Open();
            OleDbCommand cmdMaxEF = new OleDbCommand("SELECT Max(Exemp_FVM_ID) AS Expr1 FROM tbl_Exemp_FV_Master HAVING Std_Mov_ID = " + Convert.ToInt32(st_Mov_IDLabel1.Text) + "", conDb.con);

            object returnValueMaxEF;
            returnValueMaxEF = cmdMaxEF.ExecuteScalar();
            conDb.con.Close();
            exemp_FVM_IDTextBox.Text = Convert.ToString(returnValueMaxEF);
            
        }

        private void btn_Delete_Exempt_Voucher_Detail_Click(object sender, EventArgs e)
        {
            btn_Delete_Exempt_Voucher_Detail.Enabled = false ;
            btn_Add_FeeForExemption.Enabled = true;

            try
            {
                int i = Convert.ToInt32(dgvExemptFeeDetailVoucher.SelectedCells[0].Value);
                conDb.con.Open();

                OleDbCommand cmdDelEV = new OleDbCommand("DELETE FROM tbl_Exemp_FV_Detail WHERE (Exemp_FVD_ID = " + i + ")", conDb.con);

                cmdDelEV.ExecuteNonQuery();
                conDb.con.Close();


                exemptFeeDetailGridViewLoad();
                feeTotals();
                PaidFeeGridViewLoad();
                UnpaidFeeGridViewLoad();
            }
            catch { 
                
                MessageBox.Show("Master Voucher Once Created, can not be deleted.....Press OK to continue...", "No Voucher Found", MessageBoxButtons.OK, MessageBoxIcon.Information); 
            }
        }

        private void bindingNavigatorMoveFirstItem1_Click(object sender, EventArgs e)
        {
            exemptFeeDetailGridViewLoad();
        }

        private void bindingNavigatorMovePreviousItem1_Click(object sender, EventArgs e)
        {
            exemptFeeDetailGridViewLoad();
        }

        private void bindingNavigatorMoveNextItem1_Click(object sender, EventArgs e)
        {
            exemptFeeDetailGridViewLoad();
        }

        private void bindingNavigatorMoveLastItem1_Click(object sender, EventArgs e)
        {
            exemptFeeDetailGridViewLoad();
        }

        private void btn_AddNewFeeVoucher_Click(object sender, EventArgs e)
        {
            btn_AddNewFeeVoucher.Enabled = false;
            btnAddFee.Enabled = true;

            DateTime dt = DateTime.Now;
            string datetimestring;
            datetimestring = string.Format("{0:MMM-dd-yyyy}", dt);

            voucher_DateTextBox.Text = datetimestring;
            //std_Mov_IDTextBox.Text = st_Mov_IDLabel1.Text;
            //Insert in FeeVoucher Master Table in Database
            this.tbl_Fee_Voucher_MasterTableAdapter.Insert(DateTime.Today.Date, Convert.ToInt32(st_Mov_IDLabel1.Text));
            //this.tbl_Fee_Voucher_MasterTableAdapter.FillBy(this.schoolDbDataSet.tbl_Fee_Voucher_Master, Convert.ToInt32(st_Mov_IDLabel1.Text));
            maxFeeVoucher();

            this.tbl_Fee_Voucher_MasterTableAdapter.FillBy(this.schoolDbDataSet.tbl_Fee_Voucher_Master, Convert.ToInt32(st_Mov_IDLabel1.Text));
            this.tbl_Fee_Voucher_MasterBindingSource.MoveLast();
            //this.tbl_Fee_Voucher_MasterBindingSource.ResetCurrentItem();
            ////this.tbl_Fee_Voucher_MasterBindingNavigator.PositionItem = this.tbl_Fee_Voucher_MasterBindingNavigator.CountItem;
            //this .tbl_Fee_Voucher_MasterBindingSource .Position = this.tbl_Fee_Voucher_MasterBindingSource.Count;
            //Check Record Navagiation Properly Operation.
            //this.Validate();
            //this.tbl_Fee_Voucher_MasterBindingSource.EndEdit();
            //this.tbl_Fee_Voucher_MasterTableAdapter.Update(this.schoolDbDataSet.tbl_Fee_Voucher_Master);

        
            dgvFeeDetailCurrentVoucher.DataSource = "";
            bindingNavigatorAddNewItem.Enabled = false;
            btnAddFee.Enabled = true;
        }

        private void btn_DeleteVoucher_Click(object sender, EventArgs e)
        {
            btn_DeleteVoucher.Enabled = false ;
            btnAddFee.Enabled = true;
            try
            {
                int i = Convert.ToInt32(dgvFeeDetailCurrentVoucher.SelectedCells[0].Value);
                //if (i != 0)
                //{
                    conDb.con.Open();
                    OleDbCommand cmdDel = new OleDbCommand("DELETE FROM tbl_Fee_Voucher_Detail WHERE (Fee_Voucher_Detail_ID = " + i + ")", conDb.con);
                    cmdDel.ExecuteNonQuery();
                    conDb.con.Close();
                    feeDetailGridViewLoad();
                    feeTotals();
                    PaidFeeGridViewLoad();
                    UnpaidFeeGridViewLoad();
                //}
                //else { MessageBox.Show("No Voucher Found..... Press OK to continue...", "No Voucher Found", MessageBoxButtons.OK, MessageBoxIcon.Information); }
            }
            catch { 
                
                MessageBox.Show("Master Voucher Once Created, can not be deleted.....Press OK to continue...", "No Voucher Found", MessageBoxButtons.OK, MessageBoxIcon.Information); }
            }

       

        private void tabControl_GeneralInfo_Selected(object sender, TabControlEventArgs e)
        {
            
            if (tabControl_GeneralInfo.SelectedIndex == 1)

            {
               
               loadExemptFeeTab();
            }
           else  if (tabControl_GeneralInfo.SelectedIndex == 0)
            {
                 loadFeeVoucherTab();
                
            }
        }

        private void btn_Print_Exempt_Voucher_Click(object sender, EventArgs e)
        {
            try{
            CrystalReport_Fee_Voucher_Exemption crFVEx = new CrystalReport_Fee_Voucher_Exemption();
            crFVEx.Load("C://SchoolSoft//GeneralSchool//GeneralSchool//CrystalReport_Fee_Voucher_Exemption.rpt");
            crystalReportViewer_VoucherReport.ReportSource = crFVEx;
            crystalReportViewer_VoucherReport.DisplayToolbar = true;
            crystalReportViewer_VoucherReport.Zoom(80);
            //crystalReportViewer_VoucherReport.Right;
            crFVEx.SetParameterValue("schoolName", conDb._schoolName);
            crFVEx.SetParameterValue("addressSchool", conDb._address);
            crFVEx.SetParameterValue("phoneSchool", conDb._phone);
            string compNamAdd = conDb._companyName + " URL: " + conDb._website + " Email: " + conDb._email;
            crFVEx.SetParameterValue("_companyNameAddress", compNamAdd);

            int x = int.Parse(exemp_FVM_IDTextBox.Text);
            crFVEx.SetParameterValue("FV_Exemp_No", x);

            ConnectionInfo connectionInfo = new ConnectionInfo();
            connectionInfo.Password = "30615aorangikhi75800";
            SetDBLogonForReport(connectionInfo);


            tabControl_GeneralInfo.SelectTab(2);
        }
        catch (Exception)
        {
            MessageBox.Show("Fee Voucher Not Found, First Create Voucher... ", "Voucher Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //MessageBox.Show(Convert.ToString(Ex));
        }
        }

        private void tabPageFeeExemption_Click(object sender, EventArgs e)
        {
            //loadExemptFeeTab();
        }

        private void btn_FeePaidHistory_Click(object sender, EventArgs e)
        {
              try{
                  CR_Fee_Paid_History crFPH = new CR_Fee_Paid_History ();
            crFPH.Load("C://SchoolSoft//GeneralSchool//GeneralSchool//CR_Fee_Paid_History.rpt");
            crystalReportViewer_VoucherReport.ReportSource = crFPH;
            crystalReportViewer_VoucherReport.DisplayToolbar = true;
            crystalReportViewer_VoucherReport.Zoom(80);
            //crystalReportViewer_VoucherReport.Right;
            crFPH.SetParameterValue("schoolName", conDb._schoolName);
            crFPH.SetParameterValue("addressSchool", conDb._address);
            crFPH.SetParameterValue("phoneSchool", conDb._phone);
            string compNamAdd = conDb._companyName + " URL: " + conDb._website + " Email: " + conDb._email;
            crFPH.SetParameterValue("_companyNameAddress", compNamAdd);

                  int x = int.Parse(std_Mov_IDTextBox.Text);
            crFPH.SetParameterValue("Mov_ID", x);

            ConnectionInfo connectionInfo = new ConnectionInfo();
            connectionInfo.Password = "30615aorangikhi75800";
            SetDBLogonForReport(connectionInfo);


            tabControl_GeneralInfo.SelectTab(2);
        }
        catch (Exception)
        {
            MessageBox.Show("Fee Voucher Not Found, First Create Voucher... ", "Voucher Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //MessageBox.Show(Convert.ToString(Ex));
        }

        }

        private void SetDBLogonForReport(ConnectionInfo connectionInfo)
        {
            TableLogOnInfos tableLogOnInfos = crystalReportViewer_VoucherReport.LogOnInfo;
            foreach (TableLogOnInfo tableLogOnInfo in tableLogOnInfos)
            {
                tableLogOnInfo.ConnectionInfo = connectionInfo;
            }
        }

        private void btn_ExemptFeeHistory_Click(object sender, EventArgs e)
        {
            try
            {
                CR_Exempt_Fee_History crEFH = new CR_Exempt_Fee_History();
                crEFH.Load("C://SchoolSoft//GeneralSchool//GeneralSchool//CR_Exempt_Fee_History.rpt");
                crystalReportViewer_VoucherReport.ReportSource = crEFH;
                crystalReportViewer_VoucherReport.DisplayToolbar = true;
                crystalReportViewer_VoucherReport.Zoom(80);
                //crystalReportViewer_VoucherReport.Right;
                crEFH.SetParameterValue("schoolName", conDb._schoolName);
                crEFH.SetParameterValue("addressSchool", conDb._address);
                crEFH.SetParameterValue("phoneSchool", conDb._phone);
                string compNamAdd = conDb._companyName + " URL: " + conDb._website + " Email: " + conDb._email;
                crEFH.SetParameterValue("_companyNameAddress", compNamAdd);
    
                int x = int.Parse(std_Mov_IDTextBox1.Text);
                crEFH.SetParameterValue("MovID", x);

                ConnectionInfo connectionInfo = new ConnectionInfo();
                connectionInfo.Password = "30615aorangikhi75800";
                SetDBLogonForReport(connectionInfo);

                tabControl_GeneralInfo.SelectTab(2);
            }
            catch (Exception)
            {
                MessageBox.Show("Fee Voucher Not Found, First Create Voucher... ", "Voucher Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //MessageBox.Show(Convert.ToString(Ex));
            }
        }

      

       









    }
}














/*
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 *  //DataGridView dgvView = dgvUnpaidFeeVoucher;
                ////DataGridView dgvVoucherDetail = tbl_Fee_Voucher_DetailDataGridView;

                ////if (Convert.ToBoolean(dgvViewRow.Cells[0].Value) == true)
                //if (Convert.ToBoolean(dgvUnpaidFeeVoucher.SelectedCells[0].Value) == true)
                //{
                
                //foreach (DataGridViewRow dgvViewRow in dgvView.Rows)
                //{
                    
//if (Convert.ToBoolean(dgvViewRow.Cells[0].Value) == false)
//{
//    MessageBox.Show("Select at Least One Fee ", "Select One Row", MessageBoxButtons.OK, MessageBoxIcon.Information);
//}
//else   
//for (int i = 1; i <= dgvView.SelectedCells.Count; i++)
//for (int i = 1; (Convert.ToBoolean(dgvViewRow.Cells[0].Value) == true); i++)
               
                //int fee_Voucher_ID;
                // fee_Voucher_ID = Convert.ToInt32(fee_Voucher_IDTextBox.Text);
                // int fee_Define_Detail_ID;
                //fee_Define_Detail_ID = Convert.ToInt32(dgvUnpaidFeeVoucher.SelectedCells[1].Value);
                // this.tbl_Fee_Voucher_DetailTableAdapter.Insert(fee_Voucher_ID, fee_Define_Detail_ID);


            //    } // foreach 
            //}
            //else
            //{

            //    MessageBox.Show("Select at least One Row... ", "Select Row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    btnAddFee.Enabled = true;
            //    //break;
            //}
                
                //this.tbl_Fee_Voucher_DetailTableAdapter.Fill(this.schoolDbDataSet.tbl_Fee_Voucher_Detail);
                //feeDetailGridViewLoad();
                //feeTotals();
                //bindingNavigatorAddNewItem.Enabled = false;
                //tbl_Fee_Voucher_MasterBindingNavigatorSaveItem.Enabled = true;


 * 
 * 
 *  private void showValues()
        {
            try
            {
              
                conDb.con.Open();
                // Show Session Description
                OleDbCommand cmd2 = new OleDbCommand("Select Session_Desc from tbl_Session Where Session_ID= " +Convert .ToInt32 ( label_Session_Id.Text) + "", conDb.con);
                OleDbDataReader reader2 = cmd2.ExecuteReader();
                while (reader2.Read())
                {
                    label_Session_Desc.Text = reader2["Session_Desc"].ToString();

                }

                reader2.Close();

                conDb.con.Close();
            }
            catch (Exception Ex)
            { MessageBox.Show(Convert.ToString(Ex)); }
        }
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * Insert New Records Using TableAdapters
 * 
 * TableAdapters provide different ways to insert new records into a database, depending on the requirements 
 * of your application.

If your application uses datasets to store data, then you can simply add new records to the desired DataTable 
 * in the dataset, and then call the TableAdapter.Update method. The TableAdapter.Update method takes any 
 * changes in the DataTable and sends those changes to the database (including modified and deleted records).

 * // Create a new row.
NorthwindDataSet.RegionRow newRegionRow;
newRegionRow = northwindDataSet.Region.NewRegionRow();
newRegionRow.RegionID = 5;
newRegionRow.RegionDescription = "NorthWestern";

// Add the row to the Region table
this.northwindDataSet.Region.Rows.Add(newRegionRow);

// Save the new row to the database
this.regionTableAdapter.Update(this.northwindDataSet.Region);


 * 
 * 
 * DIRECTLY INSERT IN TO DATABASE
 * 
 * To insert new records into a database using the TableAdapter.Insert method
 * If your application uses objects to store the data in your application, you can use the TableAdapter.
 * Insert method to create new rows directly in the database. The Insert method accepts the individual 
 * values for each column as parameters. Calling the method inserts a new record into the database with 
 * the parameter values passed in.

The following procedure uses the Northwind database Region table as an example.

 * NorthwindDataSetTableAdapters.RegionTableAdapter regionTableAdapter = 
    new NorthwindDataSetTableAdapters.RegionTableAdapter();

regionTableAdapter.Insert(5, "NorthWestern");


 * 
 * Insert New Records Using Command Objects
 * The following example inserts new records directly into a database using command objects. For more 
 * information on using command objects to execute commands and stored procedures
 * 
 * System.Data.SqlClient.SqlConnection sqlConnection1 = 
    new System.Data.SqlClient.SqlConnection("YOUR CONNECTION STRING");

System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
cmd.CommandType = System.Data.CommandType.Text;
cmd.CommandText = "INSERT Region (RegionID, RegionDescription) VALUES (5, 'NorthWestern')";
cmd.Connection = sqlConnection1;

sqlConnection1.Open();
cmd.ExecuteNonQuery();
sqlConnection1.Close();


 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * Retrieving Data Using a DataReader (ADO.NET)4.0
 * 
 * SqlCommand command = new SqlCommand(
          "SELECT CategoryID, CategoryName FROM Categories;",
          connection);
        connection.Open();

        SqlDataReader reader = command.ExecuteReader();

        if (reader.HasRows)
        {
            while (reader.Read())
            {
                Console.WriteLine("{0}\t{1}", reader.GetInt32(0),
                    reader.GetString(1));
            }
        }
        else
        {
            Console.WriteLine("No rows found.");
        }
        reader.Close();

 * 
 * 
 * 
 * 
 * 
 * Pass parameter to OleDbCommand
 * 
 * String connect = "Provider=Microsoft.JET.OLEDB.4.0;data source=.\\Employee.mdb";
   OleDbConnection con = new OleDbConnection(connect);
   con.Open();  
   Console.WriteLine("Made the connection to the database");

   OleDbCommand cmd1 = con.CreateCommand();
   cmd1.CommandText = "SELECT ID FROM Employee "
                    + "WHERE id BETWEEN ? AND ?";
   OleDbParameter p1 = new OleDbParameter();
   OleDbParameter p2 = new OleDbParameter();
   cmd1.Parameters.Add(p1);
   cmd1.Parameters.Add(p2);
   p1.Value = "01";
   p2.Value = "03";
   OleDbDataReader reader = cmd1.ExecuteReader();
   while(reader.Read()) 
     Console.WriteLine("{0}", reader.GetInt32(0));
   reader.Close();
   con.Close
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * Bind DataSet to DataGrid
 * 
 *  string connString = "server=(local)\\SQLEXPRESS;database=MyDatabase;Integrated Security=SSPI";

         string sql = @"select * from employee";

         SqlConnection conn = new SqlConnection(connString);
         SqlDataAdapter da = new SqlDataAdapter(sql, conn);
         DataSet ds = new DataSet();
         da.Fill(ds, "customers");

         // Bind the data table to the data grid
         dataGrid1.SetDataBinding(ds, "customers");

 * 
 * 
 * 
 * 
 * 
 * 
 * 
            //object returnValue2;
            //returnValue2 = cmd2.ExecuteScalar();

            //cmb_CurrentSession.Text = Convert.ToString(returnValue2);
            //conDb.con.Close();SqlConnection sqlConnection1 = new SqlConnection("Your Connection String");
SqlCommand cmd = new SqlCommand();
Object returnValue;
cmd.CommandText = "SELECT COUNT(*) FROM Customers";
cmd.CommandType = CommandType.Text;
cmd.Connection = sqlConnection1;
sqlConnection1.Open();
returnValue = cmd.ExecuteScalar();
sqlConnection1.Close();
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 string Con = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\SchoolSoft\GeneralSchool\GeneralSchool\Database\SchoolDb.mdb";
            
            //Get Data from tblClass
            string SQL = "Select * from tbl_Class";
            // Pass connection string to the OledbConnection object
            OleDbConnection OledbConn = new OleDbConnection(Con);
            OleDbDataAdapter da = new OleDbDataAdapter(SQL, Con);

            DataTable dt = new DataTable();
            da.Fill(dt);
            bindingSource1.DataSource = dt;
            //dataGridView1.AutoResizeColumns(
            //DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader);
            dataGridView1.DataSource = bindingSource1;

            //dataGridView1.bind
            //DataSet ds = new DataSet();
            //Fill the DataSet with data
            //da.Fill(ds, "tbl_Class");

            // Bind whole table to the Gridview control
            //textBox1.DataBindings.Add("Text", ds, "tbl_Class.Class_ID");
            //dataGridView1.DataBindings.Add("Text", ds, "tbl_Class");
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * // Used Code as Junk
 * 
 *  //conDb.con.Close();

           ////Get Data from tblClass
           //string SQL = "Select * from tbl_Class Where Class_ID='" + label_Session_ID .Text     + "' ";
           //// Pass connection string to the OledbConnection object

           //OleDbDataAdapter da = new OleDbDataAdapter(SQL, conDb.con);

           //DataTable dt = new DataTable();
           ////da.Fill(dt);

           ////cmb_CurrentSession.DataSource = dt;
           //cmb_CurrentSession.Text  = "Class_Desc";
           ////cmb_CurrentSession.s = "Class_ID";
           // //cmb_CurrentSession.SelectedValue= Convert .ToInt32(returnValue);

            // //See Gscholarship 

           //conDb.con.Open();
 * 
 * 
 * 
 * 
 * 
 * 
 * TRANSACTION NOT Support in OLEDB ****************************
 *       private void UpdateFeeVoucherData()
        { 
        //this.Validate();
            this.tbl_Fee_Voucher_MasterBindingSource.EndEdit();
            this.tbl_Fee_Voucher_DetailBindingSource.EndEdit();
            
            //this.tbl_Fee_Voucher_MasterTableAdapter.Update(this.schoolDbDataSet.tbl_Fee_Voucher_Master);
            //this.tbl_Fee_Voucher_DetailTableAdapter.Update(this.schoolDbDataSet.tbl_Fee_Voucher_Detail);
            
            using (System.Transactions.TransactionScope updateTransaction =
            new System.Transactions.TransactionScope())
            {
                //DeleteVoucher_Master();
                //DeleteVoucher_Detail();
                AddNewVoucher_Master();
                AddNewVoucher_Detail();

                updateTransaction.Complete();

                schoolDbDataSet.AcceptChanges();
            }
        }
        
        private void AddNewVoucher_Master()
        {
            SchoolDbDataSet.tbl_Fee_Voucher_MasterDataTable newMasterVoucher;
            newMasterVoucher = (SchoolDbDataSet.tbl_Fee_Voucher_MasterDataTable)
                schoolDbDataSet.tbl_Fee_Voucher_Master.GetChanges(DataRowState.Added);

            //NorthwindDataSet.CustomersDataTable newCustomers;
            //newCustomers = (NorthwindDataSet.CustomersDataTable)
            //    northwindDataSet.Customers.GetChanges(DataRowState.Added);
             
            if (newMasterVoucher  != null)
            {
                try
                {

                    tbl_Fee_Voucher_MasterTableAdapter.Update(newMasterVoucher);
                    //customersTableAdapter.Update(newCustomers);
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(Convert.ToString (ex));
                }
            }
        }

        private void AddNewVoucher_Detail()
        {
            SchoolDbDataSet.tbl_Fee_Voucher_DetailDataTable newDetailVoucher;
            newDetailVoucher = (SchoolDbDataSet.tbl_Fee_Voucher_DetailDataTable)
                schoolDbDataSet.tbl_Fee_Voucher_Detail.GetChanges(DataRowState.Added);

        
            if (newDetailVoucher != null)
            {
                try
                {

                    tbl_Fee_Voucher_DetailTableAdapter.Update(newDetailVoucher);
                    //customersTableAdapter.Update(newCustomers);
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(Convert .ToString (ex));
                }
            }
        }
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
*/