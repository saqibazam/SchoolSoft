using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GeneralSchool
{
    public partial class Form_Session_Progress_Status : Form
    {
        public Form_Session_Progress_Status()
        {
            InitializeComponent();
        }

        private void tbl_Session_Progress_StatusBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tbl_Session_Progress_StatusBindingSource.EndEdit();
            this.tbl_Session_Progress_StatusTableAdapter.Update(this.schoolDbDataSet.tbl_Session_Progress_Status);

        }

        private void Form_Session_Progress_Status_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Session_Progress_Status' table. You can move, or remove it, as needed.
            this.tbl_Session_Progress_StatusTableAdapter.Fill(this.schoolDbDataSet.tbl_Session_Progress_Status);
            tbl_Session_Progress_StatusBindingSource.MoveLast();
            //tbl_Session_Progress_StatusDataGridView.AutoResizeColumns();
        }
    }
}