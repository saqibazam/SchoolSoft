namespace GeneralSchool
{
    partial class Form_Session_Progress_Status
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label session_Progress_IDLabel;
            System.Windows.Forms.Label session_IDLabel;
            System.Windows.Forms.Label session_YearLabel;
            System.Windows.Forms.Label feeClosingCompletedLabel;
            System.Windows.Forms.Label passOutLastClassStudentsLabel;
            System.Windows.Forms.Label moveAllStudentstoNewSessionLabel;
            System.Windows.Forms.Label moveAllSuccessfulStudentsToNewClassLabel;
            System.Windows.Forms.Label assignRollNoToNewClassLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Session_Progress_Status));
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.tbl_Session_Progress_StatusBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_Session_Progress_StatusTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Session_Progress_StatusTableAdapter();
            this.tbl_Session_Progress_StatusBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_Session_Progress_StatusBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.session_Progress_IDTextBox = new System.Windows.Forms.TextBox();
            this.session_IDTextBox = new System.Windows.Forms.TextBox();
            this.session_YearTextBox = new System.Windows.Forms.TextBox();
            this.feeClosingCompletedCheckBox = new System.Windows.Forms.CheckBox();
            this.passOutLastClassStudentsCheckBox = new System.Windows.Forms.CheckBox();
            this.moveAllStudentstoNewSessionCheckBox = new System.Windows.Forms.CheckBox();
            this.moveAllSuccessfulStudentsToNewClassCheckBox = new System.Windows.Forms.CheckBox();
            this.assignRollNoToNewClassCheckBox = new System.Windows.Forms.CheckBox();
            this.tbl_Session_Progress_StatusDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn4 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn5 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            session_Progress_IDLabel = new System.Windows.Forms.Label();
            session_IDLabel = new System.Windows.Forms.Label();
            session_YearLabel = new System.Windows.Forms.Label();
            feeClosingCompletedLabel = new System.Windows.Forms.Label();
            passOutLastClassStudentsLabel = new System.Windows.Forms.Label();
            moveAllStudentstoNewSessionLabel = new System.Windows.Forms.Label();
            moveAllSuccessfulStudentsToNewClassLabel = new System.Windows.Forms.Label();
            assignRollNoToNewClassLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Session_Progress_StatusBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Session_Progress_StatusBindingNavigator)).BeginInit();
            this.tbl_Session_Progress_StatusBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Session_Progress_StatusDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // session_Progress_IDLabel
            // 
            session_Progress_IDLabel.AutoSize = true;
            session_Progress_IDLabel.Location = new System.Drawing.Point(15, 117);
            session_Progress_IDLabel.Name = "session_Progress_IDLabel";
            session_Progress_IDLabel.Size = new System.Drawing.Size(105, 13);
            session_Progress_IDLabel.TabIndex = 1;
            session_Progress_IDLabel.Text = "Session Progress ID:";
            // 
            // session_IDLabel
            // 
            session_IDLabel.AutoSize = true;
            session_IDLabel.Location = new System.Drawing.Point(15, 143);
            session_IDLabel.Name = "session_IDLabel";
            session_IDLabel.Size = new System.Drawing.Size(61, 13);
            session_IDLabel.TabIndex = 3;
            session_IDLabel.Text = "Session ID:";
            // 
            // session_YearLabel
            // 
            session_YearLabel.AutoSize = true;
            session_YearLabel.Location = new System.Drawing.Point(15, 169);
            session_YearLabel.Name = "session_YearLabel";
            session_YearLabel.Size = new System.Drawing.Size(72, 13);
            session_YearLabel.TabIndex = 5;
            session_YearLabel.Text = "Session Year:";
            // 
            // feeClosingCompletedLabel
            // 
            feeClosingCompletedLabel.AutoSize = true;
            feeClosingCompletedLabel.Location = new System.Drawing.Point(15, 197);
            feeClosingCompletedLabel.Name = "feeClosingCompletedLabel";
            feeClosingCompletedLabel.Size = new System.Drawing.Size(118, 13);
            feeClosingCompletedLabel.TabIndex = 7;
            feeClosingCompletedLabel.Text = "Fee Closing Completed:";
            // 
            // passOutLastClassStudentsLabel
            // 
            passOutLastClassStudentsLabel.AutoSize = true;
            passOutLastClassStudentsLabel.Location = new System.Drawing.Point(15, 227);
            passOutLastClassStudentsLabel.Name = "passOutLastClassStudentsLabel";
            passOutLastClassStudentsLabel.Size = new System.Drawing.Size(149, 13);
            passOutLastClassStudentsLabel.TabIndex = 9;
            passOutLastClassStudentsLabel.Text = "Pass Out Last Class Students:";
            // 
            // moveAllStudentstoNewSessionLabel
            // 
            moveAllStudentstoNewSessionLabel.AutoSize = true;
            moveAllStudentstoNewSessionLabel.Location = new System.Drawing.Point(15, 257);
            moveAllStudentstoNewSessionLabel.Name = "moveAllStudentstoNewSessionLabel";
            moveAllStudentstoNewSessionLabel.Size = new System.Drawing.Size(170, 13);
            moveAllStudentstoNewSessionLabel.TabIndex = 11;
            moveAllStudentstoNewSessionLabel.Text = "Move All Studentsto New Session:";
            // 
            // moveAllSuccessfulStudentsToNewClassLabel
            // 
            moveAllSuccessfulStudentsToNewClassLabel.AutoSize = true;
            moveAllSuccessfulStudentsToNewClassLabel.Location = new System.Drawing.Point(15, 287);
            moveAllSuccessfulStudentsToNewClassLabel.Name = "moveAllSuccessfulStudentsToNewClassLabel";
            moveAllSuccessfulStudentsToNewClassLabel.Size = new System.Drawing.Size(220, 13);
            moveAllSuccessfulStudentsToNewClassLabel.TabIndex = 13;
            moveAllSuccessfulStudentsToNewClassLabel.Text = "Move All Successful Students To New Class:";
            // 
            // assignRollNoToNewClassLabel
            // 
            assignRollNoToNewClassLabel.AutoSize = true;
            assignRollNoToNewClassLabel.Location = new System.Drawing.Point(15, 317);
            assignRollNoToNewClassLabel.Name = "assignRollNoToNewClassLabel";
            assignRollNoToNewClassLabel.Size = new System.Drawing.Size(148, 13);
            assignRollNoToNewClassLabel.TabIndex = 15;
            assignRollNoToNewClassLabel.Text = "Assign Roll No To New Class:";
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_Session_Progress_StatusBindingSource
            // 
            this.tbl_Session_Progress_StatusBindingSource.DataMember = "tbl_Session_Progress_Status";
            this.tbl_Session_Progress_StatusBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tbl_Session_Progress_StatusTableAdapter
            // 
            this.tbl_Session_Progress_StatusTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_Session_Progress_StatusBindingNavigator
            // 
            this.tbl_Session_Progress_StatusBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_Session_Progress_StatusBindingNavigator.BindingSource = this.tbl_Session_Progress_StatusBindingSource;
            this.tbl_Session_Progress_StatusBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_Session_Progress_StatusBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_Session_Progress_StatusBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.tbl_Session_Progress_StatusBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_Session_Progress_StatusBindingNavigatorSaveItem});
            this.tbl_Session_Progress_StatusBindingNavigator.Location = new System.Drawing.Point(18, 351);
            this.tbl_Session_Progress_StatusBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_Session_Progress_StatusBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_Session_Progress_StatusBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_Session_Progress_StatusBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_Session_Progress_StatusBindingNavigator.Name = "tbl_Session_Progress_StatusBindingNavigator";
            this.tbl_Session_Progress_StatusBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_Session_Progress_StatusBindingNavigator.Size = new System.Drawing.Size(279, 25);
            this.tbl_Session_Progress_StatusBindingNavigator.TabIndex = 0;
            this.tbl_Session_Progress_StatusBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.ReadOnly = true;
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_Session_Progress_StatusBindingNavigatorSaveItem
            // 
            this.tbl_Session_Progress_StatusBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbl_Session_Progress_StatusBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_Session_Progress_StatusBindingNavigatorSaveItem.Image")));
            this.tbl_Session_Progress_StatusBindingNavigatorSaveItem.Name = "tbl_Session_Progress_StatusBindingNavigatorSaveItem";
            this.tbl_Session_Progress_StatusBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tbl_Session_Progress_StatusBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_Session_Progress_StatusBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_Session_Progress_StatusBindingNavigatorSaveItem_Click);
            // 
            // session_Progress_IDTextBox
            // 
            this.session_Progress_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Session_Progress_StatusBindingSource, "Session_Progress_ID", true));
            this.session_Progress_IDTextBox.Location = new System.Drawing.Point(241, 114);
            this.session_Progress_IDTextBox.Name = "session_Progress_IDTextBox";
            this.session_Progress_IDTextBox.Size = new System.Drawing.Size(104, 20);
            this.session_Progress_IDTextBox.TabIndex = 2;
            // 
            // session_IDTextBox
            // 
            this.session_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Session_Progress_StatusBindingSource, "Session_ID", true));
            this.session_IDTextBox.Location = new System.Drawing.Point(241, 140);
            this.session_IDTextBox.Name = "session_IDTextBox";
            this.session_IDTextBox.Size = new System.Drawing.Size(104, 20);
            this.session_IDTextBox.TabIndex = 4;
            // 
            // session_YearTextBox
            // 
            this.session_YearTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Session_Progress_StatusBindingSource, "Session_Year", true));
            this.session_YearTextBox.Location = new System.Drawing.Point(241, 166);
            this.session_YearTextBox.Name = "session_YearTextBox";
            this.session_YearTextBox.Size = new System.Drawing.Size(104, 20);
            this.session_YearTextBox.TabIndex = 6;
            // 
            // feeClosingCompletedCheckBox
            // 
            this.feeClosingCompletedCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.tbl_Session_Progress_StatusBindingSource, "FeeClosingCompleted", true));
            this.feeClosingCompletedCheckBox.Location = new System.Drawing.Point(241, 192);
            this.feeClosingCompletedCheckBox.Name = "feeClosingCompletedCheckBox";
            this.feeClosingCompletedCheckBox.Size = new System.Drawing.Size(104, 24);
            this.feeClosingCompletedCheckBox.TabIndex = 8;
            // 
            // passOutLastClassStudentsCheckBox
            // 
            this.passOutLastClassStudentsCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.tbl_Session_Progress_StatusBindingSource, "PassOutLastClassStudents", true));
            this.passOutLastClassStudentsCheckBox.Location = new System.Drawing.Point(241, 222);
            this.passOutLastClassStudentsCheckBox.Name = "passOutLastClassStudentsCheckBox";
            this.passOutLastClassStudentsCheckBox.Size = new System.Drawing.Size(104, 24);
            this.passOutLastClassStudentsCheckBox.TabIndex = 10;
            // 
            // moveAllStudentstoNewSessionCheckBox
            // 
            this.moveAllStudentstoNewSessionCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.tbl_Session_Progress_StatusBindingSource, "MoveAllStudentstoNewSession", true));
            this.moveAllStudentstoNewSessionCheckBox.Location = new System.Drawing.Point(241, 252);
            this.moveAllStudentstoNewSessionCheckBox.Name = "moveAllStudentstoNewSessionCheckBox";
            this.moveAllStudentstoNewSessionCheckBox.Size = new System.Drawing.Size(104, 24);
            this.moveAllStudentstoNewSessionCheckBox.TabIndex = 12;
            // 
            // moveAllSuccessfulStudentsToNewClassCheckBox
            // 
            this.moveAllSuccessfulStudentsToNewClassCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.tbl_Session_Progress_StatusBindingSource, "MoveAllSuccessfulStudentsToNewClass", true));
            this.moveAllSuccessfulStudentsToNewClassCheckBox.Location = new System.Drawing.Point(241, 282);
            this.moveAllSuccessfulStudentsToNewClassCheckBox.Name = "moveAllSuccessfulStudentsToNewClassCheckBox";
            this.moveAllSuccessfulStudentsToNewClassCheckBox.Size = new System.Drawing.Size(104, 24);
            this.moveAllSuccessfulStudentsToNewClassCheckBox.TabIndex = 14;
            // 
            // assignRollNoToNewClassCheckBox
            // 
            this.assignRollNoToNewClassCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.tbl_Session_Progress_StatusBindingSource, "AssignRollNoToNewClass", true));
            this.assignRollNoToNewClassCheckBox.Location = new System.Drawing.Point(241, 312);
            this.assignRollNoToNewClassCheckBox.Name = "assignRollNoToNewClassCheckBox";
            this.assignRollNoToNewClassCheckBox.Size = new System.Drawing.Size(104, 24);
            this.assignRollNoToNewClassCheckBox.TabIndex = 16;
            // 
            // tbl_Session_Progress_StatusDataGridView
            // 
            this.tbl_Session_Progress_StatusDataGridView.AllowUserToAddRows = false;
            this.tbl_Session_Progress_StatusDataGridView.AllowUserToDeleteRows = false;
            this.tbl_Session_Progress_StatusDataGridView.AutoGenerateColumns = false;
            this.tbl_Session_Progress_StatusDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tbl_Session_Progress_StatusDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewCheckBoxColumn2,
            this.dataGridViewCheckBoxColumn3,
            this.dataGridViewCheckBoxColumn4,
            this.dataGridViewCheckBoxColumn5});
            this.tbl_Session_Progress_StatusDataGridView.DataSource = this.tbl_Session_Progress_StatusBindingSource;
            this.tbl_Session_Progress_StatusDataGridView.Location = new System.Drawing.Point(18, 379);
            this.tbl_Session_Progress_StatusDataGridView.Name = "tbl_Session_Progress_StatusDataGridView";
            this.tbl_Session_Progress_StatusDataGridView.Size = new System.Drawing.Size(853, 220);
            this.tbl_Session_Progress_StatusDataGridView.TabIndex = 17;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Session_Progress_ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Session_ID";
            this.dataGridViewTextBoxColumn2.HeaderText = "Session ID";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Session_Year";
            this.dataGridViewTextBoxColumn3.HeaderText = "Session Year";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "FeeClosingCompleted";
            this.dataGridViewCheckBoxColumn1.HeaderText = "Fee Closing Completed";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.DataPropertyName = "PassOutLastClassStudents";
            this.dataGridViewCheckBoxColumn2.HeaderText = "Pass Out Last Class Students";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            // 
            // dataGridViewCheckBoxColumn3
            // 
            this.dataGridViewCheckBoxColumn3.DataPropertyName = "MoveAllStudentstoNewSession";
            this.dataGridViewCheckBoxColumn3.HeaderText = "Move All Students to New Session";
            this.dataGridViewCheckBoxColumn3.Name = "dataGridViewCheckBoxColumn3";
            // 
            // dataGridViewCheckBoxColumn4
            // 
            this.dataGridViewCheckBoxColumn4.DataPropertyName = "MoveAllSuccessfulStudentsToNewClass";
            this.dataGridViewCheckBoxColumn4.HeaderText = "Move All Successful Students To New Class";
            this.dataGridViewCheckBoxColumn4.Name = "dataGridViewCheckBoxColumn4";
            // 
            // dataGridViewCheckBoxColumn5
            // 
            this.dataGridViewCheckBoxColumn5.DataPropertyName = "AssignRollNoToNewClass";
            this.dataGridViewCheckBoxColumn5.HeaderText = "Assign Roll No To New Class";
            this.dataGridViewCheckBoxColumn5.Name = "dataGridViewCheckBoxColumn5";
            // 
            // Form_Session_Progress_Status
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(891, 664);
            this.Controls.Add(this.tbl_Session_Progress_StatusDataGridView);
            this.Controls.Add(session_Progress_IDLabel);
            this.Controls.Add(this.session_Progress_IDTextBox);
            this.Controls.Add(session_IDLabel);
            this.Controls.Add(this.session_IDTextBox);
            this.Controls.Add(session_YearLabel);
            this.Controls.Add(this.session_YearTextBox);
            this.Controls.Add(feeClosingCompletedLabel);
            this.Controls.Add(this.feeClosingCompletedCheckBox);
            this.Controls.Add(passOutLastClassStudentsLabel);
            this.Controls.Add(this.passOutLastClassStudentsCheckBox);
            this.Controls.Add(moveAllStudentstoNewSessionLabel);
            this.Controls.Add(this.moveAllStudentstoNewSessionCheckBox);
            this.Controls.Add(moveAllSuccessfulStudentsToNewClassLabel);
            this.Controls.Add(this.moveAllSuccessfulStudentsToNewClassCheckBox);
            this.Controls.Add(assignRollNoToNewClassLabel);
            this.Controls.Add(this.assignRollNoToNewClassCheckBox);
            this.Controls.Add(this.tbl_Session_Progress_StatusBindingNavigator);
            this.Name = "Form_Session_Progress_Status";
            this.Text = "Form_Session_Progress_Status";
            this.Load += new System.EventHandler(this.Form_Session_Progress_Status_Load);
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Session_Progress_StatusBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Session_Progress_StatusBindingNavigator)).EndInit();
            this.tbl_Session_Progress_StatusBindingNavigator.ResumeLayout(false);
            this.tbl_Session_Progress_StatusBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Session_Progress_StatusDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tbl_Session_Progress_StatusBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Session_Progress_StatusTableAdapter tbl_Session_Progress_StatusTableAdapter;
        private System.Windows.Forms.BindingNavigator tbl_Session_Progress_StatusBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_Session_Progress_StatusBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox session_Progress_IDTextBox;
        private System.Windows.Forms.TextBox session_IDTextBox;
        private System.Windows.Forms.TextBox session_YearTextBox;
        private System.Windows.Forms.CheckBox feeClosingCompletedCheckBox;
        private System.Windows.Forms.CheckBox passOutLastClassStudentsCheckBox;
        private System.Windows.Forms.CheckBox moveAllStudentstoNewSessionCheckBox;
        private System.Windows.Forms.CheckBox moveAllSuccessfulStudentsToNewClassCheckBox;
        private System.Windows.Forms.CheckBox assignRollNoToNewClassCheckBox;
        private System.Windows.Forms.DataGridView tbl_Session_Progress_StatusDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn4;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn5;
    }
}