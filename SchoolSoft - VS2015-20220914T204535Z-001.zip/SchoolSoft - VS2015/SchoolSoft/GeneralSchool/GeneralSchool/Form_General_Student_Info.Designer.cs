namespace GeneralSchool
{
    partial class Form_General_Student_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label mother_NameLabel;
            System.Windows.Forms.Label religionLabel;
            System.Windows.Forms.Label genderLabel;
            System.Windows.Forms.Label st_Mov_IDLabel;
            System.Windows.Forms.Label gR_NoLabel;
            System.Windows.Forms.Label session_IDLabel;
            System.Windows.Forms.Label result_IDLabel;
            System.Windows.Forms.Label rollLabel;
            System.Windows.Forms.Label label13;
            System.Windows.Forms.Label fee_Voucher_IDLabel;
            System.Windows.Forms.Label class_IDLabel;
            System.Windows.Forms.Label exemp_FVM_IDLabel;
            System.Windows.Forms.Label std_Mov_IDLabel1;
            System.Windows.Forms.Label voucher_DateLabel1;
            System.Windows.Forms.Label exemp_FV_DateLabel1;
            System.Windows.Forms.Label percentageLabel;
            System.Windows.Forms.Label std_Mov_IDLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_General_Student_Info));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl_GeneralInfo = new System.Windows.Forms.TabControl();
            this.tabPageFeeVoucher = new System.Windows.Forms.TabPage();
            this.btn_FeePaidHistory = new System.Windows.Forms.Button();
            this.btn_DeleteVoucher = new System.Windows.Forms.Button();
            this.btn_AddNewFeeVoucher = new System.Windows.Forms.Button();
            this.voucher_DateTextBox = new System.Windows.Forms.TextBox();
            this.tbl_Fee_Voucher_MasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.btnPrintVoucher = new System.Windows.Forms.Button();
            this.dgvFeeDetailCurrentVoucher = new System.Windows.Forms.DataGridView();
            this.tbl_Fee_Voucher_MasterBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_Fee_Voucher_MasterBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.fee_Voucher_IDTextBox = new System.Windows.Forms.TextBox();
            this.btnAddFee = new System.Windows.Forms.Button();
            this.std_Mov_IDTextBox = new System.Windows.Forms.TextBox();
            this.tabPageFeeExemption = new System.Windows.Forms.TabPage();
            this.btn_ExemptFeeHistory = new System.Windows.Forms.Button();
            this.tbl_Exemp_FV_Master_bindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem1 = new System.Windows.Forms.ToolStripButton();
            this.tbl_Exemp_FV_MasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigatorCountItem1 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem1 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.exemp_FV_DateTextBox = new System.Windows.Forms.TextBox();
            this.dgvExemptFeeDetailVoucher = new System.Windows.Forms.DataGridView();
            this.btn_Print_Exempt_Voucher = new System.Windows.Forms.Button();
            this.btn_Add_FeeForExemption = new System.Windows.Forms.Button();
            this.btn_Delete_Exempt_Voucher_Detail = new System.Windows.Forms.Button();
            this.btn_Add_Exempt_Voucher = new System.Windows.Forms.Button();
            this.exemp_FVM_IDTextBox = new System.Windows.Forms.TextBox();
            this.std_Mov_IDTextBox1 = new System.Windows.Forms.TextBox();
            this.tabPage_VoucherReport = new System.Windows.Forms.TabPage();
            this.crystalReportViewer_VoucherReport = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.gR_NoTextBox = new System.Windows.Forms.MaskedTextBox();
            this.label_ClassDetail = new System.Windows.Forms.Label();
            this.mother_QualificationLabel1 = new System.Windows.Forms.Label();
            this.father_QualificationLabel1 = new System.Windows.Forms.Label();
            this.mother_TongueLabel1 = new System.Windows.Forms.Label();
            this.mother_NameLabel1 = new System.Windows.Forms.Label();
            this.religionLabel1 = new System.Windows.Forms.Label();
            this.admission_DateLabel1 = new System.Windows.Forms.Label();
            this.organization_PhoneLabel1 = new System.Windows.Forms.Label();
            this.residence_TelephoneLabel1 = new System.Windows.Forms.Label();
            this.residence_AddressLabel1 = new System.Windows.Forms.Label();
            this.genderLabel1 = new System.Windows.Forms.Label();
            this.father_NameLabel1 = new System.Windows.Forms.Label();
            this.student_NameLabel1 = new System.Windows.Forms.Label();
            this.rollLabel1 = new System.Windows.Forms.Label();
            this.st_Mov_IDLabel1 = new System.Windows.Forms.Label();
            this.birth_DateLabel1 = new System.Windows.Forms.Label();
            this.result_DescLabel1 = new System.Windows.Forms.Label();
            this.session_DescLabel1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label_Session_Id = new System.Windows.Forms.Label();
            this.label_feeBalance = new System.Windows.Forms.Label();
            this.label_feePaid = new System.Windows.Forms.Label();
            this.label_totalFee = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.ClassID_label = new System.Windows.Forms.Label();
            this.dgv_FeePaidHistory = new System.Windows.Forms.DataGridView();
            this.dgvUnpaidFeeVoucher = new System.Windows.Forms.DataGridView();
            this.Tf_lbl_GRNo = new System.Windows.Forms.Label();
            this.tbl_Fee_Voucher_MasterTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Fee_Voucher_MasterTableAdapter();
            this.tbl_Fee_Voucher_DetailTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Fee_Voucher_DetailTableAdapter();
            this.tbl_Exemp_FV_MasterTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Exemp_FV_MasterTableAdapter();
            this.tbl_Exemp_FV_DetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_Exemp_FV_DetailTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Exemp_FV_DetailTableAdapter();
            this.lbl_totalFeeExemption = new System.Windows.Forms.Label();
            this.lbl_Exemption = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.percentageLabel1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tbl_Fee_Voucher_DetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.unpaidFeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.paidHistorybindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.FeeDetailCurrentVoucherBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ExemptFeeDetailVoucherBindingSource = new System.Windows.Forms.BindingSource(this.components);
            mother_NameLabel = new System.Windows.Forms.Label();
            religionLabel = new System.Windows.Forms.Label();
            genderLabel = new System.Windows.Forms.Label();
            st_Mov_IDLabel = new System.Windows.Forms.Label();
            gR_NoLabel = new System.Windows.Forms.Label();
            session_IDLabel = new System.Windows.Forms.Label();
            result_IDLabel = new System.Windows.Forms.Label();
            rollLabel = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            fee_Voucher_IDLabel = new System.Windows.Forms.Label();
            class_IDLabel = new System.Windows.Forms.Label();
            exemp_FVM_IDLabel = new System.Windows.Forms.Label();
            std_Mov_IDLabel1 = new System.Windows.Forms.Label();
            voucher_DateLabel1 = new System.Windows.Forms.Label();
            exemp_FV_DateLabel1 = new System.Windows.Forms.Label();
            percentageLabel = new System.Windows.Forms.Label();
            std_Mov_IDLabel = new System.Windows.Forms.Label();
            this.tabControl_GeneralInfo.SuspendLayout();
            this.tabPageFeeVoucher.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Voucher_MasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeeDetailCurrentVoucher)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Voucher_MasterBindingNavigator)).BeginInit();
            this.tbl_Fee_Voucher_MasterBindingNavigator.SuspendLayout();
            this.tabPageFeeExemption.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Exemp_FV_Master_bindingNavigator)).BeginInit();
            this.tbl_Exemp_FV_Master_bindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Exemp_FV_MasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExemptFeeDetailVoucher)).BeginInit();
            this.tabPage_VoucherReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_FeePaidHistory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUnpaidFeeVoucher)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Exemp_FV_DetailBindingSource)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Voucher_DetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.unpaidFeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paidHistorybindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FeeDetailCurrentVoucherBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ExemptFeeDetailVoucherBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // mother_NameLabel
            // 
            mother_NameLabel.AutoSize = true;
            mother_NameLabel.Location = new System.Drawing.Point(342, 78);
            mother_NameLabel.Name = "mother_NameLabel";
            mother_NameLabel.Size = new System.Drawing.Size(74, 13);
            mother_NameLabel.TabIndex = 139;
            mother_NameLabel.Text = "Mother Name:";
            // 
            // religionLabel
            // 
            religionLabel.AutoSize = true;
            religionLabel.Location = new System.Drawing.Point(342, 105);
            religionLabel.Name = "religionLabel";
            religionLabel.Size = new System.Drawing.Size(45, 13);
            religionLabel.TabIndex = 137;
            religionLabel.Text = "Religion";
            // 
            // genderLabel
            // 
            genderLabel.AutoSize = true;
            genderLabel.Location = new System.Drawing.Point(175, 108);
            genderLabel.Name = "genderLabel";
            genderLabel.Size = new System.Drawing.Size(45, 13);
            genderLabel.TabIndex = 131;
            genderLabel.Text = "Gender:";
            // 
            // st_Mov_IDLabel
            // 
            st_Mov_IDLabel.AutoSize = true;
            st_Mov_IDLabel.Location = new System.Drawing.Point(717, 17);
            st_Mov_IDLabel.Name = "st_Mov_IDLabel";
            st_Mov_IDLabel.Size = new System.Drawing.Size(58, 13);
            st_Mov_IDLabel.TabIndex = 95;
            st_Mov_IDLabel.Text = "St Mov ID:";
            // 
            // gR_NoLabel
            // 
            gR_NoLabel.AutoSize = true;
            gR_NoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            gR_NoLabel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            gR_NoLabel.Location = new System.Drawing.Point(7, 22);
            gR_NoLabel.Name = "gR_NoLabel";
            gR_NoLabel.Size = new System.Drawing.Size(110, 13);
            gR_NoLabel.TabIndex = 96;
            gR_NoLabel.Text = "Enter GR Number:";
            // 
            // session_IDLabel
            // 
            session_IDLabel.AutoSize = true;
            session_IDLabel.Location = new System.Drawing.Point(342, 22);
            session_IDLabel.Name = "session_IDLabel";
            session_IDLabel.Size = new System.Drawing.Size(44, 13);
            session_IDLabel.TabIndex = 98;
            session_IDLabel.Text = "Session";
            // 
            // result_IDLabel
            // 
            result_IDLabel.AutoSize = true;
            result_IDLabel.Location = new System.Drawing.Point(664, 22);
            result_IDLabel.Name = "result_IDLabel";
            result_IDLabel.Size = new System.Drawing.Size(37, 13);
            result_IDLabel.TabIndex = 103;
            result_IDLabel.Text = "Result";
            // 
            // rollLabel
            // 
            rollLabel.AutoSize = true;
            rollLabel.Location = new System.Drawing.Point(261, 23);
            rollLabel.Name = "rollLabel";
            rollLabel.Size = new System.Drawing.Size(25, 13);
            rollLabel.TabIndex = 105;
            rollLabel.Text = "Roll";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new System.Drawing.Point(507, 17);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(80, 13);
            label13.TabIndex = 98;
            label13.Text = "Student GR No";
            // 
            // fee_Voucher_IDLabel
            // 
            fee_Voucher_IDLabel.AutoSize = true;
            fee_Voucher_IDLabel.Location = new System.Drawing.Point(9, 36);
            fee_Voucher_IDLabel.Name = "fee_Voucher_IDLabel";
            fee_Voucher_IDLabel.Size = new System.Drawing.Size(85, 13);
            fee_Voucher_IDLabel.TabIndex = 160;
            fee_Voucher_IDLabel.Text = "Fee Voucher ID:";
            // 
            // class_IDLabel
            // 
            class_IDLabel.AutoSize = true;
            class_IDLabel.Location = new System.Drawing.Point(342, 53);
            class_IDLabel.Name = "class_IDLabel";
            class_IDLabel.Size = new System.Drawing.Size(35, 13);
            class_IDLabel.TabIndex = 101;
            class_IDLabel.Text = "Class:";
            // 
            // exemp_FVM_IDLabel
            // 
            exemp_FVM_IDLabel.AutoSize = true;
            exemp_FVM_IDLabel.Location = new System.Drawing.Point(8, 38);
            exemp_FVM_IDLabel.Name = "exemp_FVM_IDLabel";
            exemp_FVM_IDLabel.Size = new System.Drawing.Size(81, 13);
            exemp_FVM_IDLabel.TabIndex = 0;
            exemp_FVM_IDLabel.Text = "Exemp FVM ID:";
            // 
            // std_Mov_IDLabel1
            // 
            std_Mov_IDLabel1.AutoSize = true;
            std_Mov_IDLabel1.Location = new System.Drawing.Point(239, 134);
            std_Mov_IDLabel1.Name = "std_Mov_IDLabel1";
            std_Mov_IDLabel1.Size = new System.Drawing.Size(64, 13);
            std_Mov_IDLabel1.TabIndex = 4;
            std_Mov_IDLabel1.Text = "Std Mov ID:";
            // 
            // voucher_DateLabel1
            // 
            voucher_DateLabel1.AutoSize = true;
            voucher_DateLabel1.Location = new System.Drawing.Point(149, 36);
            voucher_DateLabel1.Name = "voucher_DateLabel1";
            voucher_DateLabel1.Size = new System.Drawing.Size(76, 13);
            voucher_DateLabel1.TabIndex = 181;
            voucher_DateLabel1.Text = "Voucher Date:";
            // 
            // exemp_FV_DateLabel1
            // 
            exemp_FV_DateLabel1.AutoSize = true;
            exemp_FV_DateLabel1.Location = new System.Drawing.Point(171, 38);
            exemp_FV_DateLabel1.Name = "exemp_FV_DateLabel1";
            exemp_FV_DateLabel1.Size = new System.Drawing.Size(84, 13);
            exemp_FV_DateLabel1.TabIndex = 11;
            exemp_FV_DateLabel1.Text = "Exemp FV Date:";
            // 
            // percentageLabel
            // 
            percentageLabel.AutoSize = true;
            percentageLabel.Location = new System.Drawing.Point(813, 19);
            percentageLabel.Name = "percentageLabel";
            percentageLabel.Size = new System.Drawing.Size(62, 13);
            percentageLabel.TabIndex = 104;
            percentageLabel.Text = "Percentage";
            // 
            // std_Mov_IDLabel
            // 
            std_Mov_IDLabel.AutoSize = true;
            std_Mov_IDLabel.Location = new System.Drawing.Point(222, 137);
            std_Mov_IDLabel.Name = "std_Mov_IDLabel";
            std_Mov_IDLabel.Size = new System.Drawing.Size(64, 13);
            std_Mov_IDLabel.TabIndex = 186;
            std_Mov_IDLabel.Text = "Std Mov ID:";
            // 
            // tabControl_GeneralInfo
            // 
            this.tabControl_GeneralInfo.Controls.Add(this.tabPageFeeVoucher);
            this.tabControl_GeneralInfo.Controls.Add(this.tabPageFeeExemption);
            this.tabControl_GeneralInfo.Controls.Add(this.tabPage_VoucherReport);
            this.tabControl_GeneralInfo.Enabled = false;
            this.tabControl_GeneralInfo.Location = new System.Drawing.Point(9, 223);
            this.tabControl_GeneralInfo.Name = "tabControl_GeneralInfo";
            this.tabControl_GeneralInfo.SelectedIndex = 0;
            this.tabControl_GeneralInfo.Size = new System.Drawing.Size(591, 382);
            this.tabControl_GeneralInfo.TabIndex = 1;
            this.tabControl_GeneralInfo.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl_GeneralInfo_Selected);
            // 
            // tabPageFeeVoucher
            // 
            this.tabPageFeeVoucher.AutoScroll = true;
            this.tabPageFeeVoucher.Controls.Add(this.btn_FeePaidHistory);
            this.tabPageFeeVoucher.Controls.Add(this.btn_DeleteVoucher);
            this.tabPageFeeVoucher.Controls.Add(this.btn_AddNewFeeVoucher);
            this.tabPageFeeVoucher.Controls.Add(voucher_DateLabel1);
            this.tabPageFeeVoucher.Controls.Add(this.voucher_DateTextBox);
            this.tabPageFeeVoucher.Controls.Add(this.btnPrintVoucher);
            this.tabPageFeeVoucher.Controls.Add(this.dgvFeeDetailCurrentVoucher);
            this.tabPageFeeVoucher.Controls.Add(this.tbl_Fee_Voucher_MasterBindingNavigator);
            this.tabPageFeeVoucher.Controls.Add(fee_Voucher_IDLabel);
            this.tabPageFeeVoucher.Controls.Add(this.fee_Voucher_IDTextBox);
            this.tabPageFeeVoucher.Controls.Add(this.btnAddFee);
            this.tabPageFeeVoucher.Controls.Add(std_Mov_IDLabel);
            this.tabPageFeeVoucher.Controls.Add(this.std_Mov_IDTextBox);
            this.tabPageFeeVoucher.Location = new System.Drawing.Point(4, 22);
            this.tabPageFeeVoucher.Name = "tabPageFeeVoucher";
            this.tabPageFeeVoucher.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFeeVoucher.Size = new System.Drawing.Size(583, 356);
            this.tabPageFeeVoucher.TabIndex = 1;
            this.tabPageFeeVoucher.Text = "Student Fee Voucher";
            this.tabPageFeeVoucher.UseVisualStyleBackColor = true;
            // 
            // btn_FeePaidHistory
            // 
            this.btn_FeePaidHistory.Image = global::GeneralSchool.Properties.Resources.button_print;
            this.btn_FeePaidHistory.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_FeePaidHistory.Location = new System.Drawing.Point(431, 22);
            this.btn_FeePaidHistory.Name = "btn_FeePaidHistory";
            this.btn_FeePaidHistory.Size = new System.Drawing.Size(143, 31);
            this.btn_FeePaidHistory.TabIndex = 185;
            this.btn_FeePaidHistory.Text = "Print Fee Paid History";
            this.btn_FeePaidHistory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_FeePaidHistory.UseVisualStyleBackColor = true;
            this.btn_FeePaidHistory.Click += new System.EventHandler(this.btn_FeePaidHistory_Click);
            // 
            // btn_DeleteVoucher
            // 
            this.btn_DeleteVoucher.Image = global::GeneralSchool.Properties.Resources.button_delete;
            this.btn_DeleteVoucher.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_DeleteVoucher.Location = new System.Drawing.Point(451, 202);
            this.btn_DeleteVoucher.Name = "btn_DeleteVoucher";
            this.btn_DeleteVoucher.Size = new System.Drawing.Size(90, 35);
            this.btn_DeleteVoucher.TabIndex = 184;
            this.btn_DeleteVoucher.Text = "Delete Fee";
            this.btn_DeleteVoucher.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_DeleteVoucher.UseVisualStyleBackColor = true;
            this.btn_DeleteVoucher.Click += new System.EventHandler(this.btn_DeleteVoucher_Click);
            // 
            // btn_AddNewFeeVoucher
            // 
            this.btn_AddNewFeeVoucher.BackgroundImage = global::GeneralSchool.Properties.Resources.add_2;
            this.btn_AddNewFeeVoucher.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_AddNewFeeVoucher.Location = new System.Drawing.Point(451, 271);
            this.btn_AddNewFeeVoucher.Name = "btn_AddNewFeeVoucher";
            this.btn_AddNewFeeVoucher.Size = new System.Drawing.Size(120, 35);
            this.btn_AddNewFeeVoucher.TabIndex = 183;
            this.btn_AddNewFeeVoucher.Text = "        Add New Fee Voucher";
            this.btn_AddNewFeeVoucher.UseVisualStyleBackColor = true;
            this.btn_AddNewFeeVoucher.Click += new System.EventHandler(this.btn_AddNewFeeVoucher_Click);
            // 
            // voucher_DateTextBox
            // 
            this.voucher_DateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Fee_Voucher_MasterBindingSource, "Voucher_Date", true));
            this.voucher_DateTextBox.Location = new System.Drawing.Point(225, 33);
            this.voucher_DateTextBox.Name = "voucher_DateTextBox";
            this.voucher_DateTextBox.ReadOnly = true;
            this.voucher_DateTextBox.Size = new System.Drawing.Size(107, 20);
            this.voucher_DateTextBox.TabIndex = 182;
            // 
            // tbl_Fee_Voucher_MasterBindingSource
            // 
            this.tbl_Fee_Voucher_MasterBindingSource.DataMember = "tbl_Fee_Voucher_Master";
            this.tbl_Fee_Voucher_MasterBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnPrintVoucher
            // 
            this.btnPrintVoucher.Image = global::GeneralSchool.Properties.Resources.button_print;
            this.btnPrintVoucher.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPrintVoucher.Location = new System.Drawing.Point(451, 77);
            this.btnPrintVoucher.Name = "btnPrintVoucher";
            this.btnPrintVoucher.Size = new System.Drawing.Size(111, 30);
            this.btnPrintVoucher.TabIndex = 181;
            this.btnPrintVoucher.Text = "Print Voucher";
            this.btnPrintVoucher.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnPrintVoucher.UseVisualStyleBackColor = true;
            this.btnPrintVoucher.Click += new System.EventHandler(this.btnPrintVoucher_Click);
            // 
            // dgvFeeDetailCurrentVoucher
            // 
            this.dgvFeeDetailCurrentVoucher.AllowUserToAddRows = false;
            this.dgvFeeDetailCurrentVoucher.AllowUserToDeleteRows = false;
            this.dgvFeeDetailCurrentVoucher.AllowUserToResizeColumns = false;
            this.dgvFeeDetailCurrentVoucher.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dgvFeeDetailCurrentVoucher.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvFeeDetailCurrentVoucher.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvFeeDetailCurrentVoucher.Location = new System.Drawing.Point(6, 119);
            this.dgvFeeDetailCurrentVoucher.Name = "dgvFeeDetailCurrentVoucher";
            this.dgvFeeDetailCurrentVoucher.ReadOnly = true;
            this.dgvFeeDetailCurrentVoucher.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvFeeDetailCurrentVoucher.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvFeeDetailCurrentVoucher.Size = new System.Drawing.Size(413, 187);
            this.dgvFeeDetailCurrentVoucher.TabIndex = 178;
            // 
            // tbl_Fee_Voucher_MasterBindingNavigator
            // 
            this.tbl_Fee_Voucher_MasterBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_Fee_Voucher_MasterBindingNavigator.BindingSource = this.tbl_Fee_Voucher_MasterBindingSource;
            this.tbl_Fee_Voucher_MasterBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_Fee_Voucher_MasterBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_Fee_Voucher_MasterBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.tbl_Fee_Voucher_MasterBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_Fee_Voucher_MasterBindingNavigatorSaveItem});
            this.tbl_Fee_Voucher_MasterBindingNavigator.Location = new System.Drawing.Point(6, 82);
            this.tbl_Fee_Voucher_MasterBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_Fee_Voucher_MasterBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_Fee_Voucher_MasterBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_Fee_Voucher_MasterBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_Fee_Voucher_MasterBindingNavigator.Name = "tbl_Fee_Voucher_MasterBindingNavigator";
            this.tbl_Fee_Voucher_MasterBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_Fee_Voucher_MasterBindingNavigator.Size = new System.Drawing.Size(210, 25);
            this.tbl_Fee_Voucher_MasterBindingNavigator.TabIndex = 94;
            this.tbl_Fee_Voucher_MasterBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add New Fee Voucher";
            this.bindingNavigatorAddNewItem.Visible = false;
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.Enabled = false;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(58, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_Fee_Voucher_MasterBindingNavigatorSaveItem
            // 
            this.tbl_Fee_Voucher_MasterBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tbl_Fee_Voucher_MasterBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_Fee_Voucher_MasterBindingNavigatorSaveItem.Image")));
            this.tbl_Fee_Voucher_MasterBindingNavigatorSaveItem.Name = "tbl_Fee_Voucher_MasterBindingNavigatorSaveItem";
            this.tbl_Fee_Voucher_MasterBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.tbl_Fee_Voucher_MasterBindingNavigatorSaveItem.Text = "Save Fee Voucher";
            this.tbl_Fee_Voucher_MasterBindingNavigatorSaveItem.Visible = false;
            this.tbl_Fee_Voucher_MasterBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_Fee_Voucher_MasterBindingNavigatorSaveItem_Click_1);
            // 
            // fee_Voucher_IDTextBox
            // 
            this.fee_Voucher_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Fee_Voucher_MasterBindingSource, "Fee_Voucher_ID", true));
            this.fee_Voucher_IDTextBox.Location = new System.Drawing.Point(94, 33);
            this.fee_Voucher_IDTextBox.Name = "fee_Voucher_IDTextBox";
            this.fee_Voucher_IDTextBox.ReadOnly = true;
            this.fee_Voucher_IDTextBox.Size = new System.Drawing.Size(47, 20);
            this.fee_Voucher_IDTextBox.TabIndex = 161;
            // 
            // btnAddFee
            // 
            this.btnAddFee.Image = global::GeneralSchool.Properties.Resources.enable_add;
            this.btnAddFee.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddFee.Location = new System.Drawing.Point(451, 127);
            this.btnAddFee.Name = "btnAddFee";
            this.btnAddFee.Size = new System.Drawing.Size(90, 37);
            this.btnAddFee.TabIndex = 166;
            this.btnAddFee.Text = "Add Fee";
            this.btnAddFee.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddFee.UseVisualStyleBackColor = true;
            this.btnAddFee.Click += new System.EventHandler(this.btnAddFee_Click);
            // 
            // std_Mov_IDTextBox
            // 
            this.std_Mov_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Fee_Voucher_MasterBindingSource, "Std_Mov_ID", true));
            this.std_Mov_IDTextBox.Location = new System.Drawing.Point(292, 134);
            this.std_Mov_IDTextBox.Name = "std_Mov_IDTextBox";
            this.std_Mov_IDTextBox.Size = new System.Drawing.Size(60, 20);
            this.std_Mov_IDTextBox.TabIndex = 187;
            // 
            // tabPageFeeExemption
            // 
            this.tabPageFeeExemption.AutoScroll = true;
            this.tabPageFeeExemption.Controls.Add(this.btn_ExemptFeeHistory);
            this.tabPageFeeExemption.Controls.Add(this.tbl_Exemp_FV_Master_bindingNavigator);
            this.tabPageFeeExemption.Controls.Add(exemp_FV_DateLabel1);
            this.tabPageFeeExemption.Controls.Add(this.exemp_FV_DateTextBox);
            this.tabPageFeeExemption.Controls.Add(this.dgvExemptFeeDetailVoucher);
            this.tabPageFeeExemption.Controls.Add(this.btn_Print_Exempt_Voucher);
            this.tabPageFeeExemption.Controls.Add(this.btn_Add_FeeForExemption);
            this.tabPageFeeExemption.Controls.Add(this.btn_Delete_Exempt_Voucher_Detail);
            this.tabPageFeeExemption.Controls.Add(this.btn_Add_Exempt_Voucher);
            this.tabPageFeeExemption.Controls.Add(exemp_FVM_IDLabel);
            this.tabPageFeeExemption.Controls.Add(this.exemp_FVM_IDTextBox);
            this.tabPageFeeExemption.Controls.Add(std_Mov_IDLabel1);
            this.tabPageFeeExemption.Controls.Add(this.std_Mov_IDTextBox1);
            this.tabPageFeeExemption.Location = new System.Drawing.Point(4, 22);
            this.tabPageFeeExemption.Name = "tabPageFeeExemption";
            this.tabPageFeeExemption.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFeeExemption.Size = new System.Drawing.Size(583, 356);
            this.tabPageFeeExemption.TabIndex = 2;
            this.tabPageFeeExemption.Text = "Fee Exemption";
            this.tabPageFeeExemption.UseVisualStyleBackColor = true;
            this.tabPageFeeExemption.Click += new System.EventHandler(this.tabPageFeeExemption_Click);
            // 
            // btn_ExemptFeeHistory
            // 
            this.btn_ExemptFeeHistory.Image = global::GeneralSchool.Properties.Resources.button_print;
            this.btn_ExemptFeeHistory.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ExemptFeeHistory.Location = new System.Drawing.Point(413, 21);
            this.btn_ExemptFeeHistory.Name = "btn_ExemptFeeHistory";
            this.btn_ExemptFeeHistory.Size = new System.Drawing.Size(158, 34);
            this.btn_ExemptFeeHistory.TabIndex = 14;
            this.btn_ExemptFeeHistory.Text = "Print Exempt Fee History";
            this.btn_ExemptFeeHistory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_ExemptFeeHistory.UseVisualStyleBackColor = true;
            this.btn_ExemptFeeHistory.Click += new System.EventHandler(this.btn_ExemptFeeHistory_Click);
            // 
            // tbl_Exemp_FV_Master_bindingNavigator
            // 
            this.tbl_Exemp_FV_Master_bindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem1;
            this.tbl_Exemp_FV_Master_bindingNavigator.BindingSource = this.tbl_Exemp_FV_MasterBindingSource;
            this.tbl_Exemp_FV_Master_bindingNavigator.CountItem = this.bindingNavigatorCountItem1;
            this.tbl_Exemp_FV_Master_bindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem1;
            this.tbl_Exemp_FV_Master_bindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.tbl_Exemp_FV_Master_bindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem1,
            this.bindingNavigatorMovePreviousItem1,
            this.bindingNavigatorSeparator3,
            this.bindingNavigatorPositionItem1,
            this.bindingNavigatorCountItem1,
            this.bindingNavigatorSeparator4,
            this.bindingNavigatorMoveNextItem1,
            this.bindingNavigatorMoveLastItem1,
            this.bindingNavigatorSeparator5,
            this.bindingNavigatorAddNewItem1,
            this.bindingNavigatorDeleteItem1});
            this.tbl_Exemp_FV_Master_bindingNavigator.Location = new System.Drawing.Point(9, 86);
            this.tbl_Exemp_FV_Master_bindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem1;
            this.tbl_Exemp_FV_Master_bindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem1;
            this.tbl_Exemp_FV_Master_bindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem1;
            this.tbl_Exemp_FV_Master_bindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem1;
            this.tbl_Exemp_FV_Master_bindingNavigator.Name = "tbl_Exemp_FV_Master_bindingNavigator";
            this.tbl_Exemp_FV_Master_bindingNavigator.PositionItem = this.bindingNavigatorPositionItem1;
            this.tbl_Exemp_FV_Master_bindingNavigator.Size = new System.Drawing.Size(210, 25);
            this.tbl_Exemp_FV_Master_bindingNavigator.TabIndex = 13;
            this.tbl_Exemp_FV_Master_bindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem1
            // 
            this.bindingNavigatorAddNewItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem1.Image")));
            this.bindingNavigatorAddNewItem1.Name = "bindingNavigatorAddNewItem1";
            this.bindingNavigatorAddNewItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem1.Text = "Add new";
            this.bindingNavigatorAddNewItem1.Visible = false;
            // 
            // tbl_Exemp_FV_MasterBindingSource
            // 
            this.tbl_Exemp_FV_MasterBindingSource.DataMember = "tbl_Exemp_FV_Master";
            this.tbl_Exemp_FV_MasterBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // bindingNavigatorCountItem1
            // 
            this.bindingNavigatorCountItem1.Name = "bindingNavigatorCountItem1";
            this.bindingNavigatorCountItem1.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem1.Text = "of {0}";
            this.bindingNavigatorCountItem1.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem1
            // 
            this.bindingNavigatorDeleteItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem1.Image")));
            this.bindingNavigatorDeleteItem1.Name = "bindingNavigatorDeleteItem1";
            this.bindingNavigatorDeleteItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem1.Text = "Delete";
            this.bindingNavigatorDeleteItem1.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem1
            // 
            this.bindingNavigatorMoveFirstItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem1.Image")));
            this.bindingNavigatorMoveFirstItem1.Name = "bindingNavigatorMoveFirstItem1";
            this.bindingNavigatorMoveFirstItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem1.Text = "Move first";
            this.bindingNavigatorMoveFirstItem1.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem1_Click);
            // 
            // bindingNavigatorMovePreviousItem1
            // 
            this.bindingNavigatorMovePreviousItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem1.Image")));
            this.bindingNavigatorMovePreviousItem1.Name = "bindingNavigatorMovePreviousItem1";
            this.bindingNavigatorMovePreviousItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem1.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem1.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem1_Click);
            // 
            // bindingNavigatorSeparator3
            // 
            this.bindingNavigatorSeparator3.Name = "bindingNavigatorSeparator3";
            this.bindingNavigatorSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem1
            // 
            this.bindingNavigatorPositionItem1.AccessibleName = "Position";
            this.bindingNavigatorPositionItem1.AutoSize = false;
            this.bindingNavigatorPositionItem1.Name = "bindingNavigatorPositionItem1";
            this.bindingNavigatorPositionItem1.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem1.Text = "0";
            this.bindingNavigatorPositionItem1.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator4
            // 
            this.bindingNavigatorSeparator4.Name = "bindingNavigatorSeparator4";
            this.bindingNavigatorSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem1
            // 
            this.bindingNavigatorMoveNextItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem1.Image")));
            this.bindingNavigatorMoveNextItem1.Name = "bindingNavigatorMoveNextItem1";
            this.bindingNavigatorMoveNextItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem1.Text = "Move next";
            this.bindingNavigatorMoveNextItem1.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem1_Click);
            // 
            // bindingNavigatorMoveLastItem1
            // 
            this.bindingNavigatorMoveLastItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem1.Image")));
            this.bindingNavigatorMoveLastItem1.Name = "bindingNavigatorMoveLastItem1";
            this.bindingNavigatorMoveLastItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem1.Text = "Move last";
            this.bindingNavigatorMoveLastItem1.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem1_Click);
            // 
            // bindingNavigatorSeparator5
            // 
            this.bindingNavigatorSeparator5.Name = "bindingNavigatorSeparator5";
            this.bindingNavigatorSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // exemp_FV_DateTextBox
            // 
            this.exemp_FV_DateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Exemp_FV_MasterBindingSource, "Exemp_FV_Date", true));
            this.exemp_FV_DateTextBox.Location = new System.Drawing.Point(256, 35);
            this.exemp_FV_DateTextBox.Name = "exemp_FV_DateTextBox";
            this.exemp_FV_DateTextBox.ReadOnly = true;
            this.exemp_FV_DateTextBox.Size = new System.Drawing.Size(100, 20);
            this.exemp_FV_DateTextBox.TabIndex = 12;
            // 
            // dgvExemptFeeDetailVoucher
            // 
            this.dgvExemptFeeDetailVoucher.AllowUserToAddRows = false;
            this.dgvExemptFeeDetailVoucher.AllowUserToDeleteRows = false;
            this.dgvExemptFeeDetailVoucher.AllowUserToResizeColumns = false;
            this.dgvExemptFeeDetailVoucher.AllowUserToResizeRows = false;
            this.dgvExemptFeeDetailVoucher.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvExemptFeeDetailVoucher.Location = new System.Drawing.Point(11, 122);
            this.dgvExemptFeeDetailVoucher.Name = "dgvExemptFeeDetailVoucher";
            this.dgvExemptFeeDetailVoucher.ReadOnly = true;
            this.dgvExemptFeeDetailVoucher.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvExemptFeeDetailVoucher.Size = new System.Drawing.Size(413, 184);
            this.dgvExemptFeeDetailVoucher.TabIndex = 10;
            // 
            // btn_Print_Exempt_Voucher
            // 
            this.btn_Print_Exempt_Voucher.Image = global::GeneralSchool.Properties.Resources.button_print;
            this.btn_Print_Exempt_Voucher.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Print_Exempt_Voucher.Location = new System.Drawing.Point(444, 72);
            this.btn_Print_Exempt_Voucher.Name = "btn_Print_Exempt_Voucher";
            this.btn_Print_Exempt_Voucher.Size = new System.Drawing.Size(108, 30);
            this.btn_Print_Exempt_Voucher.TabIndex = 9;
            this.btn_Print_Exempt_Voucher.Text = "Print Voucher";
            this.btn_Print_Exempt_Voucher.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Print_Exempt_Voucher.UseVisualStyleBackColor = true;
            this.btn_Print_Exempt_Voucher.Click += new System.EventHandler(this.btn_Print_Exempt_Voucher_Click);
            // 
            // btn_Add_FeeForExemption
            // 
            this.btn_Add_FeeForExemption.Image = global::GeneralSchool.Properties.Resources.enable_add;
            this.btn_Add_FeeForExemption.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Add_FeeForExemption.Location = new System.Drawing.Point(444, 128);
            this.btn_Add_FeeForExemption.Name = "btn_Add_FeeForExemption";
            this.btn_Add_FeeForExemption.Size = new System.Drawing.Size(86, 32);
            this.btn_Add_FeeForExemption.TabIndex = 8;
            this.btn_Add_FeeForExemption.Text = "Add Fee";
            this.btn_Add_FeeForExemption.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Add_FeeForExemption.UseVisualStyleBackColor = true;
            this.btn_Add_FeeForExemption.Click += new System.EventHandler(this.btn_Add_FeeForExemption_Click);
            // 
            // btn_Delete_Exempt_Voucher_Detail
            // 
            this.btn_Delete_Exempt_Voucher_Detail.Image = global::GeneralSchool.Properties.Resources.button_delete;
            this.btn_Delete_Exempt_Voucher_Detail.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Delete_Exempt_Voucher_Detail.Location = new System.Drawing.Point(444, 204);
            this.btn_Delete_Exempt_Voucher_Detail.Name = "btn_Delete_Exempt_Voucher_Detail";
            this.btn_Delete_Exempt_Voucher_Detail.Size = new System.Drawing.Size(127, 32);
            this.btn_Delete_Exempt_Voucher_Detail.TabIndex = 7;
            this.btn_Delete_Exempt_Voucher_Detail.Text = "Delete Exempt Fee";
            this.btn_Delete_Exempt_Voucher_Detail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Delete_Exempt_Voucher_Detail.UseVisualStyleBackColor = true;
            this.btn_Delete_Exempt_Voucher_Detail.Click += new System.EventHandler(this.btn_Delete_Exempt_Voucher_Detail_Click);
            // 
            // btn_Add_Exempt_Voucher
            // 
            this.btn_Add_Exempt_Voucher.BackgroundImage = global::GeneralSchool.Properties.Resources.add_2;
            this.btn_Add_Exempt_Voucher.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_Add_Exempt_Voucher.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Add_Exempt_Voucher.Location = new System.Drawing.Point(444, 270);
            this.btn_Add_Exempt_Voucher.Name = "btn_Add_Exempt_Voucher";
            this.btn_Add_Exempt_Voucher.Size = new System.Drawing.Size(109, 36);
            this.btn_Add_Exempt_Voucher.TabIndex = 6;
            this.btn_Add_Exempt_Voucher.Text = "New Exempt Voucher";
            this.btn_Add_Exempt_Voucher.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_Add_Exempt_Voucher.UseVisualStyleBackColor = true;
            this.btn_Add_Exempt_Voucher.Click += new System.EventHandler(this.btn_Add_Exempt_Voucher_Click);
            // 
            // exemp_FVM_IDTextBox
            // 
            this.exemp_FVM_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Exemp_FV_MasterBindingSource, "Exemp_FVM_ID", true));
            this.exemp_FVM_IDTextBox.Location = new System.Drawing.Point(90, 35);
            this.exemp_FVM_IDTextBox.Name = "exemp_FVM_IDTextBox";
            this.exemp_FVM_IDTextBox.ReadOnly = true;
            this.exemp_FVM_IDTextBox.Size = new System.Drawing.Size(66, 20);
            this.exemp_FVM_IDTextBox.TabIndex = 1;
            // 
            // std_Mov_IDTextBox1
            // 
            this.std_Mov_IDTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Exemp_FV_MasterBindingSource, "Std_Mov_ID", true));
            this.std_Mov_IDTextBox1.Location = new System.Drawing.Point(309, 131);
            this.std_Mov_IDTextBox1.Name = "std_Mov_IDTextBox1";
            this.std_Mov_IDTextBox1.Size = new System.Drawing.Size(85, 20);
            this.std_Mov_IDTextBox1.TabIndex = 5;
            // 
            // tabPage_VoucherReport
            // 
            this.tabPage_VoucherReport.Controls.Add(this.crystalReportViewer_VoucherReport);
            this.tabPage_VoucherReport.Location = new System.Drawing.Point(4, 22);
            this.tabPage_VoucherReport.Name = "tabPage_VoucherReport";
            this.tabPage_VoucherReport.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_VoucherReport.Size = new System.Drawing.Size(583, 356);
            this.tabPage_VoucherReport.TabIndex = 3;
            this.tabPage_VoucherReport.Text = "Voucher Report";
            this.tabPage_VoucherReport.UseVisualStyleBackColor = true;
            // 
            // crystalReportViewer_VoucherReport
            // 
            this.crystalReportViewer_VoucherReport.ActiveViewIndex = -1;
            this.crystalReportViewer_VoucherReport.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.crystalReportViewer_VoucherReport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer_VoucherReport.DisplayGroupTree = false;
            this.crystalReportViewer_VoucherReport.DisplayStatusBar = false;
            this.crystalReportViewer_VoucherReport.DisplayToolbar = false;
            this.crystalReportViewer_VoucherReport.Location = new System.Drawing.Point(3, 3);
            this.crystalReportViewer_VoucherReport.Name = "crystalReportViewer_VoucherReport";
            this.crystalReportViewer_VoucherReport.SelectionFormula = "";
            this.crystalReportViewer_VoucherReport.Size = new System.Drawing.Size(571, 342);
            this.crystalReportViewer_VoucherReport.TabIndex = 0;
            this.crystalReportViewer_VoucherReport.ViewTimeSelectionFormula = "";
            // 
            // gR_NoTextBox
            // 
            this.gR_NoTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.gR_NoTextBox.Location = new System.Drawing.Point(123, 19);
            this.gR_NoTextBox.Mask = "0000";
            this.gR_NoTextBox.Name = "gR_NoTextBox";
            this.gR_NoTextBox.Size = new System.Drawing.Size(45, 20);
            this.gR_NoTextBox.TabIndex = 0;
            this.gR_NoTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gR_NoTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.gR_NoTextBox_KeyPress);
            // 
            // label_ClassDetail
            // 
            this.label_ClassDetail.BackColor = System.Drawing.SystemColors.Window;
            this.label_ClassDetail.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label_ClassDetail.Location = new System.Drawing.Point(380, 49);
            this.label_ClassDetail.Name = "label_ClassDetail";
            this.label_ClassDetail.Size = new System.Drawing.Size(446, 20);
            this.label_ClassDetail.TabIndex = 146;
            this.label_ClassDetail.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mother_QualificationLabel1
            // 
            this.mother_QualificationLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.mother_QualificationLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mother_QualificationLabel1.Location = new System.Drawing.Point(823, 101);
            this.mother_QualificationLabel1.Name = "mother_QualificationLabel1";
            this.mother_QualificationLabel1.Size = new System.Drawing.Size(86, 20);
            this.mother_QualificationLabel1.TabIndex = 144;
            this.mother_QualificationLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // father_QualificationLabel1
            // 
            this.father_QualificationLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.father_QualificationLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.father_QualificationLabel1.Location = new System.Drawing.Point(604, 101);
            this.father_QualificationLabel1.Name = "father_QualificationLabel1";
            this.father_QualificationLabel1.Size = new System.Drawing.Size(100, 20);
            this.father_QualificationLabel1.TabIndex = 143;
            this.father_QualificationLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mother_TongueLabel1
            // 
            this.mother_TongueLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.mother_TongueLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mother_TongueLabel1.Location = new System.Drawing.Point(719, 75);
            this.mother_TongueLabel1.Name = "mother_TongueLabel1";
            this.mother_TongueLabel1.Size = new System.Drawing.Size(66, 20);
            this.mother_TongueLabel1.TabIndex = 142;
            this.mother_TongueLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mother_NameLabel1
            // 
            this.mother_NameLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.mother_NameLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mother_NameLabel1.Location = new System.Drawing.Point(419, 75);
            this.mother_NameLabel1.Name = "mother_NameLabel1";
            this.mother_NameLabel1.Size = new System.Drawing.Size(207, 20);
            this.mother_NameLabel1.TabIndex = 141;
            this.mother_NameLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // religionLabel1
            // 
            this.religionLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.religionLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.religionLabel1.Location = new System.Drawing.Point(394, 101);
            this.religionLabel1.Name = "religionLabel1";
            this.religionLabel1.Size = new System.Drawing.Size(100, 20);
            this.religionLabel1.TabIndex = 140;
            this.religionLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // admission_DateLabel1
            // 
            this.admission_DateLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.admission_DateLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.admission_DateLabel1.Location = new System.Drawing.Point(562, 18);
            this.admission_DateLabel1.Name = "admission_DateLabel1";
            this.admission_DateLabel1.Size = new System.Drawing.Size(100, 20);
            this.admission_DateLabel1.TabIndex = 138;
            this.admission_DateLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // organization_PhoneLabel1
            // 
            this.organization_PhoneLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.organization_PhoneLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.organization_PhoneLabel1.Location = new System.Drawing.Point(832, 129);
            this.organization_PhoneLabel1.Name = "organization_PhoneLabel1";
            this.organization_PhoneLabel1.Size = new System.Drawing.Size(100, 20);
            this.organization_PhoneLabel1.TabIndex = 136;
            this.organization_PhoneLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // residence_TelephoneLabel1
            // 
            this.residence_TelephoneLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.residence_TelephoneLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.residence_TelephoneLabel1.Location = new System.Drawing.Point(636, 129);
            this.residence_TelephoneLabel1.Name = "residence_TelephoneLabel1";
            this.residence_TelephoneLabel1.Size = new System.Drawing.Size(105, 20);
            this.residence_TelephoneLabel1.TabIndex = 135;
            this.residence_TelephoneLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // residence_AddressLabel1
            // 
            this.residence_AddressLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.residence_AddressLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.residence_AddressLabel1.Location = new System.Drawing.Point(64, 129);
            this.residence_AddressLabel1.Name = "residence_AddressLabel1";
            this.residence_AddressLabel1.Size = new System.Drawing.Size(454, 20);
            this.residence_AddressLabel1.TabIndex = 134;
            this.residence_AddressLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // genderLabel1
            // 
            this.genderLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.genderLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.genderLabel1.Location = new System.Drawing.Point(226, 101);
            this.genderLabel1.Name = "genderLabel1";
            this.genderLabel1.Size = new System.Drawing.Size(100, 20);
            this.genderLabel1.TabIndex = 133;
            this.genderLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // father_NameLabel1
            // 
            this.father_NameLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.father_NameLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.father_NameLabel1.Location = new System.Drawing.Point(88, 75);
            this.father_NameLabel1.Name = "father_NameLabel1";
            this.father_NameLabel1.Size = new System.Drawing.Size(238, 20);
            this.father_NameLabel1.TabIndex = 132;
            this.father_NameLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // student_NameLabel1
            // 
            this.student_NameLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.student_NameLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.student_NameLabel1.Location = new System.Drawing.Point(88, 46);
            this.student_NameLabel1.Name = "student_NameLabel1";
            this.student_NameLabel1.Size = new System.Drawing.Size(238, 20);
            this.student_NameLabel1.TabIndex = 130;
            this.student_NameLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rollLabel1
            // 
            this.rollLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.rollLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.rollLabel1.Location = new System.Drawing.Point(295, 19);
            this.rollLabel1.Name = "rollLabel1";
            this.rollLabel1.Size = new System.Drawing.Size(31, 20);
            this.rollLabel1.TabIndex = 129;
            this.rollLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // st_Mov_IDLabel1
            // 
            this.st_Mov_IDLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.st_Mov_IDLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.st_Mov_IDLabel1.Location = new System.Drawing.Point(781, 11);
            this.st_Mov_IDLabel1.Name = "st_Mov_IDLabel1";
            this.st_Mov_IDLabel1.Size = new System.Drawing.Size(40, 19);
            this.st_Mov_IDLabel1.TabIndex = 127;
            this.st_Mov_IDLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // birth_DateLabel1
            // 
            this.birth_DateLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.birth_DateLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.birth_DateLabel1.Location = new System.Drawing.Point(64, 101);
            this.birth_DateLabel1.Name = "birth_DateLabel1";
            this.birth_DateLabel1.Size = new System.Drawing.Size(100, 20);
            this.birth_DateLabel1.TabIndex = 126;
            this.birth_DateLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // result_DescLabel1
            // 
            this.result_DescLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.result_DescLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.result_DescLabel1.Location = new System.Drawing.Point(707, 15);
            this.result_DescLabel1.Name = "result_DescLabel1";
            this.result_DescLabel1.Size = new System.Drawing.Size(100, 20);
            this.result_DescLabel1.TabIndex = 125;
            this.result_DescLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // session_DescLabel1
            // 
            this.session_DescLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.session_DescLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.session_DescLabel1.Location = new System.Drawing.Point(392, 19);
            this.session_DescLabel1.Name = "session_DescLabel1";
            this.session_DescLabel1.Size = new System.Drawing.Size(79, 19);
            this.session_DescLabel1.TabIndex = 118;
            this.session_DescLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(633, 78);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 13);
            this.label12.TabIndex = 117;
            this.label12.Text = "Mother Tongue";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(716, 105);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 13);
            this.label11.TabIndex = 116;
            this.label11.Text = "Mother Qualification";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(500, 105);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 13);
            this.label10.TabIndex = 115;
            this.label10.Text = "Father Qualification";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(477, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 13);
            this.label9.TabIndex = 114;
            this.label9.Text = "Admission Date";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 105);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 13);
            this.label8.TabIndex = 113;
            this.label8.Text = "Birth Date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(741, 133);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 13);
            this.label7.TabIndex = 112;
            this.label7.Text = "Father/Guardian";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(572, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 111;
            this.label6.Text = "Residence";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(534, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 110;
            this.label5.Text = "Phone:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 109;
            this.label4.Text = "Address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 108;
            this.label2.Text = "Father Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 107;
            this.label1.Text = "Student Name";
            // 
            // label_Session_Id
            // 
            this.label_Session_Id.AutoSize = true;
            this.label_Session_Id.Location = new System.Drawing.Point(831, 17);
            this.label_Session_Id.Name = "label_Session_Id";
            this.label_Session_Id.Size = new System.Drawing.Size(87, 13);
            this.label_Session_Id.TabIndex = 106;
            this.label_Session_Id.Text = "label_Session_Id";
            // 
            // label_feeBalance
            // 
            this.label_feeBalance.AutoSize = true;
            this.label_feeBalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_feeBalance.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_feeBalance.Location = new System.Drawing.Point(262, 20);
            this.label_feeBalance.Name = "label_feeBalance";
            this.label_feeBalance.Size = new System.Drawing.Size(0, 13);
            this.label_feeBalance.TabIndex = 176;
            // 
            // label_feePaid
            // 
            this.label_feePaid.AutoSize = true;
            this.label_feePaid.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_feePaid.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_feePaid.Location = new System.Drawing.Point(129, 20);
            this.label_feePaid.Name = "label_feePaid";
            this.label_feePaid.Size = new System.Drawing.Size(0, 13);
            this.label_feePaid.TabIndex = 175;
            // 
            // label_totalFee
            // 
            this.label_totalFee.AutoSize = true;
            this.label_totalFee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_totalFee.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_totalFee.Location = new System.Drawing.Point(51, 20);
            this.label_totalFee.Name = "label_totalFee";
            this.label_totalFee.Size = new System.Drawing.Size(0, 13);
            this.label_totalFee.TabIndex = 174;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(262, 3);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(53, 13);
            this.label40.TabIndex = 173;
            this.label40.Text = "Balance";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(129, 3);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(32, 13);
            this.label39.TabIndex = 172;
            this.label39.Text = "Paid";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(51, 3);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(66, 14);
            this.label38.TabIndex = 171;
            this.label38.Text = "Academic Year";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(6, 20);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(36, 13);
            this.label37.TabIndex = 170;
            this.label37.Text = "Total";
            // 
            // ClassID_label
            // 
            this.ClassID_label.AutoSize = true;
            this.ClassID_label.Location = new System.Drawing.Point(654, 16);
            this.ClassID_label.Name = "ClassID_label";
            this.ClassID_label.Size = new System.Drawing.Size(49, 13);
            this.ClassID_label.TabIndex = 168;
            this.ClassID_label.Text = "Class_ID";
            // 
            // dgv_FeePaidHistory
            // 
            this.dgv_FeePaidHistory.AllowUserToAddRows = false;
            this.dgv_FeePaidHistory.AllowUserToDeleteRows = false;
            this.dgv_FeePaidHistory.AllowUserToResizeColumns = false;
            this.dgv_FeePaidHistory.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dgv_FeePaidHistory.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_FeePaidHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgv_FeePaidHistory.Location = new System.Drawing.Point(9, 19);
            this.dgv_FeePaidHistory.Name = "dgv_FeePaidHistory";
            this.dgv_FeePaidHistory.ReadOnly = true;
            this.dgv_FeePaidHistory.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgv_FeePaidHistory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_FeePaidHistory.Size = new System.Drawing.Size(363, 127);
            this.dgv_FeePaidHistory.TabIndex = 167;
            // 
            // dgvUnpaidFeeVoucher
            // 
            this.dgvUnpaidFeeVoucher.AllowUserToAddRows = false;
            this.dgvUnpaidFeeVoucher.AllowUserToDeleteRows = false;
            this.dgvUnpaidFeeVoucher.AllowUserToResizeColumns = false;
            this.dgvUnpaidFeeVoucher.AllowUserToResizeRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dgvUnpaidFeeVoucher.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvUnpaidFeeVoucher.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvUnpaidFeeVoucher.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.dgvUnpaidFeeVoucher.Location = new System.Drawing.Point(9, 18);
            this.dgvUnpaidFeeVoucher.Name = "dgvUnpaidFeeVoucher";
            this.dgvUnpaidFeeVoucher.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvUnpaidFeeVoucher.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUnpaidFeeVoucher.Size = new System.Drawing.Size(363, 144);
            this.dgvUnpaidFeeVoucher.TabIndex = 160;
            // 
            // Tf_lbl_GRNo
            // 
            this.Tf_lbl_GRNo.BackColor = System.Drawing.SystemColors.Window;
            this.Tf_lbl_GRNo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Tf_lbl_GRNo.Location = new System.Drawing.Point(593, 14);
            this.Tf_lbl_GRNo.Name = "Tf_lbl_GRNo";
            this.Tf_lbl_GRNo.Size = new System.Drawing.Size(46, 19);
            this.Tf_lbl_GRNo.TabIndex = 120;
            this.Tf_lbl_GRNo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbl_Fee_Voucher_MasterTableAdapter
            // 
            this.tbl_Fee_Voucher_MasterTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_Fee_Voucher_DetailTableAdapter
            // 
            this.tbl_Fee_Voucher_DetailTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_Exemp_FV_MasterTableAdapter
            // 
            this.tbl_Exemp_FV_MasterTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_Exemp_FV_DetailBindingSource
            // 
            this.tbl_Exemp_FV_DetailBindingSource.DataMember = "tbl_Exemp_FV_Detail";
            this.tbl_Exemp_FV_DetailBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tbl_Exemp_FV_DetailTableAdapter
            // 
            this.tbl_Exemp_FV_DetailTableAdapter.ClearBeforeFill = true;
            // 
            // lbl_totalFeeExemption
            // 
            this.lbl_totalFeeExemption.AutoSize = true;
            this.lbl_totalFeeExemption.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalFeeExemption.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_totalFeeExemption.Location = new System.Drawing.Point(188, 20);
            this.lbl_totalFeeExemption.Name = "lbl_totalFeeExemption";
            this.lbl_totalFeeExemption.Size = new System.Drawing.Size(0, 13);
            this.lbl_totalFeeExemption.TabIndex = 183;
            // 
            // lbl_Exemption
            // 
            this.lbl_Exemption.AutoSize = true;
            this.lbl_Exemption.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Exemption.Location = new System.Drawing.Point(188, 3);
            this.lbl_Exemption.Name = "lbl_Exemption";
            this.lbl_Exemption.Size = new System.Drawing.Size(65, 13);
            this.lbl_Exemption.TabIndex = 182;
            this.lbl_Exemption.Text = "Exemption";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetPartial;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.68493F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 71F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 102F));
            this.tableLayoutPanel1.Controls.Add(this.label37, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl_totalFeeExemption, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.label38, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_Exemption, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label39, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label40, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label_totalFee, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label_feePaid, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label_feeBalance, 4, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(9, 154);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.63158F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.36842F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(364, 37);
            this.tableLayoutPanel1.TabIndex = 184;
            // 
            // percentageLabel1
            // 
            this.percentageLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.percentageLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.percentageLabel1.Location = new System.Drawing.Point(881, 15);
            this.percentageLabel1.Name = "percentageLabel1";
            this.percentageLabel1.Size = new System.Drawing.Size(31, 20);
            this.percentageLabel1.TabIndex = 128;
            this.percentageLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.gR_NoTextBox);
            this.groupBox1.Controls.Add(this.birth_DateLabel1);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.student_NameLabel1);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(gR_NoLabel);
            this.groupBox1.Controls.Add(this.father_NameLabel1);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label_ClassDetail);
            this.groupBox1.Controls.Add(this.genderLabel1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.organization_PhoneLabel1);
            this.groupBox1.Controls.Add(genderLabel);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.residence_TelephoneLabel1);
            this.groupBox1.Controls.Add(class_IDLabel);
            this.groupBox1.Controls.Add(this.mother_QualificationLabel1);
            this.groupBox1.Controls.Add(this.admission_DateLabel1);
            this.groupBox1.Controls.Add(this.residence_AddressLabel1);
            this.groupBox1.Controls.Add(this.rollLabel1);
            this.groupBox1.Controls.Add(this.percentageLabel1);
            this.groupBox1.Controls.Add(this.religionLabel1);
            this.groupBox1.Controls.Add(rollLabel);
            this.groupBox1.Controls.Add(religionLabel);
            this.groupBox1.Controls.Add(this.session_DescLabel1);
            this.groupBox1.Controls.Add(this.result_DescLabel1);
            this.groupBox1.Controls.Add(percentageLabel);
            this.groupBox1.Controls.Add(this.father_QualificationLabel1);
            this.groupBox1.Controls.Add(this.mother_NameLabel1);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(result_IDLabel);
            this.groupBox1.Controls.Add(session_IDLabel);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(mother_NameLabel);
            this.groupBox1.Controls.Add(this.mother_TongueLabel1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(9, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(985, 159);
            this.groupBox1.TabIndex = 185;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Student Information";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvUnpaidFeeVoucher);
            this.groupBox2.Location = new System.Drawing.Point(615, 227);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(379, 168);
            this.groupBox2.TabIndex = 186;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Un-Paid Fee";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dgv_FeePaidHistory);
            this.groupBox4.Controls.Add(this.tableLayoutPanel1);
            this.groupBox4.Location = new System.Drawing.Point(615, 405);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(379, 200);
            this.groupBox4.TabIndex = 187;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Paid Fee";
            // 
            // tbl_Fee_Voucher_DetailBindingSource
            // 
            this.tbl_Fee_Voucher_DetailBindingSource.DataMember = "tbl_Fee_Voucher_Mastertbl_Fee_Voucher_Detail";
            this.tbl_Fee_Voucher_DetailBindingSource.DataSource = this.tbl_Fee_Voucher_MasterBindingSource;
            // 
            // Form_General_Student_Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1025, 676);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tabControl_GeneralInfo);
            this.Controls.Add(this.ClassID_label);
            this.Controls.Add(this.label_Session_Id);
            this.Controls.Add(this.Tf_lbl_GRNo);
            this.Controls.Add(label13);
            this.Controls.Add(st_Mov_IDLabel);
            this.Controls.Add(this.st_Mov_IDLabel1);
            this.Name = "Form_General_Student_Info";
            this.Text = "Generate Fee Voucher";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form_General_Student_Info_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_General_Student_Info_FormClosing);
            this.tabControl_GeneralInfo.ResumeLayout(false);
            this.tabPageFeeVoucher.ResumeLayout(false);
            this.tabPageFeeVoucher.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Voucher_MasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeeDetailCurrentVoucher)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Voucher_MasterBindingNavigator)).EndInit();
            this.tbl_Fee_Voucher_MasterBindingNavigator.ResumeLayout(false);
            this.tbl_Fee_Voucher_MasterBindingNavigator.PerformLayout();
            this.tabPageFeeExemption.ResumeLayout(false);
            this.tabPageFeeExemption.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Exemp_FV_Master_bindingNavigator)).EndInit();
            this.tbl_Exemp_FV_Master_bindingNavigator.ResumeLayout(false);
            this.tbl_Exemp_FV_Master_bindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Exemp_FV_MasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExemptFeeDetailVoucher)).EndInit();
            this.tabPage_VoucherReport.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_FeePaidHistory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUnpaidFeeVoucher)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Exemp_FV_DetailBindingSource)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Fee_Voucher_DetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.unpaidFeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paidHistorybindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FeeDetailCurrentVoucherBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ExemptFeeDetailVoucherBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl_GeneralInfo;
        private System.Windows.Forms.Label mother_QualificationLabel1;
        private System.Windows.Forms.Label father_QualificationLabel1;
        private System.Windows.Forms.Label mother_TongueLabel1;
        private System.Windows.Forms.Label mother_NameLabel1;
        private System.Windows.Forms.Label religionLabel1;
        private System.Windows.Forms.Label admission_DateLabel1;
        private System.Windows.Forms.Label organization_PhoneLabel1;
        private System.Windows.Forms.Label residence_TelephoneLabel1;
        private System.Windows.Forms.Label residence_AddressLabel1;
        private System.Windows.Forms.Label genderLabel1;
        private System.Windows.Forms.Label father_NameLabel1;
        private System.Windows.Forms.Label student_NameLabel1;
        private System.Windows.Forms.Label rollLabel1;
        private System.Windows.Forms.Label st_Mov_IDLabel1;
        private System.Windows.Forms.Label birth_DateLabel1;
        private System.Windows.Forms.Label result_DescLabel1;
        private System.Windows.Forms.Label session_DescLabel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_Session_Id;
        private System.Windows.Forms.TabPage tabPageFeeVoucher;
        private System.Windows.Forms.Label Tf_lbl_GRNo;
        private System.Windows.Forms.DataGridView dgvUnpaidFeeVoucher;
        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tbl_Fee_Voucher_MasterBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Fee_Voucher_MasterTableAdapter tbl_Fee_Voucher_MasterTableAdapter;
        private System.Windows.Forms.BindingNavigator tbl_Fee_Voucher_MasterBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_Fee_Voucher_MasterBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox fee_Voucher_IDTextBox;
        private System.Windows.Forms.BindingSource tbl_Fee_Voucher_DetailBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Fee_Voucher_DetailTableAdapter tbl_Fee_Voucher_DetailTableAdapter;
        private System.Windows.Forms.BindingSource unpaidFeeBindingSource;
        private System.Windows.Forms.Button btnAddFee;
        private System.Windows.Forms.DataGridView dgv_FeePaidHistory;
        private System.Windows.Forms.Label ClassID_label;
        private System.Windows.Forms.BindingSource paidHistorybindingSource;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label_feePaid;
        private System.Windows.Forms.Label label_totalFee;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label_feeBalance;
        private System.Windows.Forms.DataGridView dgvFeeDetailCurrentVoucher;
        private System.Windows.Forms.BindingSource FeeDetailCurrentVoucherBindingSource;
        private System.Windows.Forms.Label label_ClassDetail;
        private System.Windows.Forms.MaskedTextBox gR_NoTextBox;
        private System.Windows.Forms.Button btnPrintVoucher;
        private System.Windows.Forms.TabPage tabPageFeeExemption;
        private System.Windows.Forms.BindingSource tbl_Exemp_FV_MasterBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Exemp_FV_MasterTableAdapter tbl_Exemp_FV_MasterTableAdapter;
        private System.Windows.Forms.TextBox exemp_FVM_IDTextBox;
        private System.Windows.Forms.TextBox std_Mov_IDTextBox1;
        private System.Windows.Forms.Button btn_Print_Exempt_Voucher;
        private System.Windows.Forms.Button btn_Add_FeeForExemption;
        private System.Windows.Forms.Button btn_Delete_Exempt_Voucher_Detail;
        private System.Windows.Forms.Button btn_Add_Exempt_Voucher;
        private System.Windows.Forms.DataGridView dgvExemptFeeDetailVoucher;
        private System.Windows.Forms.TextBox voucher_DateTextBox;
        private System.Windows.Forms.TextBox exemp_FV_DateTextBox;
        private System.Windows.Forms.BindingSource tbl_Exemp_FV_DetailBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Exemp_FV_DetailTableAdapter tbl_Exemp_FV_DetailTableAdapter;
        private System.Windows.Forms.BindingSource ExemptFeeDetailVoucherBindingSource;
        private System.Windows.Forms.Label lbl_totalFeeExemption;
        private System.Windows.Forms.Label lbl_Exemption;
        private System.Windows.Forms.BindingNavigator tbl_Exemp_FV_Master_bindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem1;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator3;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator4;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator5;
        private System.Windows.Forms.Button btn_DeleteVoucher;
        private System.Windows.Forms.Button btn_AddNewFeeVoucher;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label percentageLabel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabPage tabPage_VoucherReport;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer_VoucherReport;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btn_FeePaidHistory;
        private System.Windows.Forms.Button btn_ExemptFeeHistory;
        private System.Windows.Forms.TextBox std_Mov_IDTextBox;

    }
}