namespace GeneralSchool
{
    partial class Form_School
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label school_IDLabel;
            System.Windows.Forms.Label school_NameLabel;
            System.Windows.Forms.Label owner_NameLabel;
            System.Windows.Forms.Label principal_NameLabel;
            System.Windows.Forms.Label established_DateLabel;
            System.Windows.Forms.Label school_AddressLabel;
            System.Windows.Forms.Label school_PhoneLabel;
            System.Windows.Forms.Label school_WebsiteLabel;
            System.Windows.Forms.Label school_EmailLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_School));
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.tbl_SchoolBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_SchoolTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SchoolTableAdapter();
            this.tbl_SchoolBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_SchoolBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.btn_EditData = new System.Windows.Forms.ToolStripButton();
            this.school_IDTextBox = new System.Windows.Forms.TextBox();
            this.school_NameTextBox = new System.Windows.Forms.TextBox();
            this.owner_NameTextBox = new System.Windows.Forms.TextBox();
            this.principal_NameTextBox = new System.Windows.Forms.TextBox();
            this.established_DateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.school_AddressTextBox = new System.Windows.Forms.TextBox();
            this.school_PhoneTextBox = new System.Windows.Forms.TextBox();
            this.school_WebsiteTextBox = new System.Windows.Forms.TextBox();
            this.school_EmailTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            school_IDLabel = new System.Windows.Forms.Label();
            school_NameLabel = new System.Windows.Forms.Label();
            owner_NameLabel = new System.Windows.Forms.Label();
            principal_NameLabel = new System.Windows.Forms.Label();
            established_DateLabel = new System.Windows.Forms.Label();
            school_AddressLabel = new System.Windows.Forms.Label();
            school_PhoneLabel = new System.Windows.Forms.Label();
            school_WebsiteLabel = new System.Windows.Forms.Label();
            school_EmailLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SchoolBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SchoolBindingNavigator)).BeginInit();
            this.tbl_SchoolBindingNavigator.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // school_IDLabel
            // 
            school_IDLabel.AutoSize = true;
            school_IDLabel.Location = new System.Drawing.Point(128, 13);
            school_IDLabel.Name = "school_IDLabel";
            school_IDLabel.Size = new System.Drawing.Size(57, 13);
            school_IDLabel.TabIndex = 1;
            school_IDLabel.Text = "School ID:";
            school_IDLabel.Visible = false;
            // 
            // school_NameLabel
            // 
            school_NameLabel.AutoSize = true;
            school_NameLabel.Location = new System.Drawing.Point(35, 39);
            school_NameLabel.Name = "school_NameLabel";
            school_NameLabel.Size = new System.Drawing.Size(74, 13);
            school_NameLabel.TabIndex = 3;
            school_NameLabel.Text = "School Name:";
            // 
            // owner_NameLabel
            // 
            owner_NameLabel.AutoSize = true;
            owner_NameLabel.Location = new System.Drawing.Point(35, 65);
            owner_NameLabel.Name = "owner_NameLabel";
            owner_NameLabel.Size = new System.Drawing.Size(72, 13);
            owner_NameLabel.TabIndex = 5;
            owner_NameLabel.Text = "Owner Name:";
            // 
            // principal_NameLabel
            // 
            principal_NameLabel.AutoSize = true;
            principal_NameLabel.Location = new System.Drawing.Point(35, 94);
            principal_NameLabel.Name = "principal_NameLabel";
            principal_NameLabel.Size = new System.Drawing.Size(81, 13);
            principal_NameLabel.TabIndex = 7;
            principal_NameLabel.Text = "Principal Name:";
            // 
            // established_DateLabel
            // 
            established_DateLabel.AutoSize = true;
            established_DateLabel.Location = new System.Drawing.Point(35, 121);
            established_DateLabel.Name = "established_DateLabel";
            established_DateLabel.Size = new System.Drawing.Size(90, 13);
            established_DateLabel.TabIndex = 9;
            established_DateLabel.Text = "Established Date:";
            // 
            // school_AddressLabel
            // 
            school_AddressLabel.AutoSize = true;
            school_AddressLabel.Location = new System.Drawing.Point(35, 146);
            school_AddressLabel.Name = "school_AddressLabel";
            school_AddressLabel.Size = new System.Drawing.Size(84, 13);
            school_AddressLabel.TabIndex = 11;
            school_AddressLabel.Text = "School Address:";
            // 
            // school_PhoneLabel
            // 
            school_PhoneLabel.AutoSize = true;
            school_PhoneLabel.Location = new System.Drawing.Point(35, 172);
            school_PhoneLabel.Name = "school_PhoneLabel";
            school_PhoneLabel.Size = new System.Drawing.Size(77, 13);
            school_PhoneLabel.TabIndex = 13;
            school_PhoneLabel.Text = "School Phone:";
            // 
            // school_WebsiteLabel
            // 
            school_WebsiteLabel.AutoSize = true;
            school_WebsiteLabel.Location = new System.Drawing.Point(35, 198);
            school_WebsiteLabel.Name = "school_WebsiteLabel";
            school_WebsiteLabel.Size = new System.Drawing.Size(85, 13);
            school_WebsiteLabel.TabIndex = 15;
            school_WebsiteLabel.Text = "School Website:";
            // 
            // school_EmailLabel
            // 
            school_EmailLabel.AutoSize = true;
            school_EmailLabel.Location = new System.Drawing.Point(35, 224);
            school_EmailLabel.Name = "school_EmailLabel";
            school_EmailLabel.Size = new System.Drawing.Size(71, 13);
            school_EmailLabel.TabIndex = 17;
            school_EmailLabel.Text = "School Email:";
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_SchoolBindingSource
            // 
            this.tbl_SchoolBindingSource.DataMember = "tbl_School";
            this.tbl_SchoolBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tbl_SchoolTableAdapter
            // 
            this.tbl_SchoolTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_SchoolBindingNavigator
            // 
            this.tbl_SchoolBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_SchoolBindingNavigator.BindingSource = this.tbl_SchoolBindingSource;
            this.tbl_SchoolBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_SchoolBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_SchoolBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.tbl_SchoolBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_SchoolBindingNavigatorSaveItem,
            this.btn_EditData});
            this.tbl_SchoolBindingNavigator.Location = new System.Drawing.Point(38, 267);
            this.tbl_SchoolBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_SchoolBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_SchoolBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_SchoolBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_SchoolBindingNavigator.Name = "tbl_SchoolBindingNavigator";
            this.tbl_SchoolBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_SchoolBindingNavigator.Size = new System.Drawing.Size(160, 25);
            this.tbl_SchoolBindingNavigator.TabIndex = 0;
            this.tbl_SchoolBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Visible = false;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            this.bindingNavigatorCountItem.Visible = false;
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Visible = false;
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Visible = false;
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            this.bindingNavigatorSeparator.Visible = false;
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            this.bindingNavigatorPositionItem.Visible = false;
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            this.bindingNavigatorSeparator1.Visible = false;
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Visible = false;
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Visible = false;
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            this.bindingNavigatorSeparator2.Visible = false;
            // 
            // tbl_SchoolBindingNavigatorSaveItem
            // 
            this.tbl_SchoolBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_SchoolBindingNavigatorSaveItem.Image")));
            this.tbl_SchoolBindingNavigatorSaveItem.Name = "tbl_SchoolBindingNavigatorSaveItem";
            this.tbl_SchoolBindingNavigatorSaveItem.Size = new System.Drawing.Size(77, 22);
            this.tbl_SchoolBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_SchoolBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_SchoolBindingNavigatorSaveItem_Click);
            // 
            // btn_EditData
            // 
            this.btn_EditData.Image = global::GeneralSchool.Properties.Resources.edit;
            this.btn_EditData.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_EditData.Name = "btn_EditData";
            this.btn_EditData.Size = new System.Drawing.Size(71, 22);
            this.btn_EditData.Text = "Edit Data";
            this.btn_EditData.Click += new System.EventHandler(this.btn_EditData_Click);
            // 
            // school_IDTextBox
            // 
            this.school_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SchoolBindingSource, "School_ID", true));
            this.school_IDTextBox.Enabled = false;
            this.school_IDTextBox.Location = new System.Drawing.Point(224, 10);
            this.school_IDTextBox.Name = "school_IDTextBox";
            this.school_IDTextBox.Size = new System.Drawing.Size(36, 20);
            this.school_IDTextBox.TabIndex = 2;
            this.school_IDTextBox.Visible = false;
            // 
            // school_NameTextBox
            // 
            this.school_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SchoolBindingSource, "School_Name", true));
            this.school_NameTextBox.Enabled = false;
            this.school_NameTextBox.Location = new System.Drawing.Point(131, 36);
            this.school_NameTextBox.Name = "school_NameTextBox";
            this.school_NameTextBox.Size = new System.Drawing.Size(289, 20);
            this.school_NameTextBox.TabIndex = 4;
            // 
            // owner_NameTextBox
            // 
            this.owner_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SchoolBindingSource, "Owner_Name", true));
            this.owner_NameTextBox.Location = new System.Drawing.Point(131, 62);
            this.owner_NameTextBox.Name = "owner_NameTextBox";
            this.owner_NameTextBox.Size = new System.Drawing.Size(200, 20);
            this.owner_NameTextBox.TabIndex = 6;
            // 
            // principal_NameTextBox
            // 
            this.principal_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SchoolBindingSource, "Principal_Name", true));
            this.principal_NameTextBox.Location = new System.Drawing.Point(131, 91);
            this.principal_NameTextBox.Name = "principal_NameTextBox";
            this.principal_NameTextBox.Size = new System.Drawing.Size(200, 20);
            this.principal_NameTextBox.TabIndex = 8;
            // 
            // established_DateDateTimePicker
            // 
            this.established_DateDateTimePicker.CustomFormat = "dd-MMM-yyyy";
            this.established_DateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tbl_SchoolBindingSource, "Established_Date", true));
            this.established_DateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.established_DateDateTimePicker.Location = new System.Drawing.Point(131, 117);
            this.established_DateDateTimePicker.Name = "established_DateDateTimePicker";
            this.established_DateDateTimePicker.Size = new System.Drawing.Size(99, 20);
            this.established_DateDateTimePicker.TabIndex = 10;
            // 
            // school_AddressTextBox
            // 
            this.school_AddressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SchoolBindingSource, "School_Address", true));
            this.school_AddressTextBox.Location = new System.Drawing.Point(131, 143);
            this.school_AddressTextBox.Name = "school_AddressTextBox";
            this.school_AddressTextBox.Size = new System.Drawing.Size(346, 20);
            this.school_AddressTextBox.TabIndex = 12;
            // 
            // school_PhoneTextBox
            // 
            this.school_PhoneTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SchoolBindingSource, "School_Phone", true));
            this.school_PhoneTextBox.Location = new System.Drawing.Point(131, 169);
            this.school_PhoneTextBox.Name = "school_PhoneTextBox";
            this.school_PhoneTextBox.Size = new System.Drawing.Size(200, 20);
            this.school_PhoneTextBox.TabIndex = 14;
            // 
            // school_WebsiteTextBox
            // 
            this.school_WebsiteTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SchoolBindingSource, "School_Website", true));
            this.school_WebsiteTextBox.Location = new System.Drawing.Point(131, 195);
            this.school_WebsiteTextBox.Name = "school_WebsiteTextBox";
            this.school_WebsiteTextBox.Size = new System.Drawing.Size(200, 20);
            this.school_WebsiteTextBox.TabIndex = 16;
            // 
            // school_EmailTextBox
            // 
            this.school_EmailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SchoolBindingSource, "School_Email", true));
            this.school_EmailTextBox.Location = new System.Drawing.Point(131, 221);
            this.school_EmailTextBox.Name = "school_EmailTextBox";
            this.school_EmailTextBox.Size = new System.Drawing.Size(200, 20);
            this.school_EmailTextBox.TabIndex = 18;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(school_IDLabel);
            this.groupBox1.Controls.Add(this.tbl_SchoolBindingNavigator);
            this.groupBox1.Controls.Add(school_PhoneLabel);
            this.groupBox1.Controls.Add(principal_NameLabel);
            this.groupBox1.Controls.Add(this.school_PhoneTextBox);
            this.groupBox1.Controls.Add(school_WebsiteLabel);
            this.groupBox1.Controls.Add(this.owner_NameTextBox);
            this.groupBox1.Controls.Add(this.school_WebsiteTextBox);
            this.groupBox1.Controls.Add(this.principal_NameTextBox);
            this.groupBox1.Controls.Add(school_EmailLabel);
            this.groupBox1.Controls.Add(this.school_IDTextBox);
            this.groupBox1.Controls.Add(this.school_EmailTextBox);
            this.groupBox1.Controls.Add(established_DateLabel);
            this.groupBox1.Controls.Add(owner_NameLabel);
            this.groupBox1.Controls.Add(this.established_DateDateTimePicker);
            this.groupBox1.Controls.Add(school_AddressLabel);
            this.groupBox1.Controls.Add(school_NameLabel);
            this.groupBox1.Controls.Add(this.school_AddressTextBox);
            this.groupBox1.Controls.Add(this.school_NameTextBox);
            this.groupBox1.Location = new System.Drawing.Point(38, 134);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(657, 351);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Enter School Data";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(35, 315);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(548, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "NOTE: You can not change School Name, Address and Phone, for require changes, con" +
                "tact the Software Vendor.";
            // 
            // Form_School
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 497);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form_School";
            this.Text = "School Information";
            this.Load += new System.EventHandler(this.Form_School_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_School_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SchoolBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SchoolBindingNavigator)).EndInit();
            this.tbl_SchoolBindingNavigator.ResumeLayout(false);
            this.tbl_SchoolBindingNavigator.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tbl_SchoolBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SchoolTableAdapter tbl_SchoolTableAdapter;
        private System.Windows.Forms.BindingNavigator tbl_SchoolBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_SchoolBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox school_IDTextBox;
        private System.Windows.Forms.TextBox school_NameTextBox;
        private System.Windows.Forms.TextBox owner_NameTextBox;
        private System.Windows.Forms.TextBox principal_NameTextBox;
        private System.Windows.Forms.DateTimePicker established_DateDateTimePicker;
        private System.Windows.Forms.TextBox school_AddressTextBox;
        private System.Windows.Forms.TextBox school_PhoneTextBox;
        private System.Windows.Forms.TextBox school_WebsiteTextBox;
        private System.Windows.Forms.TextBox school_EmailTextBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripButton btn_EditData;
    }
}