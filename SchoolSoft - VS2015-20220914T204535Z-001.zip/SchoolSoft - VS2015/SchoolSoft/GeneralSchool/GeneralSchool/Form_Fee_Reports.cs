using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;


namespace GeneralSchool
{
    public partial class Form_Fee_Reports : Form
    {
        Class_ConnectDB conDb = new Class_ConnectDB();
        public Form_Fee_Reports()
        {
            InitializeComponent();
        }

        private void SetDBLogonForReport(ConnectionInfo connectionInfo)
        {
            TableLogOnInfos tableLogOnInfos = cRViewer_FeeVoucher.LogOnInfo;
            foreach (TableLogOnInfo tableLogOnInfo in tableLogOnInfos)
            {
                tableLogOnInfo.ConnectionInfo = connectionInfo;
            }
        }

        private void btn_ShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                CR_Fee_History_ByClass_Sec_Sess_Shift_Med crFHCSSSM = new CR_Fee_History_ByClass_Sec_Sess_Shift_Med();
                crFHCSSSM.Load("C://SchoolSoft//GeneralSchool//GeneralSchool//CR_Fee_History_ByClass_Sec_Sess_Shift_Med.rpt");
                cRViewer_FeeVoucher.ReportSource = crFHCSSSM;
                cRViewer_FeeVoucher.DisplayToolbar = true;
                cRViewer_FeeVoucher.Zoom(80);
                //crystalReportViewer_VoucherReport.Right;
                crFHCSSSM.SetParameterValue("schoolName", conDb._schoolName);
                crFHCSSSM.SetParameterValue("addressSchool", conDb._address);
                crFHCSSSM.SetParameterValue("phoneSchool", conDb._phone);
                string compNamAdd = conDb._companyName + " URL: " + conDb._website + " Email: " + conDb._email;
                crFHCSSSM.SetParameterValue("_companyNameAddress", compNamAdd);


                int cls = Convert .ToInt32 (comboBox_Class .SelectedValue);
                int sec = Convert.ToInt32(comboBox_Section.SelectedValue);
                int sess = Convert.ToInt32(comboBox_SessionYear.SelectedValue);
                int shift = Convert.ToInt32(comboBox_Shift.SelectedValue);
                int medium = Convert.ToInt32(comboBox_Medium.SelectedValue);
                int academicFeeSum = sumAcademicFee();
                crFHCSSSM.SetParameterValue("_class", cls );
                crFHCSSSM.SetParameterValue("_section", sec);
                crFHCSSSM.SetParameterValue("_session", sess);
                crFHCSSSM.SetParameterValue("_shift", shift);
                crFHCSSSM.SetParameterValue("_medium", medium );
                crFHCSSSM.SetParameterValue("_academicFeeSum", academicFeeSum);

                ConnectionInfo connectionInfo = new ConnectionInfo();
                connectionInfo.Password = "30615aorangikhi75800";
                SetDBLogonForReport(connectionInfo);


                //tabControl_Fee_Report.SelectTab(0);
            }
            catch (Exception Ex)
            {
                //MessageBox.Show("Fee Voucher Not Found, First Create Voucher... ", "Voucher Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show(Convert.ToString(Ex));
            }
        }

        private void Form_Fee_Reports_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Medium' table. You can move, or remove it, as needed.
            this.tbl_MediumTableAdapter.Fill(this.schoolDbDataSet.tbl_Medium);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Shift' table. You can move, or remove it, as needed.
            this.tbl_ShiftTableAdapter.Fill(this.schoolDbDataSet.tbl_Shift);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Session' table. You can move, or remove it, as needed.
            this.tbl_SessionTableAdapter.Fill(this.schoolDbDataSet.tbl_Session);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Section' table. You can move, or remove it, as needed.
            this.tbl_SectionTableAdapter.Fill(this.schoolDbDataSet.tbl_Section);
            // TODO: This line of code loads data into the 'schoolDbDataSet.tbl_Class' table. You can move, or remove it, as needed.
            this.tbl_ClassTableAdapter.Fill(this.schoolDbDataSet.tbl_Class);
            int i = sumAllClassFee() - (sumAllClassCollectedFee() + sumAllClassExemptedFee()) ; 
            label_SumFee.Text = "Total All Class Fee: " + sumAllClassFee() + "   Total Collected Fee: " 
                + sumAllClassCollectedFee() + "   Total Fee Exempted : " + sumAllClassExemptedFee() 
                + "   Total Balance : " + i  + " ";
          
            if (sumAllClassFee() == (sumAllClassCollectedFee() + sumAllClassExemptedFee()))
            {
                checkBox_FeeClosingCompleted.Checked = true;
                UpdateFeeClosingCompletedInTable();
            }

            checkBox_FeeClosingCompleted.Checked = conDb._feeClosed;
        
        }

        private void UpdateFeeClosingCompletedInTable()
        {
            int S_ID = Convert.ToInt32(conDb.returnSessionID());
            OleDbCommand cmdFCC = new OleDbCommand("UPDATE  tbl_Session_Progress_Status SET  FeeClosingCompleted = " + true + " WHERE Session_ID = " + S_ID + "  ", conDb.con);
            conDb.con.Open();
            cmdFCC.ExecuteNonQuery();
            conDb.con.Close();
        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private int sumAcademicFee()
        {
            //Sum Total Academic Fee
            //if (Convert.ToInt32(comboBox_SessionYear .SelectedValue) != DBNull )
            //Convert.ToInt32(comboBox_Class .SelectedValue)

            conDb.con.Open();
            OleDbCommand cmd3 = new OleDbCommand("SELECT SUM(Fee_Amount) AS Expr2 FROM View_Fee HAVING (Session_ID = " + Convert.ToInt32(comboBox_SessionYear .SelectedValue) + ")AND (Class_ID = " + Convert.ToInt32(comboBox_Class .SelectedValue) + ")", conDb.con);
            object returnValueTotalFee;
            returnValueTotalFee = cmd3.ExecuteScalar();
            conDb.con.Close();
            if (returnValueTotalFee != DBNull.Value)
            {
                int i = Convert.ToInt32(returnValueTotalFee);
                return i;
            }
            else { return 0; }
        }

        private int sumAllClassFee()
        {
            int sesId = int.Parse (conDb.returnSessionID());
            //Sum Total Academic Fee
            conDb.con.Open();
            OleDbCommand cmdSum = new OleDbCommand("SELECT SUM(Fee_Amount) AS Expr2 FROM View_Fee HAVING (Session_ID = " + sesId  + ")", conDb.con);
            object returnValueTotalAllClassFee;
            returnValueTotalAllClassFee = cmdSum.ExecuteScalar();
            conDb.con.Close();
            int i = Convert.ToInt32(returnValueTotalAllClassFee);
            return i;
        }
        
        
            private int sumAllClassCollectedFee()
           {
            int sesId = int.Parse (conDb.returnSessionID());
            //Sum Total Academic Fee
            conDb.con.Open();
            OleDbCommand cmdSum = new OleDbCommand("SELECT SUM(Fee_Amount) AS Expr3 FROM View_PaidFee_fromFeeVoucherMasterDetail HAVING (Session_ID = " + sesId + ")", conDb.con);
            object returnValueTotalAllClassCollectFee;
            returnValueTotalAllClassCollectFee = cmdSum.ExecuteScalar();
            conDb.con.Close();
            int i = Convert.ToInt32(returnValueTotalAllClassCollectFee);
            return i;
        }
        
        private int sumAllClassExemptedFee()
        {
            int sesId = int.Parse(conDb.returnSessionID());
            //Sum Total Academic Fee
            conDb.con.Open();
            OleDbCommand cmdSum = new OleDbCommand("SELECT SUM(Fee_Amount) AS Expr4 FROM View_Exempt_Fee_from_ExemptFeeVoucherMasterDetail HAVING (Session_ID = " + sesId + ")", conDb.con);
            object returnValueTotalAllClassExemptFee;
            returnValueTotalAllClassExemptFee = cmdSum.ExecuteScalar();
            conDb.con.Close();
            int i = Convert.ToInt32(returnValueTotalAllClassExemptFee);
            return i;
        }

        private void button_ShowPaidFeeAllClass_Click(object sender, EventArgs e)
        {
            try
            {
               CR_Paid_Fee_Of_All_Class crPFOAC = new CR_Paid_Fee_Of_All_Class();
               crPFOAC.Load("C://SchoolSoft//GeneralSchool//GeneralSchool//CR_Paid_Fee_Of_All_Class.rpt");
               cRViewer_FeeVoucher.ReportSource = crPFOAC;
                cRViewer_FeeVoucher.DisplayToolbar = true;
                cRViewer_FeeVoucher.Zoom(80);
                //crystalReportViewer_VoucherReport.Right;
                crPFOAC.SetParameterValue("schoolName", conDb._schoolName);
                crPFOAC.SetParameterValue("addressSchool", conDb._address);
                crPFOAC.SetParameterValue("phoneSchool", conDb._phone);
                string compNamAdd = conDb._companyName + " URL: " + conDb._website + " Email: " + conDb._email;
                crPFOAC.SetParameterValue("_companyNameAddress", compNamAdd);


                int sess = Convert.ToInt32(comboBox_SessionYear.SelectedValue);
                crPFOAC.SetParameterValue("_session", sess);
                int academicFeeSum = sumAcademicFee();

                crPFOAC.SetParameterValue("_academicFeeSum", academicFeeSum);

                ConnectionInfo connectionInfo = new ConnectionInfo();
                connectionInfo.Password = "30615aorangikhi75800";
                SetDBLogonForReport(connectionInfo);


                //tabControl_Fee_Report.SelectTab(0);
            }
            catch (Exception Ex)
            {
                //MessageBox.Show("Fee Voucher Not Found, First Create Voucher... ", "Voucher Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show(Convert.ToString(Ex));
            }
        }

        private void button_ShowExemptFeeAllClass_Click(object sender, EventArgs e)
        {
            try
            {
               CR_Exempt_Fee_Of_All_Class crEFOAC = new CR_Exempt_Fee_Of_All_Class();
               crEFOAC.Load("C://SchoolSoft//GeneralSchool//GeneralSchool//CR_Exempt_Fee_Of_All_Class.rpt");
               cRViewer_FeeVoucher.ReportSource = crEFOAC;
                cRViewer_FeeVoucher.DisplayToolbar = true;
                cRViewer_FeeVoucher.Zoom(80);
                //crystalReportViewer_VoucherReport.Right;
                crEFOAC.SetParameterValue("schoolName", conDb._schoolName);
                crEFOAC.SetParameterValue("addressSchool", conDb._address);
                crEFOAC.SetParameterValue("phoneSchool", conDb._phone);
                string compNamAdd = conDb._companyName + " URL: " + conDb._website + " Email: " + conDb._email;
                crEFOAC.SetParameterValue("_companyNameAddress", compNamAdd);

                int sess = Convert.ToInt32(comboBox_SessionYear.SelectedValue);
                crEFOAC.SetParameterValue("_session", sess);
                int academicFeeSum = sumAcademicFee();

                crEFOAC.SetParameterValue("_academicFeeSum", academicFeeSum);

                ConnectionInfo connectionInfo = new ConnectionInfo();
                connectionInfo.Password = "30615aorangikhi75800";
                SetDBLogonForReport(connectionInfo);


                //tabControl_Fee_Report.SelectTab(0);
            }
            catch (Exception Ex)
            {
                //MessageBox.Show("Fee Voucher Not Found, First Create Voucher... ", "Voucher Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show(Convert.ToString(Ex));
            }
        }

        private void Form_Fee_Reports_FormClosing(object sender, FormClosingEventArgs e)
        {
            MDIParent_Form.FeeReports = false;
        }


 //CrystalReport_Fee_Voucher_Exemption crFVEx = new CrystalReport_Fee_Voucher_Exemption();
 //           crFVEx.Load("C://SchoolSoft//GeneralSchool//GeneralSchool//CrystalReport_Fee_Voucher_Exemption.rpt");
 //           crystalReportViewer_VoucherReport.ReportSource = crFVEx;
 //           crystalReportViewer_VoucherReport.DisplayToolbar = true;
 //           crystalReportViewer_VoucherReport.Zoom(80);
 //           //crystalReportViewer_VoucherReport.Right;
 //           crFVEx.SetParameterValue("schoolName", conDb._schoolName);
 //           crFVEx.SetParameterValue("addressSchool", conDb._address);
 //           crFVEx.SetParameterValue("phoneSchool", conDb._phone);
 //           int x = int.Parse(exemp_FVM_IDTextBox.Text);
 //           crFVEx.SetParameterValue("FV_Exemp_No", x);
 //           tabControl_GeneralInfo.SelectTab(2);








    }
}


/*
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 *  private void SetDBLogonForReport(ConnectionInfo connectionInfo)
        {
            TableLogOnInfos tableLogOnInfos = crystalReportViewer1.LogOnInfo;
            foreach (TableLogOnInfo tableLogOnInfo in tableLogOnInfos)
            {
                tableLogOnInfo.ConnectionInfo = connectionInfo;
            }
        }
        private void btnFeeReceipt_Click(object sender, EventArgs e)
        {
            // ReportDocument cr = new ReportDocument();
            CR_Fee_Receipt cr = new CR_Fee_Receipt();
            cr.Load("C://Program Files/Dynamic Solutions/SetupSmartOne/DataBase/CR_Fee_Receipt.rpt");
            crystalReportViewer1.ReportSource = cr;
            cr.SetParameterValue("ReceiptID", recpIDComboBox.Text);

            ConnectionInfo connectionInfo = new ConnectionInfo();
            connectionInfo.Password = "adminds";
            SetDBLogonForReport(connectionInfo);

            tabFeeReceipt.SelectTab(3);
        }
 * 
 * 
 * 
*/