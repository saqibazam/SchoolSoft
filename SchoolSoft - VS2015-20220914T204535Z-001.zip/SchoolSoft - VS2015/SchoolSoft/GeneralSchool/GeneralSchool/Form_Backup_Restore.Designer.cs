namespace GeneralSchool
{
    partial class Form_Backup_Restore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_Password = new System.Windows.Forms.TextBox();
            this.cmbUserName = new System.Windows.Forms.ComboBox();
            this.tblUserBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_BackupData = new System.Windows.Forms.Button();
            this.btn_RestoreData = new System.Windows.Forms.Button();
            this.folderBrowserDialog_Backup = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialogBackupDB = new System.Windows.Forms.OpenFileDialog();
            this.tbl_UserTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_UserTableAdapter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.tblUserBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(108, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Password";
            // 
            // textBox_Password
            // 
            this.textBox_Password.ForeColor = System.Drawing.Color.Black;
            this.textBox_Password.Location = new System.Drawing.Point(184, 105);
            this.textBox_Password.Name = "textBox_Password";
            this.textBox_Password.PasswordChar = '*';
            this.textBox_Password.Size = new System.Drawing.Size(141, 21);
            this.textBox_Password.TabIndex = 6;
            this.textBox_Password.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_Password_KeyPress);
            // 
            // cmbUserName
            // 
            this.cmbUserName.DataSource = this.tblUserBindingSource;
            this.cmbUserName.DisplayMember = "uName";
            this.cmbUserName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUserName.ForeColor = System.Drawing.Color.Black;
            this.cmbUserName.FormattingEnabled = true;
            this.cmbUserName.Location = new System.Drawing.Point(184, 65);
            this.cmbUserName.Name = "cmbUserName";
            this.cmbUserName.Size = new System.Drawing.Size(141, 23);
            this.cmbUserName.TabIndex = 8;
            this.cmbUserName.ValueMember = "uID";
            this.cmbUserName.SelectedIndexChanged += new System.EventHandler(this.cmbUserName_SelectedIndexChanged);
            // 
            // tblUserBindingSource
            // 
            this.tblUserBindingSource.DataMember = "tbl_User";
            this.tblUserBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(108, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "User Name";
            // 
            // btn_BackupData
            // 
            this.btn_BackupData.ForeColor = System.Drawing.Color.Black;
            this.btn_BackupData.Image = global::GeneralSchool.Properties.Resources.backup_btn;
            this.btn_BackupData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_BackupData.Location = new System.Drawing.Point(78, 176);
            this.btn_BackupData.Name = "btn_BackupData";
            this.btn_BackupData.Size = new System.Drawing.Size(120, 39);
            this.btn_BackupData.TabIndex = 9;
            this.btn_BackupData.Text = "Backup Data";
            this.btn_BackupData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_BackupData.UseVisualStyleBackColor = true;
            this.btn_BackupData.Click += new System.EventHandler(this.btn_BackupData_Click);
            // 
            // btn_RestoreData
            // 
            this.btn_RestoreData.ForeColor = System.Drawing.Color.Black;
            this.btn_RestoreData.Image = global::GeneralSchool.Properties.Resources.restore_btn;
            this.btn_RestoreData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_RestoreData.Location = new System.Drawing.Point(242, 176);
            this.btn_RestoreData.Name = "btn_RestoreData";
            this.btn_RestoreData.Size = new System.Drawing.Size(123, 39);
            this.btn_RestoreData.TabIndex = 10;
            this.btn_RestoreData.Text = "Restore Data";
            this.btn_RestoreData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_RestoreData.UseVisualStyleBackColor = true;
            this.btn_RestoreData.Click += new System.EventHandler(this.btn_RestoreData_Click);
            // 
            // openFileDialogBackupDB
            // 
            this.openFileDialogBackupDB.FileName = "GS_Archieve.zip";
            // 
            // tbl_UserTableAdapter
            // 
            this.tbl_UserTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox1.Controls.Add(this.cmbUserName);
            this.groupBox1.Controls.Add(this.btn_RestoreData);
            this.groupBox1.Controls.Add(this.btn_BackupData);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox_Password);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(98, 114);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(426, 268);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Backup and Restore Data";
            // 
            // Form_Backup_Restore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 470);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form_Backup_Restore";
            this.Text = "Backup and Restore Data";
            this.Load += new System.EventHandler(this.Form_Backup_Restore_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Backup_Restore_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.tblUserBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_Password;
        private System.Windows.Forms.ComboBox cmbUserName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_BackupData;
        private System.Windows.Forms.Button btn_RestoreData;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_Backup;
        private System.Windows.Forms.OpenFileDialog openFileDialogBackupDB;
        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tblUserBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_UserTableAdapter tbl_UserTableAdapter;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}