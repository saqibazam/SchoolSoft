namespace GeneralSchool
{
    partial class Form_Session
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label session_IDLabel;
            System.Windows.Forms.Label session_DescLabel;
            System.Windows.Forms.Label session_StartLabel;
            System.Windows.Forms.Label session_EndLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Session));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tbl_SessionBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.tbl_SessionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_SessionBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_Edit_Data = new System.Windows.Forms.ToolStripButton();
            this.session_IDTextBox = new System.Windows.Forms.TextBox();
            this.session_DescTextBox = new System.Windows.Forms.TextBox();
            this.session_StartDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.session_EndDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.tbl_SessionDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_SessionProgressStatus = new System.Windows.Forms.DataGridView();
            this.btn_AddSession = new System.Windows.Forms.Button();
            this.tbl_SessionTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SessionTableAdapter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_EnableAddEdit = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SPS_bindingSource = new System.Windows.Forms.BindingSource(this.components);
            session_IDLabel = new System.Windows.Forms.Label();
            session_DescLabel = new System.Windows.Forms.Label();
            session_StartLabel = new System.Windows.Forms.Label();
            session_EndLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SessionBindingNavigator)).BeginInit();
            this.tbl_SessionBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SessionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SessionDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SessionProgressStatus)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SPS_bindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // session_IDLabel
            // 
            session_IDLabel.AutoSize = true;
            session_IDLabel.Location = new System.Drawing.Point(15, 173);
            session_IDLabel.Name = "session_IDLabel";
            session_IDLabel.Size = new System.Drawing.Size(61, 13);
            session_IDLabel.TabIndex = 1;
            session_IDLabel.Text = "Session ID:";
            // 
            // session_DescLabel
            // 
            session_DescLabel.AutoSize = true;
            session_DescLabel.Location = new System.Drawing.Point(15, 199);
            session_DescLabel.Name = "session_DescLabel";
            session_DescLabel.Size = new System.Drawing.Size(75, 13);
            session_DescLabel.TabIndex = 3;
            session_DescLabel.Text = "Session Desc:";
            // 
            // session_StartLabel
            // 
            session_StartLabel.AutoSize = true;
            session_StartLabel.Location = new System.Drawing.Point(15, 226);
            session_StartLabel.Name = "session_StartLabel";
            session_StartLabel.Size = new System.Drawing.Size(72, 13);
            session_StartLabel.TabIndex = 5;
            session_StartLabel.Text = "Session Start:";
            // 
            // session_EndLabel
            // 
            session_EndLabel.AutoSize = true;
            session_EndLabel.Location = new System.Drawing.Point(15, 252);
            session_EndLabel.Name = "session_EndLabel";
            session_EndLabel.Size = new System.Drawing.Size(69, 13);
            session_EndLabel.TabIndex = 7;
            session_EndLabel.Text = "Session End:";
            // 
            // tbl_SessionBindingNavigator
            // 
            this.tbl_SessionBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_SessionBindingNavigator.BindingSource = this.tbl_SessionBindingSource;
            this.tbl_SessionBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_SessionBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_SessionBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.tbl_SessionBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tbl_SessionBindingNavigatorSaveItem,
            this.toolStripButton_Edit_Data});
            this.tbl_SessionBindingNavigator.Location = new System.Drawing.Point(262, 64);
            this.tbl_SessionBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_SessionBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_SessionBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_SessionBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_SessionBindingNavigator.Name = "tbl_SessionBindingNavigator";
            this.tbl_SessionBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_SessionBindingNavigator.Size = new System.Drawing.Size(427, 25);
            this.tbl_SessionBindingNavigator.TabIndex = 0;
            this.tbl_SessionBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(69, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // tbl_SessionBindingSource
            // 
            this.tbl_SessionBindingSource.DataMember = "tbl_Session";
            this.tbl_SessionBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Enabled = false;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.ReadOnly = true;
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_SessionBindingNavigatorSaveItem
            // 
            this.tbl_SessionBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_SessionBindingNavigatorSaveItem.Image")));
            this.tbl_SessionBindingNavigatorSaveItem.Name = "tbl_SessionBindingNavigatorSaveItem";
            this.tbl_SessionBindingNavigatorSaveItem.Size = new System.Drawing.Size(77, 22);
            this.tbl_SessionBindingNavigatorSaveItem.Text = "Save Data";
            this.tbl_SessionBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_SessionBindingNavigatorSaveItem_Click);
            // 
            // toolStripButton_Edit_Data
            // 
            this.toolStripButton_Edit_Data.Image = global::GeneralSchool.Properties.Resources.edit;
            this.toolStripButton_Edit_Data.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_Edit_Data.Name = "toolStripButton_Edit_Data";
            this.toolStripButton_Edit_Data.Size = new System.Drawing.Size(71, 22);
            this.toolStripButton_Edit_Data.Text = "Edit Data";
            this.toolStripButton_Edit_Data.Click += new System.EventHandler(this.toolStripButton_Edit_Data_Click);
            // 
            // session_IDTextBox
            // 
            this.session_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SessionBindingSource, "Session_ID", true));
            this.session_IDTextBox.Enabled = false;
            this.session_IDTextBox.Location = new System.Drawing.Point(96, 170);
            this.session_IDTextBox.Name = "session_IDTextBox";
            this.session_IDTextBox.Size = new System.Drawing.Size(52, 20);
            this.session_IDTextBox.TabIndex = 2;
            // 
            // session_DescTextBox
            // 
            this.session_DescTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_SessionBindingSource, "Session_Desc", true));
            this.session_DescTextBox.Location = new System.Drawing.Point(96, 196);
            this.session_DescTextBox.Name = "session_DescTextBox";
            this.session_DescTextBox.Size = new System.Drawing.Size(97, 20);
            this.session_DescTextBox.TabIndex = 4;
            // 
            // session_StartDateTimePicker
            // 
            this.session_StartDateTimePicker.CustomFormat = "dd-MMM-yyyy";
            this.session_StartDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tbl_SessionBindingSource, "Session_Start", true));
            this.session_StartDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.session_StartDateTimePicker.Location = new System.Drawing.Point(96, 222);
            this.session_StartDateTimePicker.Name = "session_StartDateTimePicker";
            this.session_StartDateTimePicker.Size = new System.Drawing.Size(97, 20);
            this.session_StartDateTimePicker.TabIndex = 6;
            // 
            // session_EndDateTimePicker
            // 
            this.session_EndDateTimePicker.CustomFormat = "dd-MMM-yyyy";
            this.session_EndDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tbl_SessionBindingSource, "Session_End", true));
            this.session_EndDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.session_EndDateTimePicker.Location = new System.Drawing.Point(96, 248);
            this.session_EndDateTimePicker.Name = "session_EndDateTimePicker";
            this.session_EndDateTimePicker.Size = new System.Drawing.Size(97, 20);
            this.session_EndDateTimePicker.TabIndex = 8;
            // 
            // tbl_SessionDataGridView
            // 
            this.tbl_SessionDataGridView.AllowUserToAddRows = false;
            this.tbl_SessionDataGridView.AllowUserToDeleteRows = false;
            this.tbl_SessionDataGridView.AllowUserToResizeColumns = false;
            this.tbl_SessionDataGridView.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tbl_SessionDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.tbl_SessionDataGridView.AutoGenerateColumns = false;
            this.tbl_SessionDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.tbl_SessionDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.tbl_SessionDataGridView.DataSource = this.tbl_SessionBindingSource;
            this.tbl_SessionDataGridView.Location = new System.Drawing.Point(262, 96);
            this.tbl_SessionDataGridView.Name = "tbl_SessionDataGridView";
            this.tbl_SessionDataGridView.ReadOnly = true;
            this.tbl_SessionDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.tbl_SessionDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tbl_SessionDataGridView.Size = new System.Drawing.Size(455, 172);
            this.tbl_SessionDataGridView.TabIndex = 9;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Session_ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "Session ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Session_Desc";
            this.dataGridViewTextBoxColumn2.HeaderText = "Session Desc";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Session_Start";
            this.dataGridViewTextBoxColumn3.HeaderText = "Session Start";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Session_End";
            this.dataGridViewTextBoxColumn4.HeaderText = "Session End";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dgv_SessionProgressStatus
            // 
            this.dgv_SessionProgressStatus.AllowUserToAddRows = false;
            this.dgv_SessionProgressStatus.AllowUserToDeleteRows = false;
            this.dgv_SessionProgressStatus.AllowUserToResizeColumns = false;
            this.dgv_SessionProgressStatus.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dgv_SessionProgressStatus.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_SessionProgressStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgv_SessionProgressStatus.Location = new System.Drawing.Point(18, 19);
            this.dgv_SessionProgressStatus.Name = "dgv_SessionProgressStatus";
            this.dgv_SessionProgressStatus.ReadOnly = true;
            this.dgv_SessionProgressStatus.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgv_SessionProgressStatus.Size = new System.Drawing.Size(661, 127);
            this.dgv_SessionProgressStatus.TabIndex = 10;
            // 
            // btn_AddSession
            // 
            this.btn_AddSession.Image = global::GeneralSchool.Properties.Resources.update;
            this.btn_AddSession.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AddSession.Location = new System.Drawing.Point(18, 152);
            this.btn_AddSession.Name = "btn_AddSession";
            this.btn_AddSession.Size = new System.Drawing.Size(198, 45);
            this.btn_AddSession.TabIndex = 11;
            this.btn_AddSession.Text = "Update Session Progress Status";
            this.btn_AddSession.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_AddSession.UseVisualStyleBackColor = true;
            this.btn_AddSession.Click += new System.EventHandler(this.btn_AddSession_Click);
            // 
            // tbl_SessionTableAdapter
            // 
            this.tbl_SessionTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.button_EnableAddEdit);
            this.groupBox1.Controls.Add(session_IDLabel);
            this.groupBox1.Controls.Add(this.session_EndDateTimePicker);
            this.groupBox1.Controls.Add(session_EndLabel);
            this.groupBox1.Controls.Add(this.tbl_SessionDataGridView);
            this.groupBox1.Controls.Add(this.session_StartDateTimePicker);
            this.groupBox1.Controls.Add(session_StartLabel);
            this.groupBox1.Controls.Add(this.tbl_SessionBindingNavigator);
            this.groupBox1.Controls.Add(this.session_DescTextBox);
            this.groupBox1.Controls.Add(this.session_IDTextBox);
            this.groupBox1.Controls.Add(session_DescLabel);
            this.groupBox1.Location = new System.Drawing.Point(12, 90);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(765, 286);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add New Session";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(15, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(229, 52);
            this.label2.TabIndex = 12;
            this.label2.Text = "This button will be enable automatically, When \r\nAcademic Year Fee Balance will b" +
                "e Zero.\r\nFor checking Fee Balance Go to Fee Reports\r\nin Reports Menu.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(15, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(455, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "NOTE: You can not create new Session untill the Academic Year Fee Balance will no" +
                "t be Zero.";
            // 
            // button_EnableAddEdit
            // 
            this.button_EnableAddEdit.Image = global::GeneralSchool.Properties.Resources.enable_add_edit;
            this.button_EnableAddEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_EnableAddEdit.Location = new System.Drawing.Point(18, 47);
            this.button_EnableAddEdit.Name = "button_EnableAddEdit";
            this.button_EnableAddEdit.Size = new System.Drawing.Size(130, 42);
            this.button_EnableAddEdit.TabIndex = 10;
            this.button_EnableAddEdit.Text = "Enable Add Edit";
            this.button_EnableAddEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button_EnableAddEdit.UseVisualStyleBackColor = true;
            this.button_EnableAddEdit.Click += new System.EventHandler(this.button_EnableAddEdit_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.dgv_SessionProgressStatus);
            this.groupBox2.Controls.Add(this.btn_AddSession);
            this.groupBox2.Location = new System.Drawing.Point(12, 382);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(765, 208);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Session Progress Status";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(248, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(338, 26);
            this.label3.TabIndex = 13;
            this.label3.Text = "After Create New Session, Click this button to Update Session Status, \r\nyou can a" +
                "lso check the after End Session status. ";
            // 
            // Form_Session
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(974, 746);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form_Session";
            this.Text = "Add New Session";
            this.Load += new System.EventHandler(this.Form_Session_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Session_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SessionBindingNavigator)).EndInit();
            this.tbl_SessionBindingNavigator.ResumeLayout(false);
            this.tbl_SessionBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SessionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_SessionDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SessionProgressStatus)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SPS_bindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tbl_SessionBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SessionTableAdapter tbl_SessionTableAdapter;
        private System.Windows.Forms.BindingNavigator tbl_SessionBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_SessionBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox session_IDTextBox;
        private System.Windows.Forms.TextBox session_DescTextBox;
        private System.Windows.Forms.DateTimePicker session_StartDateTimePicker;
        private System.Windows.Forms.DateTimePicker session_EndDateTimePicker;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridView tbl_SessionDataGridView;
        private System.Windows.Forms.DataGridView dgv_SessionProgressStatus;
        private System.Windows.Forms.BindingSource SPS_bindingSource;
        private System.Windows.Forms.Button btn_AddSession;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_EnableAddEdit;
        private System.Windows.Forms.ToolStripButton toolStripButton_Edit_Data;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}