namespace GeneralSchool
{
    partial class Form_NewStudent_Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label st_Mov_IDLabel;
            System.Windows.Forms.Label gR_NoLabel1;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label result_IDLabel;
            System.Windows.Forms.Label student_IDLabel;
            System.Windows.Forms.Label label8;
            System.Windows.Forms.Label rollLabel;
            System.Windows.Forms.Label gR_NoLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_NewStudent_Registration));
            this.schoolDbDataSet = new GeneralSchool.SchoolDbDataSet();
            this.tbl_Student_MasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_Student_MasterTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Student_MasterTableAdapter();
            this.tbl_Student_MovementBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_Student_MovementTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Student_MovementTableAdapter();
            this.st_Mov_IDTextBox = new System.Windows.Forms.TextBox();
            this.gR_NoTextBox1 = new System.Windows.Forms.TextBox();
            this.tblResultBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbl_ResultTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ResultTableAdapter();
            this.notRegStudent_bindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dvg_NotRegisteredStudent = new System.Windows.Forms.DataGridView();
            this.searchByClassComboBox = new System.Windows.Forms.ComboBox();
            this.tblSMCSDefineBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnFindStudent = new System.Windows.Forms.Button();
            this.label_SMCS_ID = new System.Windows.Forms.Label();
            this.label_SessionID = new System.Windows.Forms.Label();
            this.dgv_RegisteredStudent = new System.Windows.Forms.DataGridView();
            this.regStudent_bindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox3_Result = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label19_resultID = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2_Class_Capacity = new System.Windows.Forms.Label();
            this.label4_MaxRoll = new System.Windows.Forms.Label();
            this.label18_Total_Student = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2_ClassID = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbl_Student_MasterBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tbl_Student_MasterBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_Edit = new System.Windows.Forms.ToolStripButton();
            this.BtnUpdate = new System.Windows.Forms.ToolStripButton();
            this.gR_NoTextBox = new System.Windows.Forms.TextBox();
            this.label18_Test_Percent = new System.Windows.Forms.Label();
            this.percentageTextBox = new System.Windows.Forms.TextBox();
            this.label19_Result = new System.Windows.Forms.Label();
            this.rollTextBox = new System.Windows.Forms.TextBox();
            this.label3_St_ID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label_StudentName = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label_Class_Detail = new System.Windows.Forms.Label();
            this.label_FatherName = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label_SessionDesc = new System.Windows.Forms.Label();
            this.label_Gender = new System.Windows.Forms.Label();
            this.label_AdmissionDate = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.smcsd_IDTextBox = new System.Windows.Forms.TextBox();
            this.result_IDTextBox = new System.Windows.Forms.TextBox();
            this.session_IDTextBox = new System.Windows.Forms.TextBox();
            this.student_IDTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbl_SMCS_DefineTableAdapter = new GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SMCS_DefineTableAdapter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            st_Mov_IDLabel = new System.Windows.Forms.Label();
            gR_NoLabel1 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            result_IDLabel = new System.Windows.Forms.Label();
            student_IDLabel = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            rollLabel = new System.Windows.Forms.Label();
            gR_NoLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Student_MasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Student_MovementBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblResultBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.notRegStudent_bindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dvg_NotRegisteredStudent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSMCSDefineBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_RegisteredStudent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.regStudent_bindingSource)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Student_MasterBindingNavigator)).BeginInit();
            this.tbl_Student_MasterBindingNavigator.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // st_Mov_IDLabel
            // 
            st_Mov_IDLabel.AutoSize = true;
            st_Mov_IDLabel.Location = new System.Drawing.Point(106, 410);
            st_Mov_IDLabel.Name = "st_Mov_IDLabel";
            st_Mov_IDLabel.Size = new System.Drawing.Size(58, 13);
            st_Mov_IDLabel.TabIndex = 5;
            st_Mov_IDLabel.Text = "St Mov ID:";
            // 
            // gR_NoLabel1
            // 
            gR_NoLabel1.AutoSize = true;
            gR_NoLabel1.Location = new System.Drawing.Point(202, 410);
            gR_NoLabel1.Name = "gR_NoLabel1";
            gR_NoLabel1.Size = new System.Drawing.Size(43, 13);
            gR_NoLabel1.TabIndex = 7;
            gR_NoLabel1.Text = "GR No:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label5.ForeColor = System.Drawing.SystemColors.WindowText;
            label5.Location = new System.Drawing.Point(163, 16);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(88, 13);
            label5.TabIndex = 31;
            label5.Text = "Register in Class:";
            // 
            // result_IDLabel
            // 
            result_IDLabel.AutoSize = true;
            result_IDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            result_IDLabel.Location = new System.Drawing.Point(30, 199);
            result_IDLabel.Name = "result_IDLabel";
            result_IDLabel.Size = new System.Drawing.Size(64, 13);
            result_IDLabel.TabIndex = 114;
            result_IDLabel.Text = "Test Result:";
            // 
            // student_IDLabel
            // 
            student_IDLabel.AutoSize = true;
            student_IDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            student_IDLabel.Location = new System.Drawing.Point(165, 62);
            student_IDLabel.Name = "student_IDLabel";
            student_IDLabel.Size = new System.Drawing.Size(61, 13);
            student_IDLabel.TabIndex = 94;
            student_IDLabel.Text = "Student ID:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label8.Location = new System.Drawing.Point(24, 232);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(69, 13);
            label8.TabIndex = 90;
            label8.Text = "Last Class %:";
            // 
            // rollLabel
            // 
            rollLabel.AutoSize = true;
            rollLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            rollLabel.Location = new System.Drawing.Point(23, 265);
            rollLabel.Name = "rollLabel";
            rollLabel.Size = new System.Drawing.Size(68, 13);
            rollLabel.TabIndex = 88;
            rollLabel.Text = "Roll Number:";
            // 
            // gR_NoLabel
            // 
            gR_NoLabel.AutoSize = true;
            gR_NoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            gR_NoLabel.Location = new System.Drawing.Point(57, 62);
            gR_NoLabel.Name = "gR_NoLabel";
            gR_NoLabel.Size = new System.Drawing.Size(43, 13);
            gR_NoLabel.TabIndex = 85;
            gR_NoLabel.Text = "GR No:";
            // 
            // schoolDbDataSet
            // 
            this.schoolDbDataSet.DataSetName = "SchoolDbDataSet";
            this.schoolDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_Student_MasterBindingSource
            // 
            this.tbl_Student_MasterBindingSource.DataMember = "tbl_Student_Master";
            this.tbl_Student_MasterBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tbl_Student_MasterTableAdapter
            // 
            this.tbl_Student_MasterTableAdapter.ClearBeforeFill = true;
            // 
            // tbl_Student_MovementBindingSource
            // 
            this.tbl_Student_MovementBindingSource.DataMember = "tbl_Student_Mastertbl_Student_Movement";
            this.tbl_Student_MovementBindingSource.DataSource = this.tbl_Student_MasterBindingSource;
            // 
            // tbl_Student_MovementTableAdapter
            // 
            this.tbl_Student_MovementTableAdapter.ClearBeforeFill = true;
            // 
            // st_Mov_IDTextBox
            // 
            this.st_Mov_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Student_MovementBindingSource, "St_Mov_ID", true));
            this.st_Mov_IDTextBox.Location = new System.Drawing.Point(170, 407);
            this.st_Mov_IDTextBox.Name = "st_Mov_IDTextBox";
            this.st_Mov_IDTextBox.Size = new System.Drawing.Size(26, 20);
            this.st_Mov_IDTextBox.TabIndex = 6;
            // 
            // gR_NoTextBox1
            // 
            this.gR_NoTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Student_MovementBindingSource, "GR_No", true));
            this.gR_NoTextBox1.Location = new System.Drawing.Point(258, 407);
            this.gR_NoTextBox1.Name = "gR_NoTextBox1";
            this.gR_NoTextBox1.Size = new System.Drawing.Size(42, 20);
            this.gR_NoTextBox1.TabIndex = 8;
            // 
            // tblResultBindingSource
            // 
            this.tblResultBindingSource.DataMember = "tbl_Result";
            this.tblResultBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // tbl_ResultTableAdapter
            // 
            this.tbl_ResultTableAdapter.ClearBeforeFill = true;
            // 
            // dvg_NotRegisteredStudent
            // 
            this.dvg_NotRegisteredStudent.AllowUserToAddRows = false;
            this.dvg_NotRegisteredStudent.AllowUserToDeleteRows = false;
            this.dvg_NotRegisteredStudent.AllowUserToResizeColumns = false;
            this.dvg_NotRegisteredStudent.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dvg_NotRegisteredStudent.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dvg_NotRegisteredStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dvg_NotRegisteredStudent.Cursor = System.Windows.Forms.Cursors.Default;
            this.dvg_NotRegisteredStudent.Location = new System.Drawing.Point(10, 19);
            this.dvg_NotRegisteredStudent.MultiSelect = false;
            this.dvg_NotRegisteredStudent.Name = "dvg_NotRegisteredStudent";
            this.dvg_NotRegisteredStudent.ReadOnly = true;
            this.dvg_NotRegisteredStudent.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dvg_NotRegisteredStudent.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dvg_NotRegisteredStudent.Size = new System.Drawing.Size(724, 125);
            this.dvg_NotRegisteredStudent.TabIndex = 41;
            this.dvg_NotRegisteredStudent.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvg_NotRegisteredStudent_CellClick);
            // 
            // searchByClassComboBox
            // 
            this.searchByClassComboBox.DataSource = this.tblSMCSDefineBindingSource;
            this.searchByClassComboBox.DisplayMember = "Class_Detail";
            this.searchByClassComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.searchByClassComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchByClassComboBox.FormattingEnabled = true;
            this.searchByClassComboBox.Location = new System.Drawing.Point(166, 32);
            this.searchByClassComboBox.Name = "searchByClassComboBox";
            this.searchByClassComboBox.Size = new System.Drawing.Size(385, 21);
            this.searchByClassComboBox.TabIndex = 46;
            this.searchByClassComboBox.ValueMember = "Smcsd_ID";
            this.searchByClassComboBox.SelectedIndexChanged += new System.EventHandler(this.searchByClassComboBox_SelectedIndexChanged);
            // 
            // tblSMCSDefineBindingSource
            // 
            this.tblSMCSDefineBindingSource.DataMember = "tbl_SMCS_Define";
            this.tblSMCSDefineBindingSource.DataSource = this.schoolDbDataSet;
            // 
            // btnFindStudent
            // 
            this.btnFindStudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindStudent.ForeColor = System.Drawing.Color.Black;
            this.btnFindStudent.Image = global::GeneralSchool.Properties.Resources.search2;
            this.btnFindStudent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFindStudent.Location = new System.Drawing.Point(593, 19);
            this.btnFindStudent.Name = "btnFindStudent";
            this.btnFindStudent.Size = new System.Drawing.Size(141, 43);
            this.btnFindStudent.TabIndex = 50;
            this.btnFindStudent.Text = "Show Students";
            this.btnFindStudent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnFindStudent.UseVisualStyleBackColor = true;
            this.btnFindStudent.Click += new System.EventHandler(this.btnFindStudent_Click);
            // 
            // label_SMCS_ID
            // 
            this.label_SMCS_ID.AutoSize = true;
            this.label_SMCS_ID.Location = new System.Drawing.Point(250, 439);
            this.label_SMCS_ID.Name = "label_SMCS_ID";
            this.label_SMCS_ID.Size = new System.Drawing.Size(50, 13);
            this.label_SMCS_ID.TabIndex = 51;
            this.label_SMCS_ID.Text = "Smcs_ID";
            // 
            // label_SessionID
            // 
            this.label_SessionID.AutoSize = true;
            this.label_SessionID.Location = new System.Drawing.Point(35, 410);
            this.label_SessionID.Name = "label_SessionID";
            this.label_SessionID.Size = new System.Drawing.Size(55, 13);
            this.label_SessionID.TabIndex = 61;
            this.label_SessionID.Text = "SessionID";
            // 
            // dgv_RegisteredStudent
            // 
            this.dgv_RegisteredStudent.AllowUserToAddRows = false;
            this.dgv_RegisteredStudent.AllowUserToDeleteRows = false;
            this.dgv_RegisteredStudent.AllowUserToResizeColumns = false;
            this.dgv_RegisteredStudent.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dgv_RegisteredStudent.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_RegisteredStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgv_RegisteredStudent.Location = new System.Drawing.Point(12, 20);
            this.dgv_RegisteredStudent.Name = "dgv_RegisteredStudent";
            this.dgv_RegisteredStudent.ReadOnly = true;
            this.dgv_RegisteredStudent.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgv_RegisteredStudent.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_RegisteredStudent.Size = new System.Drawing.Size(722, 175);
            this.dgv_RegisteredStudent.TabIndex = 68;
            // 
            // comboBox3_Result
            // 
            this.comboBox3_Result.DataSource = this.tblResultBindingSource;
            this.comboBox3_Result.DisplayMember = "Result_Desc";
            this.comboBox3_Result.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3_Result.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3_Result.FormattingEnabled = true;
            this.comboBox3_Result.Location = new System.Drawing.Point(33, 32);
            this.comboBox3_Result.Name = "comboBox3_Result";
            this.comboBox3_Result.Size = new System.Drawing.Size(73, 21);
            this.comboBox3_Result.TabIndex = 71;
            this.comboBox3_Result.ValueMember = "Result_ID";
            this.comboBox3_Result.SelectedIndexChanged += new System.EventHandler(this.comboBox3_Result_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label16.Location = new System.Drawing.Point(30, 16);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 13);
            this.label16.TabIndex = 74;
            this.label16.Text = "Test Result:";
            // 
            // label19_resultID
            // 
            this.label19_resultID.AutoSize = true;
            this.label19_resultID.Location = new System.Drawing.Point(192, 439);
            this.label19_resultID.Name = "label19_resultID";
            this.label19_resultID.Size = new System.Drawing.Size(43, 13);
            this.label19_resultID.TabIndex = 77;
            this.label19_resultID.Text = "resultID";
            this.label19_resultID.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(6, 19);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(798, 531);
            this.tabControl1.TabIndex = 83;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.label2_ClassID);
            this.tabPage1.Controls.Add(this.label_SessionID);
            this.tabPage1.Controls.Add(this.st_Mov_IDTextBox);
            this.tabPage1.Controls.Add(this.gR_NoTextBox1);
            this.tabPage1.Controls.Add(gR_NoLabel1);
            this.tabPage1.Controls.Add(st_Mov_IDLabel);
            this.tabPage1.Controls.Add(this.label_SMCS_ID);
            this.tabPage1.Controls.Add(this.label19_resultID);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(790, 505);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Find Student";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkRed;
            this.label4.Location = new System.Drawing.Point(11, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(688, 26);
            this.label4.TabIndex = 92;
            this.label4.Text = "Select Register in Class Drop Down List from Selection Criteria and Click on Show" +
                " Students button, For Student Registration, Select a Student in \r\nUn-Registered " +
                "Students View and Click this Student.";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnFindStudent);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.comboBox3_Result);
            this.groupBox4.Controls.Add(this.searchByClassComboBox);
            this.groupBox4.Controls.Add(label5);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(17, 48);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(751, 69);
            this.groupBox4.TabIndex = 142;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Selection Criteria";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgv_RegisteredStudent);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2_Class_Capacity);
            this.groupBox3.Controls.Add(this.label4_MaxRoll);
            this.groupBox3.Controls.Add(this.label18_Total_Student);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(17, 278);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(751, 220);
            this.groupBox3.TabIndex = 42;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Registered Students";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(9, 198);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(132, 13);
            this.label17.TabIndex = 136;
            this.label17.Text = "Total Student in this Class:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(310, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 140;
            this.label2.Text = "Seating Capacity:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(590, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 13);
            this.label3.TabIndex = 134;
            this.label3.Text = "Last Roll in this Class:";
            // 
            // label2_Class_Capacity
            // 
            this.label2_Class_Capacity.AutoSize = true;
            this.label2_Class_Capacity.BackColor = System.Drawing.SystemColors.Desktop;
            this.label2_Class_Capacity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2_Class_Capacity.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2_Class_Capacity.Location = new System.Drawing.Point(405, 198);
            this.label2_Class_Capacity.Name = "label2_Class_Capacity";
            this.label2_Class_Capacity.Size = new System.Drawing.Size(13, 13);
            this.label2_Class_Capacity.TabIndex = 139;
            this.label2_Class_Capacity.Text = "0";
            // 
            // label4_MaxRoll
            // 
            this.label4_MaxRoll.AutoSize = true;
            this.label4_MaxRoll.BackColor = System.Drawing.SystemColors.Desktop;
            this.label4_MaxRoll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4_MaxRoll.ForeColor = System.Drawing.Color.White;
            this.label4_MaxRoll.Location = new System.Drawing.Point(704, 198);
            this.label4_MaxRoll.Name = "label4_MaxRoll";
            this.label4_MaxRoll.Size = new System.Drawing.Size(13, 13);
            this.label4_MaxRoll.TabIndex = 135;
            this.label4_MaxRoll.Text = "0";
            // 
            // label18_Total_Student
            // 
            this.label18_Total_Student.AutoSize = true;
            this.label18_Total_Student.BackColor = System.Drawing.SystemColors.Desktop;
            this.label18_Total_Student.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18_Total_Student.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label18_Total_Student.Location = new System.Drawing.Point(145, 198);
            this.label18_Total_Student.Name = "label18_Total_Student";
            this.label18_Total_Student.Size = new System.Drawing.Size(13, 13);
            this.label18_Total_Student.TabIndex = 137;
            this.label18_Total_Student.Text = "0";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dvg_NotRegisteredStudent);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(17, 122);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(751, 152);
            this.groupBox2.TabIndex = 141;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Un-Registered Students";
            // 
            // label2_ClassID
            // 
            this.label2_ClassID.AutoSize = true;
            this.label2_ClassID.Location = new System.Drawing.Point(318, 410);
            this.label2_ClassID.Name = "label2_ClassID";
            this.label2_ClassID.Size = new System.Drawing.Size(42, 13);
            this.label2_ClassID.TabIndex = 138;
            this.label2_ClassID.Text = "classID";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.smcsd_IDTextBox);
            this.tabPage2.Controls.Add(this.result_IDTextBox);
            this.tabPage2.Controls.Add(this.session_IDTextBox);
            this.tabPage2.Controls.Add(this.student_IDTextBox);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(790, 505);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Register Student";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.tbl_Student_MasterBindingNavigator);
            this.groupBox5.Controls.Add(this.gR_NoTextBox);
            this.groupBox5.Controls.Add(this.label18_Test_Percent);
            this.groupBox5.Controls.Add(label8);
            this.groupBox5.Controls.Add(this.percentageTextBox);
            this.groupBox5.Controls.Add(gR_NoLabel);
            this.groupBox5.Controls.Add(rollLabel);
            this.groupBox5.Controls.Add(this.label19_Result);
            this.groupBox5.Controls.Add(this.rollTextBox);
            this.groupBox5.Controls.Add(student_IDLabel);
            this.groupBox5.Controls.Add(this.label3_St_ID);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(result_IDLabel);
            this.groupBox5.Controls.Add(this.label_StudentName);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label_Class_Detail);
            this.groupBox5.Controls.Add(this.label_FatherName);
            this.groupBox5.Controls.Add(this.label111);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label_SessionDesc);
            this.groupBox5.Controls.Add(this.label_Gender);
            this.groupBox5.Controls.Add(this.label_AdmissionDate);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Location = new System.Drawing.Point(22, 47);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(689, 348);
            this.groupBox5.TabIndex = 134;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Student Registration Detail";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(230, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 108;
            this.label6.Text = "Session Year:";
            // 
            // tbl_Student_MasterBindingNavigator
            // 
            this.tbl_Student_MasterBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tbl_Student_MasterBindingNavigator.BindingSource = this.tbl_Student_MasterBindingSource;
            this.tbl_Student_MasterBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tbl_Student_MasterBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tbl_Student_MasterBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.tbl_Student_MasterBindingNavigator.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbl_Student_MasterBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.toolStripSeparator1,
            this.tbl_Student_MasterBindingNavigatorSaveItem,
            this.toolStripSeparator2,
            this.btn_Edit,
            this.BtnUpdate});
            this.tbl_Student_MasterBindingNavigator.Location = new System.Drawing.Point(25, 298);
            this.tbl_Student_MasterBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tbl_Student_MasterBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tbl_Student_MasterBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tbl_Student_MasterBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tbl_Student_MasterBindingNavigator.Name = "tbl_Student_MasterBindingNavigator";
            this.tbl_Student_MasterBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tbl_Student_MasterBindingNavigator.Size = new System.Drawing.Size(606, 25);
            this.tbl_Student_MasterBindingNavigator.TabIndex = 84;
            this.tbl_Student_MasterBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(122, 22);
            this.bindingNavigatorAddNewItem.Text = "Assign New GR No.";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click_1);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(33, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.ReadOnly = true;
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tbl_Student_MasterBindingNavigatorSaveItem
            // 
            this.tbl_Student_MasterBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tbl_Student_MasterBindingNavigatorSaveItem.Image")));
            this.tbl_Student_MasterBindingNavigatorSaveItem.Name = "tbl_Student_MasterBindingNavigatorSaveItem";
            this.tbl_Student_MasterBindingNavigatorSaveItem.Size = new System.Drawing.Size(106, 22);
            this.tbl_Student_MasterBindingNavigatorSaveItem.Text = "Register Student";
            this.tbl_Student_MasterBindingNavigatorSaveItem.Click += new System.EventHandler(this.tbl_Student_MasterBindingNavigatorSaveItem_Click_1);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // btn_Edit
            // 
            this.btn_Edit.Image = global::GeneralSchool.Properties.Resources.edit;
            this.btn_Edit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Edit.Name = "btn_Edit";
            this.btn_Edit.Size = new System.Drawing.Size(71, 22);
            this.btn_Edit.Text = "Edit Data";
            this.btn_Edit.Click += new System.EventHandler(this.btn_Edit_Click);
            // 
            // BtnUpdate
            // 
            this.BtnUpdate.Image = global::GeneralSchool.Properties.Resources.update;
            this.BtnUpdate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnUpdate.Name = "BtnUpdate";
            this.BtnUpdate.Size = new System.Drawing.Size(88, 22);
            this.BtnUpdate.Text = "Update Data";
            this.BtnUpdate.Click += new System.EventHandler(this.BtnUpdate_Click_1);
            // 
            // gR_NoTextBox
            // 
            this.gR_NoTextBox.BackColor = System.Drawing.SystemColors.Desktop;
            this.gR_NoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Student_MasterBindingSource, "GR_No", true));
            this.gR_NoTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gR_NoTextBox.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.gR_NoTextBox.Location = new System.Drawing.Point(110, 57);
            this.gR_NoTextBox.Name = "gR_NoTextBox";
            this.gR_NoTextBox.Size = new System.Drawing.Size(43, 20);
            this.gR_NoTextBox.TabIndex = 83;
            this.gR_NoTextBox.TextChanged += new System.EventHandler(this.gR_NoTextBox_TextChanged);
            // 
            // label18_Test_Percent
            // 
            this.label18_Test_Percent.AutoSize = true;
            this.label18_Test_Percent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18_Test_Percent.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label18_Test_Percent.Location = new System.Drawing.Point(170, 200);
            this.label18_Test_Percent.Name = "label18_Test_Percent";
            this.label18_Test_Percent.Size = new System.Drawing.Size(36, 13);
            this.label18_Test_Percent.TabIndex = 132;
            this.label18_Test_Percent.Text = "Test%";
            this.label18_Test_Percent.Visible = false;
            // 
            // percentageTextBox
            // 
            this.percentageTextBox.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.percentageTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Student_MovementBindingSource, "Percentage", true));
            this.percentageTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.percentageTextBox.ForeColor = System.Drawing.SystemColors.WindowText;
            this.percentageTextBox.Location = new System.Drawing.Point(110, 229);
            this.percentageTextBox.Name = "percentageTextBox";
            this.percentageTextBox.Size = new System.Drawing.Size(43, 20);
            this.percentageTextBox.TabIndex = 86;
            // 
            // label19_Result
            // 
            this.label19_Result.AutoSize = true;
            this.label19_Result.BackColor = System.Drawing.SystemColors.Desktop;
            this.label19_Result.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19_Result.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label19_Result.Location = new System.Drawing.Point(110, 200);
            this.label19_Result.Name = "label19_Result";
            this.label19_Result.Size = new System.Drawing.Size(41, 13);
            this.label19_Result.TabIndex = 123;
            this.label19_Result.Text = "label19";
            // 
            // rollTextBox
            // 
            this.rollTextBox.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.rollTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Student_MovementBindingSource, "Roll", true));
            this.rollTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rollTextBox.ForeColor = System.Drawing.SystemColors.WindowText;
            this.rollTextBox.Location = new System.Drawing.Point(110, 264);
            this.rollTextBox.Name = "rollTextBox";
            this.rollTextBox.Size = new System.Drawing.Size(43, 20);
            this.rollTextBox.TabIndex = 87;
            // 
            // label3_St_ID
            // 
            this.label3_St_ID.AutoSize = true;
            this.label3_St_ID.BackColor = System.Drawing.SystemColors.Desktop;
            this.label3_St_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3_St_ID.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3_St_ID.Location = new System.Drawing.Point(234, 62);
            this.label3_St_ID.Name = "label3_St_ID";
            this.label3_St_ID.Size = new System.Drawing.Size(28, 13);
            this.label3_St_ID.TabIndex = 117;
            this.label3_St_ID.Text = "StID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 96;
            this.label1.Text = "Student Name:";
            // 
            // label_StudentName
            // 
            this.label_StudentName.AutoSize = true;
            this.label_StudentName.BackColor = System.Drawing.SystemColors.Desktop;
            this.label_StudentName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_StudentName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_StudentName.Location = new System.Drawing.Point(110, 95);
            this.label_StudentName.Name = "label_StudentName";
            this.label_StudentName.Size = new System.Drawing.Size(78, 13);
            this.label_StudentName.TabIndex = 97;
            this.label_StudentName.Text = "Student Name:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(23, 129);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 13);
            this.label10.TabIndex = 98;
            this.label10.Text = "Father Name:";
            // 
            // label_Class_Detail
            // 
            this.label_Class_Detail.AutoSize = true;
            this.label_Class_Detail.BackColor = System.Drawing.SystemColors.Desktop;
            this.label_Class_Detail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Class_Detail.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_Class_Detail.Location = new System.Drawing.Point(110, 166);
            this.label_Class_Detail.Name = "label_Class_Detail";
            this.label_Class_Detail.Size = new System.Drawing.Size(59, 13);
            this.label_Class_Detail.TabIndex = 107;
            this.label_Class_Detail.Text = "ClassDetail";
            // 
            // label_FatherName
            // 
            this.label_FatherName.AutoSize = true;
            this.label_FatherName.BackColor = System.Drawing.SystemColors.Desktop;
            this.label_FatherName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_FatherName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_FatherName.Location = new System.Drawing.Point(110, 130);
            this.label_FatherName.Name = "label_FatherName";
            this.label_FatherName.Size = new System.Drawing.Size(71, 13);
            this.label_FatherName.TabIndex = 99;
            this.label_FatherName.Text = "Father Name:";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.Location = new System.Drawing.Point(65, 165);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(35, 13);
            this.label111.TabIndex = 106;
            this.label111.Text = "Class:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(278, 62);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(45, 13);
            this.label13.TabIndex = 100;
            this.label13.Text = "Gender:";
            // 
            // label_SessionDesc
            // 
            this.label_SessionDesc.AutoSize = true;
            this.label_SessionDesc.BackColor = System.Drawing.SystemColors.Desktop;
            this.label_SessionDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_SessionDesc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_SessionDesc.Location = new System.Drawing.Point(316, 26);
            this.label_SessionDesc.Name = "label_SessionDesc";
            this.label_SessionDesc.Size = new System.Drawing.Size(69, 13);
            this.label_SessionDesc.TabIndex = 104;
            this.label_SessionDesc.Text = "SessionDesc";
            // 
            // label_Gender
            // 
            this.label_Gender.AutoSize = true;
            this.label_Gender.BackColor = System.Drawing.SystemColors.Desktop;
            this.label_Gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Gender.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_Gender.Location = new System.Drawing.Point(328, 62);
            this.label_Gender.Name = "label_Gender";
            this.label_Gender.Size = new System.Drawing.Size(45, 13);
            this.label_Gender.TabIndex = 101;
            this.label_Gender.Text = "Gender:";
            // 
            // label_AdmissionDate
            // 
            this.label_AdmissionDate.AutoSize = true;
            this.label_AdmissionDate.BackColor = System.Drawing.SystemColors.Desktop;
            this.label_AdmissionDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_AdmissionDate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_AdmissionDate.Location = new System.Drawing.Point(486, 63);
            this.label_AdmissionDate.Name = "label_AdmissionDate";
            this.label_AdmissionDate.Size = new System.Drawing.Size(83, 13);
            this.label_AdmissionDate.TabIndex = 103;
            this.label_AdmissionDate.Text = "Admission Date:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(389, 62);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 13);
            this.label15.TabIndex = 102;
            this.label15.Text = "Admission Date:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkRed;
            this.label9.Location = new System.Drawing.Point(19, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(674, 13);
            this.label9.TabIndex = 91;
            this.label9.Text = "Now Click Assign New GR No. button to Allot New GR Number, and than Click Registe" +
                "r Student button to Complete the Registration Process.";
            // 
            // smcsd_IDTextBox
            // 
            this.smcsd_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Student_MovementBindingSource, "Smcsd_ID", true));
            this.smcsd_IDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.smcsd_IDTextBox.Location = new System.Drawing.Point(260, 63);
            this.smcsd_IDTextBox.Name = "smcsd_IDTextBox";
            this.smcsd_IDTextBox.Size = new System.Drawing.Size(44, 20);
            this.smcsd_IDTextBox.TabIndex = 133;
            // 
            // result_IDTextBox
            // 
            this.result_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Student_MovementBindingSource, "Result_ID", true));
            this.result_IDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.result_IDTextBox.Location = new System.Drawing.Point(193, 63);
            this.result_IDTextBox.Name = "result_IDTextBox";
            this.result_IDTextBox.Size = new System.Drawing.Size(43, 20);
            this.result_IDTextBox.TabIndex = 116;
            // 
            // session_IDTextBox
            // 
            this.session_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Student_MovementBindingSource, "Session_ID", true));
            this.session_IDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.session_IDTextBox.Location = new System.Drawing.Point(132, 63);
            this.session_IDTextBox.Name = "session_IDTextBox";
            this.session_IDTextBox.Size = new System.Drawing.Size(43, 20);
            this.session_IDTextBox.TabIndex = 105;
            // 
            // student_IDTextBox
            // 
            this.student_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tbl_Student_MasterBindingSource, "Student_ID", true));
            this.student_IDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.student_IDTextBox.Location = new System.Drawing.Point(70, 63);
            this.student_IDTextBox.Name = "student_IDTextBox";
            this.student_IDTextBox.Size = new System.Drawing.Size(43, 20);
            this.student_IDTextBox.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(69, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(267, 13);
            this.label7.TabIndex = 135;
            this.label7.Text = "These are Binding Text Boxes, which are using in code";
            this.label7.Visible = false;
            // 
            // tbl_SMCS_DefineTableAdapter
            // 
            this.tbl_SMCS_DefineTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tabControl1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 77);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(822, 562);
            this.groupBox1.TabIndex = 134;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "New Student Registration";
            // 
            // Form_NewStudent_Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 746);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form_NewStudent_Registration";
            this.Text = "New Student Registration";
            this.Load += new System.EventHandler(this.Form_NewStudent_Registration_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_NewStudent_Registration_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.schoolDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Student_MasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Student_MovementBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblResultBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.notRegStudent_bindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dvg_NotRegisteredStudent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSMCSDefineBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_RegisteredStudent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.regStudent_bindingSource)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_Student_MasterBindingNavigator)).EndInit();
            this.tbl_Student_MasterBindingNavigator.ResumeLayout(false);
            this.tbl_Student_MasterBindingNavigator.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private SchoolDbDataSet schoolDbDataSet;
        private System.Windows.Forms.BindingSource tbl_Student_MasterBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Student_MasterTableAdapter tbl_Student_MasterTableAdapter;
        private System.Windows.Forms.BindingSource tbl_Student_MovementBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_Student_MovementTableAdapter tbl_Student_MovementTableAdapter;
        private System.Windows.Forms.TextBox st_Mov_IDTextBox;
        private System.Windows.Forms.TextBox gR_NoTextBox1;
        private System.Windows.Forms.BindingSource tblResultBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_ResultTableAdapter tbl_ResultTableAdapter;
        private System.Windows.Forms.BindingSource notRegStudent_bindingSource;
        private System.Windows.Forms.DataGridView dvg_NotRegisteredStudent;
        private System.Windows.Forms.ComboBox searchByClassComboBox;
        private System.Windows.Forms.Button btnFindStudent;
       public  System.Windows.Forms.Label label_SMCS_ID;
        private System.Windows.Forms.Label label_SessionID;
        private System.Windows.Forms.DataGridView dgv_RegisteredStudent;
        private System.Windows.Forms.BindingSource regStudent_bindingSource;
        private System.Windows.Forms.ComboBox comboBox3_Result;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19_resultID;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox result_IDTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label_Class_Detail;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.TextBox session_IDTextBox;
        private System.Windows.Forms.Label label_SessionDesc;
        private System.Windows.Forms.Label label_AdmissionDate;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label_Gender;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label_FatherName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label_StudentName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox student_IDTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox percentageTextBox;
        private System.Windows.Forms.TextBox rollTextBox;
        private System.Windows.Forms.TextBox gR_NoTextBox;
        private System.Windows.Forms.BindingNavigator tbl_Student_MasterBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tbl_Student_MasterBindingNavigatorSaveItem;
        private System.Windows.Forms.ToolStripButton BtnUpdate;
        private System.Windows.Forms.Label label19_Result;
        private System.Windows.Forms.Label label3_St_ID;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.Label label18_Test_Percent;
        private System.Windows.Forms.ToolStripButton btn_Edit;
        private System.Windows.Forms.BindingSource tblSMCSDefineBindingSource;
        private GeneralSchool.SchoolDbDataSetTableAdapters.tbl_SMCS_DefineTableAdapter tbl_SMCS_DefineTableAdapter;
        private System.Windows.Forms.TextBox smcsd_IDTextBox;
        private System.Windows.Forms.Label label18_Total_Student;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label4_MaxRoll;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2_ClassID;
        private System.Windows.Forms.Label label2_Class_Capacity;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label7;
    }
}